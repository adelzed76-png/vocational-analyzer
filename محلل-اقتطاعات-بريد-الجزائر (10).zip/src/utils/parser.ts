import { PaymentStatus, RawRecord } from '../types';
import { normalizeAmount } from './formatters';

export const STATUS_MAP: Record<string, { labelAr: string; labelFr: string; status: PaymentStatus }> = {
  "000": { labelAr: "تم التسديد في الوقت", labelFr: "Payé à temps", status: PaymentStatus.PAID_ON_TIME },
  "100": { labelAr: "تحت المراقبة", labelFr: "Sous surveillance", status: PaymentStatus.NOT_PAID },
  "126": { labelAr: "لم يتم الدفع", labelFr: "Non payé", status: PaymentStatus.NOT_PAID },
  "127": { labelAr: "لم يتم الدفع", labelFr: "Non payé", status: PaymentStatus.NOT_PAID },
  "200": { labelAr: "حساب محجور", labelFr: "Compte bloqué", status: PaymentStatus.NOT_PAID },
  "226": { labelAr: "فشل المراقبة", labelFr: "Échec de surveillance", status: PaymentStatus.NOT_PAID },
  "227": { labelAr: "فشل المراقبة", labelFr: "Échec de surveillance", status: PaymentStatus.NOT_PAID },
};

export const getStatusFromCode = (code: string): { labelAr: string; labelFr: string; status: PaymentStatus } => {
  // 3. Code Classification (CRITICAL)
  
  // Paid on Time: 000
  if (code === "000") {
    return { labelAr: "تم التسديد في الوقت", labelFr: "Payé à temps", status: PaymentStatus.PAID_ON_TIME };
  }
  
  // Paid Late: 001 → 027
  if (code >= "001" && code <= "027") {
    return { labelAr: "تم الدفع متأخرا", labelFr: "Paid late", status: PaymentStatus.PAID_LATE };
  }
  
  // Unpaid: 126 / 127 / 200 (and others)
  const unpaidCodes = ["126", "127", "200"];
  if (unpaidCodes.includes(code)) {
    return { labelAr: "لم يتم الدفع", labelFr: "Non payé", status: PaymentStatus.NOT_PAID };
  }
  
  // Fallback for any other code
  return { labelAr: "غير مسدد", labelFr: "Non payé", status: PaymentStatus.NOT_PAID };
};

export const parseRecord = (data: any, fileName: string, overrideMonth?: string, overrideYear?: string, lineIndex: number = 0): RawRecord | null => {
  try {
    const customerAccount = String(data.customerAccount || data['Compte Client'] || data['Account'] || '').trim();
    const customerName = String(data.customerName || data['Nom Client'] || data['Name'] || '').trim();
    const installmentAmount = normalizeAmount(parseFloat(data.installmentAmount || data['Montant'] || data['Amount'] || 0));
    const rawDate = String(data.installmentDate || data['Date'] || data['date'] || '').trim();
    const installmentDate = rawDate || (overrideMonth && overrideYear ? `02/${overrideMonth}/${overrideYear}` : '');
    const statusCode = String(data.statusCode || data['Code Statut'] || data['Status'] || '').trim();
    const fullReference = String(data.fullReference || data['Référence'] || data['Reference'] || '').trim();
    
    if (!customerAccount || isNaN(installmentAmount) || !installmentDate) {
      if (!overrideMonth || !overrideYear) return null;
    }

    const [referenceNumber, referenceYear] = fullReference.split('/');
    
    let deductionMonth = "";
    let deductionYear = "";

    // Rule: ALWAYS prioritize the month from the Payment Date inside the line
    const dateParts = installmentDate.split('/');
    if (dateParts.length === 3) {
      deductionMonth = dateParts[1];
      deductionYear = dateParts[2];
    } else {
      // Fallback to override only if date is missing or invalid
      deductionMonth = overrideMonth || "";
      deductionYear = overrideYear || "";
    }

    let deductionDay = 2;
    if (statusCode === "000") {
      deductionDay = 2;
    } else if (statusCode.startsWith('0')) {
      deductionDay = 2 + parseInt(statusCode, 10);
    }

    // Stable ID to prevent double counting across uploads while keeping duplicates in same file
    const id = `${fileName}-${lineIndex}-${customerAccount}-${installmentAmount}-${statusCode}`.replace(/\s+/g, '');

    return {
      id,
      customerAccount,
      customerName,
      installmentAmount,
      installmentDate,
      deductionDay,
      deductionMonth,
      deductionYear,
      sellerAccount: String(data.sellerAccount || '').trim(),
      statusCode,
      referenceNumber: referenceNumber || "",
      referenceYear: referenceYear || "",
      fullReference,
      fileName,
      lineIndex,
      uploadDate: Date.now(),
      isValid: true
    };
  } catch (e) {
    return null;
  }
};

export const createInvalidRecord = (fileName: string, index: number): RawRecord => {
  return {
    id: `invalid-${fileName}-${index}-${Date.now()}`,
    customerAccount: "INVALID",
    customerName: "Invalid Record",
    installmentAmount: 0,
    installmentDate: "00/00/0000",
    deductionDay: 0,
    deductionMonth: "00",
    deductionYear: "0000",
    sellerAccount: "",
    statusCode: "ERR",
    referenceNumber: "",
    referenceYear: "",
    fullReference: "INVALID",
    fileName,
    lineIndex: index,
    uploadDate: Date.now(),
    isValid: false
  };
};

export const parseTxtLine = (line: string, fileName: string, overrideMonth?: string, overrideYear?: string, lineIndex: number = 0): RawRecord | null => {
  if (!line || line.trim().length === 0) return null;

  try {
    // 1. Transaction Line Structure (Strict Parsing)
    // [Account][Customer Name][Amount][Payment Date][...93][Code][Reference]
    
    // 2. Extract Required Fields
    
    // 2.1 Customer CCP Account (exactly 10 digits as per requirement, at the start)
    const accountMatch = line.match(/^(\d{10})/);
    const customerAccount = accountMatch ? accountMatch[1].trim() : "0000000000";
    
    // 2.2 Amount (11.2 format: 00000000500.00)
    const amountMatch = line.match(/(\d{1,11}\.\d{2})/);
    const rawAmount = amountMatch ? parseFloat(amountMatch[1]) : 0;
    const installmentAmount = normalizeAmount(rawAmount);

    // 2.3 Payment Date (DD/MM/YYYY) - Search specifically after the amount
    const amountIndex = amountMatch ? line.indexOf(amountMatch[0]) : -1;
    const searchArea = amountIndex !== -1 ? line.substring(amountIndex + amountMatch[0].length) : line;
    const dateMatch = searchArea.match(/(\d{2})\/(\d{2})\/(\d{4})/);
    const lineDate = dateMatch ? dateMatch[0] : null;
    const installmentDate = lineDate || (overrideMonth && overrideYear ? `02/${overrideMonth}/${overrideYear}` : "01/01/2000");
    
    // 2.4 Code (3 digits after 93) and Reference (after code)
    // The user mentions both 930 and 93. We search for '93' as the primary marker.
    const last93Index = line.lastIndexOf('93');
    let statusCode = "UNKNOWN";
    let referencePart = "SANS REF";
    let sellerAccount = "";

    if (last93Index !== -1) {
      sellerAccount = line.substring(0, last93Index + 2).trim();
      const after93 = line.substring(last93Index + 2);
      if (after93.length >= 3) {
        statusCode = after93.substring(0, 3);
        referencePart = after93.substring(3).trim();
      }
    }

    const [referenceNumber, referenceYear] = referencePart.split('/');
    
    // 2.5 Customer Name (between account and amount)
    const nameStart = accountMatch ? accountMatch[1].length : 10;
    const customerName = amountIndex !== -1 
      ? line.substring(nameStart, amountIndex).trim() 
      : "NOM INCONNU";

    // 3. Month Assignment Logic (STRICT)
    // Rule: NEVER use the file month (overrideMonth/Year). ALWAYS use the month from Payment Date inside the line.
    let deductionMonth = overrideMonth || "01";
    let deductionYear = overrideYear || "2000";

    if (dateMatch) {
      // ALWAYS use the month from Payment Date inside the line for ALL classifications (000, 0XX, 126, etc.)
      deductionMonth = dateMatch[2]; // MM
      deductionYear = dateMatch[3];  // YYYY
    }

    const isPaidOnTime = statusCode === "000";
    const isPaidLate = statusCode >= "001" && statusCode <= "027";

    // Deduction Day logic
    let deductionDay = 2;
    if (isPaidOnTime) {
      deductionDay = 2;
    } else if (statusCode.startsWith('0')) {
      const offset = parseInt(statusCode, 10);
      deductionDay = 2 + (isNaN(offset) ? 0 : offset);
    }

    // Stable ID to prevent double counting across uploads while keeping duplicates in same file
    const id = `${fileName}-${lineIndex}-${customerAccount}-${installmentAmount}-${statusCode}`.replace(/\s+/g, '');

    return {
      id,
      customerAccount,
      customerName,
      installmentAmount,
      installmentDate,
      deductionDay,
      deductionMonth,
      deductionYear,
      sellerAccount,
      statusCode,
      referenceNumber: referenceNumber || "",
      referenceYear: referenceYear || "",
      fullReference: referencePart,
      fileName,
      lineIndex,
      uploadDate: Date.now(),
      isValid: true
    };
  } catch (e) {
    return createInvalidRecord(fileName, lineIndex);
  }
};
