/**
 * Formats a number as Algerian Dinar (DZD) with two decimal places.
 */
export const formatCurrency = (amount: number, includeSymbol: boolean = true): string => {
  const formatted = amount.toFixed(2);
  
  if (includeSymbol) {
    return `${formatted} دج`;
  }
  return formatted;
};

/**
 * Normalizes a financial amount.
 */
export const normalizeAmount = (amount: number): number => {
  return amount;
};
