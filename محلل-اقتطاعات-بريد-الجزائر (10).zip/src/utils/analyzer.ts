import { RawRecord, CustomerSummary, PaymentStatus, MonthlyBreakdown, CustomerConfig, LoanSummary } from '../types';
import { getStatusFromCode } from './parser';

export function getInstallmentMonth(record: RawRecord): string {
  // Rule: ALWAYS use the deduction month/year which should have been set from the line date during parsing
  let m = parseInt(record.deductionMonth, 10);
  let y = parseInt(record.deductionYear, 10);
  
  return `${String(m).padStart(2, '0')} / ${y}`;
}

export function calculateDuration(startDate: string, endDate: string): number {
  try {
    const sParts = startDate.split('/');
    const eParts = endDate.split('/');
    
    if (sParts.length < 3 || eParts.length < 3) return 12;

    const sm = parseInt(sParts[1], 10);
    const sy = parseInt(sParts[2], 10);
    const em = parseInt(eParts[1], 10);
    const ey = parseInt(eParts[2], 10);
    
    if (isNaN(sm) || isNaN(sy) || isNaN(em) || isNaN(ey)) return 12;
    
    const duration = (ey - sy) * 12 + (em - sm) + 1;
    return Math.max(1, duration);
  } catch (e) {
    return 12;
  }
}

export function calculateEndDate(startDate: string, duration: number): string {
  try {
    const [d, m, y] = startDate.split('/').map(Number);
    if (isNaN(d) || isNaN(m) || isNaN(y)) return '';
    
    // Start date is month 1. End date is month 'duration'.
    // Example: Start Dec 2025, Duration 12 months -> End Nov 2026.
    const date = new Date(y, m - 1 + duration - 1, d);
    
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    
    return `${day}/${month}/${year}`;
  } catch (e) {
    return '';
  }
}

export function processRecords(
  records: RawRecord[], 
  configs: Record<string, CustomerConfig> = {}
): CustomerSummary[] {
  const customerMap = new Map<string, RawRecord[]>();
  
  records.forEach(record => {
    const key = record.customerAccount.trim();
    if (key === "INVALID") return;
    let existing = customerMap.get(key);
    if (!existing) {
      existing = [];
      customerMap.set(key, existing);
    }
    existing.push(record);
  });

  const summaries: CustomerSummary[] = [];
  const now = new Date();

    customerMap.forEach((customerRecords, account) => {
    const loans: LoanSummary[] = [];
    
    // Group records by "Contract" (based on start date and reference)
    // We'll treat each unique reference as a separate "loan" or group them by start date
    const contractMap = new Map<string, RawRecord[]>();
    
    customerRecords.forEach(r => {
      if (!r.isValid) return;
      const account = r.customerAccount.trim();
      const ref = r.fullReference || 'SANS REF';
      
      const config = configs[account];
      let startDate = 'SANS DATE';
      
      if (config) {
        if (config.contracts && config.contracts.length > 0) {
          const contract = config.contracts.find(c => 
            c.installments.some(i => i.reference === ref)
          );
          if (contract) {
            startDate = contract.startDate;
          } else {
            const refConfig = configs[`${account}|${ref}`];
            if (refConfig && refConfig.startDate) {
              startDate = refConfig.startDate;
            }
          }
        } else {
          const refConfig = configs[`${account}|${ref}`] || configs[account];
          startDate = refConfig?.startDate || 'SANS DATE';
        }
      }

      const key = startDate;
      let existing = contractMap.get(key);
      if (!existing) {
        existing = [];
        contractMap.set(key, existing);
      }
      existing.push(r);
    });

    contractMap.forEach((loanRecords, groupKey) => {
      const firstRecord = loanRecords[0];
      const account = firstRecord.customerAccount.trim();
      const config = configs[account];
      
      const startDateKey = groupKey;
      let startDate = startDateKey === 'SANS DATE' ? undefined : startDateKey;
      let installmentDuration = 12;
      let endDate = '';
      let manualMonthlyValue = 0;
      let isManualContract = false;
      let nonCollectableDebt = false;

      if (config && config.contracts && startDate) {
        const mContract = config.contracts.find(c => c.startDate === startDate);
        if (mContract) {
          installmentDuration = mContract.duration;
          endDate = mContract.endDate;
          manualMonthlyValue = mContract.monthlyValue;
          nonCollectableDebt = mContract.nonCollectableDebt || false;
          isManualContract = true;
        }
      }

      if (!isManualContract) {
        // Fallback to legacy config lookup
        const ref = firstRecord.fullReference || 'SANS REF';
        const refConfig = configs[`${account}|${ref}`] || configs[account] || { duration: 12 };
        startDate = startDate || refConfig.startDate;
        installmentDuration = refConfig.duration || 12;
        endDate = refConfig.endDate || '';
      }

      // Calculate installmentAmount for the group
      // This is the expected monthly amount.
      let installmentAmount = 0;
      if (isManualContract && manualMonthlyValue > 0) {
        installmentAmount = manualMonthlyValue;
      } else {
        // If not manual, we need to determine the monthly installment amount.
        // Usually, it's the amount of one installment.
        // If there are multiple unique references, we might sum them if they are for the same month.
        // But for now, let's take the most common amount or the first one.
        installmentAmount = firstRecord.installmentAmount;
      }
      
      if (startDate && !endDate) {
        endDate = calculateEndDate(startDate, installmentDuration);
      } else if (startDate && endDate) {
        installmentDuration = calculateDuration(startDate, endDate);
      }
      
      const totalExpected = Number((installmentAmount * installmentDuration).toFixed(2));
      
      const monthlyGroups = new Map<string, RawRecord[]>();
      loanRecords.forEach(r => {
        const key = getInstallmentMonth(r);
        let existing = monthlyGroups.get(key);
        if (!existing) {
          existing = [];
          monthlyGroups.set(key, existing);
        }
        existing.push(r);
      });

      const monthlyBreakdown: MonthlyBreakdown[] = [];
      let totalPaidAmount = 0;
      let totalUnpaidAmount = 0;
      let totalAttempts = 0;
      let paidOnTimeCount = 0;
      let paidLateCount = 0;
      let unpaidCount = 0;

      let monthKeys: string[] = [];
      if (startDate) {
        const [sd, sm, sy] = startDate.split('/').map(Number);
        const start = new Date(sy, sm - 1, 1);
        
        for (let i = 0; i < installmentDuration; i++) {
          const current = new Date(start.getFullYear(), start.getMonth() + i, 1);
          const m = String(current.getMonth() + 1).padStart(2, '0');
          const y = current.getFullYear();
          monthKeys.push(`${m} / ${y}`);
        }
      } else {
        monthKeys = Array.from(monthlyGroups.keys()).sort((a, b) => {
          const [ma, ya] = a.split(' / ').map(Number);
          const [mb, yb] = b.split(' / ').map(Number);
          return new Date(ya, ma - 1, 1).getTime() - new Date(yb, mb - 1, 1).getTime();
        });
      }

      monthKeys.forEach(monthKey => {
        const monthRecords = monthlyGroups.get(monthKey) || [];
        const [m, y] = monthKey.split(' / ').map(Number);
        const monthDate = new Date(y, m - 1, 1);
        
        const currentMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
        const isPast = monthDate < currentMonthStart;

        // Each line is one installment. Count ALL lines.
        // We use all records in monthRecords directly.
        const uniqueMonthRecords = monthRecords;
        const attemptCount = monthRecords.length;
        totalAttempts += attemptCount;

        let mPaidOnTime = 0;
        let mPaidLate = 0;
        let mUnpaid = 0;
        let mPaidAmount = 0;
        let mUnpaidAmount = 0;
        let status = PaymentStatus.NOT_COLLECTED;

        // Count successful payments
        uniqueMonthRecords.forEach(r => {
          const code = r.statusCode;
          if (code === "000") {
            mPaidOnTime++;
            mPaidAmount += r.installmentAmount;
          } else if (code >= "001" && code <= "027") {
            mPaidLate++;
            mPaidAmount += r.installmentAmount;
          }
        });

        // Expected count for this month is usually 1, but if we have more unique records, we use that.
        // Actually, if it's a past month and we have NO paid records, we expect 1.
        const expectedCountForMonth = Math.max(1, uniqueMonthRecords.length);
        const paidCount = mPaidOnTime + mPaidLate;
        
        if (paidCount > 0) {
          status = mPaidOnTime > 0 ? PaymentStatus.PAID_ON_TIME : PaymentStatus.PAID_LATE;
          if (paidCount < expectedCountForMonth) {
            mUnpaid = expectedCountForMonth - paidCount;
            mUnpaidAmount = mUnpaid * installmentAmount;
          }
        } else if (isPast) {
          mUnpaid = expectedCountForMonth;
          mUnpaidAmount = mUnpaid * installmentAmount;
          status = PaymentStatus.NOT_PAID;
        }

        paidOnTimeCount += mPaidOnTime;
        paidLateCount += mPaidLate;
        unpaidCount += mUnpaid;
        totalPaidAmount = Number((totalPaidAmount + mPaidAmount).toFixed(2));
        totalUnpaidAmount = Number((totalUnpaidAmount + mUnpaidAmount).toFixed(2));

        monthlyBreakdown.push({
          monthYear: monthKey,
          installmentAmount,
          attemptCount,
          collectedAmount: mPaidAmount,
          notCollectedAmount: mUnpaidAmount,
          paidOnTimeCount: mPaidOnTime,
          paidLateCount: mPaidLate,
          unpaidCount: mUnpaid,
          totalPaidAmount: mPaidAmount,
          totalUnpaidAmount: mUnpaidAmount,
          status,
          records: monthRecords
        });
      });

      const totalCollected = totalPaidAmount;
      const totalRemaining = Math.max(0, Number((totalExpected - totalCollected).toFixed(2)));
      const isOverpaid = totalCollected > totalExpected;
      
      let isStopList = totalCollected >= totalExpected;
      if (endDate) {
        const [ed, em, ey] = endDate.split('/').map(Number);
        const end = new Date(ey, em - 1, 28);
        if (now > end) isStopList = true;
      }

      const sortedLoanRecords = loanRecords.sort((a, b) => {
        const monthA = getInstallmentMonth(a);
        const monthB = getInstallmentMonth(b);
        const [ma, ya] = monthA.split(' / ').map(Number);
        const [mb, yb] = monthB.split(' / ').map(Number);
        return new Date(ya, ma - 1, 1).getTime() - new Date(yb, mb - 1, 1).getTime();
      });

      loans.push({
        fullReference: firstRecord.fullReference || 'SANS REF',
        referenceNumber: firstRecord.referenceNumber,
        referenceYear: firstRecord.referenceYear,
        installmentAmount,
        installmentDuration,
        startDate,
        endDate,
        totalExpected,
        totalCollected,
        totalPaidAmount,
        totalUnpaidAmount,
        totalNotCollected: totalUnpaidAmount,
        totalRemaining,
        totalAttempts,
        monthsPaid: paidOnTimeCount + paidLateCount,
        monthsMissed: unpaidCount,
        paidOnTimeCount,
        paidLateCount,
        unpaidCount,
        records: sortedLoanRecords,
        monthlyBreakdown,
        isStopList,
        isOverpaid,
        overdueMonths: unpaidCount,
        latestStatus: sortedLoanRecords.length > 0 
          ? getStatusFromCode(sortedLoanRecords[sortedLoanRecords.length - 1].statusCode).status 
          : PaymentStatus.UNKNOWN,
        nonCollectableDebt
      });
    });

    // Sort loans by reference number
    loans.sort((a, b) => a.referenceNumber.localeCompare(b.referenceNumber, undefined, { numeric: true }));

    const totalExpected = loans.reduce((sum, l) => sum + l.totalExpected, 0);
    const totalCollected = loans.reduce((sum, l) => sum + l.totalCollected, 0);
    const totalNotCollected = loans.reduce((sum, l) => sum + l.totalNotCollected, 0);
    const totalRemaining = loans.reduce((sum, l) => sum + l.totalRemaining, 0);
    const totalAttempts = loans.reduce((sum, l) => sum + l.totalAttempts, 0);
    const overdueMonths = loans.reduce((sum, l) => sum + l.overdueMonths, 0);
    const isStopList = loans.every(l => l.isStopList);
    const isOverpaid = loans.some(l => l.isOverpaid);
    
    // Find latest completion date
    let completionDate = '';
    loans.forEach(l => {
      if (l.endDate) {
        if (!completionDate) completionDate = l.endDate;
        else {
          const [cd, cm, cy] = completionDate.split('/').map(Number);
          const [ld, lm, ly] = l.endDate.split('/').map(Number);
          if (new Date(ly, lm - 1, ld) > new Date(cy, cm - 1, cd)) {
            completionDate = l.endDate;
          }
        }
      }
    });

    // Latest status across all loans
    const latestStatus = loans.length > 0 ? loans[0].latestStatus : PaymentStatus.UNKNOWN;

    // Get nonCollectableDebt from config
    const customerConfig = configs[account];
    const nonCollectableDebt = customerConfig?.nonCollectableDebt || false;

    summaries.push({
      customerAccount: account,
      customerName: customerRecords[0].customerName,
      loans,
      totalExpected,
      totalCollected,
      totalNotCollected,
      totalRemaining,
      totalAttempts,
      isStopList,
      isOverpaid,
      overdueMonths,
      completionDate,
      latestStatus,
      records: customerRecords.filter(r => r.isValid),
      nonCollectableDebt
    });
  });

  return summaries;
}
