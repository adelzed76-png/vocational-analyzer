import * as XLSX from 'xlsx';
import ExcelJS from 'exceljs';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { CustomerSummary, MonthlyBreakdown, RawRecord, PaymentStatus } from '../types';
import { getStatusFromCode } from './parser';
import { getInstallmentMonth } from './analyzer';
import { formatCurrency } from './formatters';

// Helper for French status labels
const getFrenchStatus = (status: PaymentStatus): string => {
  switch (status) {
    case PaymentStatus.PAID_ON_TIME: return 'Payé (Bleu)';
    case PaymentStatus.PAID_LATE: return 'Payé (Vert)';
    case PaymentStatus.UNDER_MONITORING: return 'En attente (Code 100)';
    case PaymentStatus.NOT_PAID: return 'Non payé (Rouge)';
    case PaymentStatus.ACCOUNT_BLOCKED: return 'Compte bloqué';
    case PaymentStatus.MONITORING_FAILURE: return 'Échec de surveillance';
    case PaymentStatus.OVERPAID: return 'Trop-perçu (Jaune)';
    default: return 'Inconnu';
  }
};

const getStatusColor = (status: PaymentStatus): string => {
  switch (status) {
    case PaymentStatus.PAID_ON_TIME: return '3498db'; // Blue
    case PaymentStatus.PAID_LATE: return '2ecc71'; // Green
    case PaymentStatus.NOT_PAID: return 'e74c3c'; // Red
    case PaymentStatus.UNDER_MONITORING: return 'ffffff'; // White
    case PaymentStatus.OVERPAID: return 'f1c40f'; // Yellow
    default: return 'bdc3c7'; // Gray
  }
};

/**
 * EXCEL EXPORTS (using exceljs for styling)
 */

export const exportMonthlyReportToExcel = async (
  monthYear: string,
  summaries: CustomerSummary[]
) => {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Rapport Mensuel');

  worksheet.columns = [
    { header: 'N° Compte', key: 'account', width: 15 },
    { header: 'Nom du Client', key: 'name', width: 30 },
    { header: 'Référence', key: 'ref', width: 25 },
    { header: 'Mois Mensualité', key: 'month', width: 15 },
    { header: 'Montant Mensualité', key: 'amount', width: 15 },
    { header: 'Collecté', key: 'collected', width: 15 },
    { header: 'Non Collecté', key: 'notCollected', width: 15 },
    { header: 'Statut', key: 'status', width: 20 },
    { header: 'Date Prélèvement', key: 'date', width: 15 }
  ];

  summaries.forEach(s => {
    s.loans.forEach(loan => {
      const m = loan.monthlyBreakdown.find(mb => mb.monthYear === monthYear);
      if (m && m.records.length > 0) {
        m.records.forEach(record => {
          const { status: recStatus } = getStatusFromCode(record.statusCode);
          let displayStatus = recStatus;
          
          if (recStatus === PaymentStatus.PAID_ON_TIME) {
            const [rd] = record.installmentDate.split('/').map(Number);
            displayStatus = rd <= 2 ? PaymentStatus.PAID_ON_TIME : PaymentStatus.PAID_LATE;
          }

          const row = worksheet.addRow({
            account: s.customerAccount,
            name: s.customerName,
            ref: loan.fullReference,
            month: monthYear,
            amount: loan.installmentAmount,
            collected: (displayStatus === PaymentStatus.PAID_ON_TIME || displayStatus === PaymentStatus.PAID_LATE) ? record.installmentAmount : 0,
            notCollected: (displayStatus !== PaymentStatus.PAID_ON_TIME && displayStatus !== PaymentStatus.PAID_LATE) ? record.installmentAmount : 0,
            status: getFrenchStatus(displayStatus),
            date: record.installmentDate
          });

          const color = getStatusColor(displayStatus);
          row.getCell('status').fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FF' + color }
          };
        });
      }
    });
  });

  // Totals
  let totalExpected = 0;
  let totalCollected = 0;
  let totalNotCollected = 0;
  const statusCounts: Record<string, number> = {};

  summaries.forEach(s => {
    s.loans.forEach(loan => {
      const m = loan.monthlyBreakdown.find(mb => mb.monthYear === monthYear);
      if (m) {
        totalExpected += loan.installmentAmount;
        totalCollected += m.collectedAmount;
        totalNotCollected += m.notCollectedAmount;
        statusCounts[m.status] = (statusCounts[m.status] || 0) + 1;
      }
    });
  });

  worksheet.addRow([]);
  worksheet.addRow(['Statistiques du Mois']).font = { bold: true };
  worksheet.addRow(['Total Attendu', totalExpected]);
  worksheet.addRow(['Total Collecté', totalCollected]);
  worksheet.addRow(['Total Non Collecté', totalNotCollected]);
  worksheet.addRow(['Nombre de Clients par Statut']).font = { bold: true };
  Object.entries(statusCounts).forEach(([status, count]) => {
    worksheet.addRow([getFrenchStatus(status as PaymentStatus), count]);
  });

  worksheet.addRow([]);
  worksheet.addRow(['Note: Le mois de mensualité est déterminé par la date de prélèvement. Les prélèvements jusqu\'au 02 du mois sont considérés pour le mois précédent.']).font = { italic: true, size: 10 };

  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Rapport_Mensuel_${monthYear.replace(' / ', '_')}.xlsx`;
  a.click();
};

export const exportCustomerReportToExcel = async (customer: CustomerSummary) => {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Fiche Client');

  worksheet.addRow(['Numéro de Compte', customer.customerAccount]);
  worksheet.addRow(['Nom du Client', customer.customerName]);
  worksheet.addRow(['Total Collecté', customer.totalCollected]);
  worksheet.addRow(['Total Restant', customer.totalRemaining]);
  
  if (customer.isOverpaid) {
    const alertRow = worksheet.addRow(['ALERTE', 'Le client a dépassé le montant total des mensualités sur un ou plusieurs prêts.']);
    alertRow.getCell(2).font = { color: { argb: 'FFFF0000' }, bold: true };
  }
  worksheet.addRow([]);

  customer.loans.forEach(loan => {
    worksheet.addRow([`PRÊT: ${loan.fullReference}`]).font = { bold: true, size: 12 };
    worksheet.addRow(['Date de Début', loan.startDate || '---']);
    worksheet.addRow(['Date de Fin', loan.endDate || '---']);
    worksheet.addRow(['Durée', `${loan.installmentDuration} mois`]);
    worksheet.addRow(['Montant Mensuel', loan.installmentAmount]);
    worksheet.addRow(['Total Collecté', loan.totalCollected]);
    worksheet.addRow(['Total Restant', loan.totalRemaining]);
    worksheet.addRow([]);

    const tableHeader = worksheet.addRow(['Mois', 'Date', 'Mensualité', 'Collecté', 'Non Collecté', 'Statut', 'Référence']);
    tableHeader.font = { bold: true };

    loan.monthlyBreakdown.forEach(m => {
      if (m.records.length > 0) {
        m.records.forEach(record => {
          const { status: recStatus } = getStatusFromCode(record.statusCode);
          let displayStatus = recStatus;
          
          if (recStatus === PaymentStatus.PAID_ON_TIME) {
            const [rd, rm, ry] = record.installmentDate.split('/').map(Number);
            const instDate = new Date(ry, rm - 1, rd);
            
            let resMonth: number, resYear: number;
            if (record.deductionMonth && record.deductionYear) {
              resMonth = parseInt(record.deductionMonth, 10);
              resYear = parseInt(record.deductionYear, 10);
            } else {
              if (rd <= 2) {
                resMonth = rm;
                resYear = ry;
              } else {
                const next = new Date(ry, rm, 1);
                resMonth = next.getMonth() + 1;
                resYear = next.getFullYear();
              }
            }
            
            const limitDate = new Date(resYear, resMonth - 1, 2);
            displayStatus = instDate <= limitDate ? PaymentStatus.PAID_ON_TIME : PaymentStatus.PAID_LATE;
          }

          const row = worksheet.addRow([
            m.monthYear,
            record.installmentDate,
            loan.installmentAmount,
            (displayStatus === PaymentStatus.PAID_ON_TIME || displayStatus === PaymentStatus.PAID_LATE) ? record.installmentAmount : 0,
            (displayStatus !== PaymentStatus.PAID_ON_TIME && displayStatus !== PaymentStatus.PAID_LATE) ? record.installmentAmount : 0,
            getFrenchStatus(displayStatus),
            record.fullReference
          ]);

          const color = getStatusColor(displayStatus);
          row.getCell(6).fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FF' + color }
          };
        });
      } else {
        const row = worksheet.addRow([
          m.monthYear,
          '',
          loan.installmentAmount,
          0,
          loan.installmentAmount,
          getFrenchStatus(PaymentStatus.NOT_PAID),
          ''
        ]);
        row.getCell(6).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE74C3C' } };
      }
    });
    worksheet.addRow([]);
    worksheet.addRow([]);
  });

  worksheet.addRow([]);
  worksheet.addRow(['Note: Le mois de mensualité est déterminé par la date de prélèvement. Les prélèvements jusqu\'au 02 du mois sont considérés pour le mois précédent.']).font = { italic: true, size: 10 };

  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Fiche_Client_${customer.customerAccount}.xlsx`;
  a.click();
};

export const exportFullDatabaseToExcel = async (summaries: CustomerSummary[]) => {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Base de Données');

  worksheet.columns = [
    { header: 'Numéro de Compte', key: 'account', width: 15 },
    { header: 'Nom du Client', key: 'name', width: 30 },
    { header: 'Référence', key: 'ref', width: 25 },
    { header: 'Date Début', key: 'startDate', width: 15 },
    { header: 'Date Fin', key: 'endDate', width: 15 },
    { header: 'Mensualité', key: 'amount', width: 15 },
    { header: 'Durée', key: 'duration', width: 10 },
    { header: 'Total Collecté', key: 'collected', width: 15 },
    { header: 'Mensualités Payées', key: 'paid', width: 15 },
    { header: 'Mensualités Restantes', key: 'remaining', width: 15 },
    { header: 'Statut', key: 'status', width: 15 }
  ];

  summaries.forEach(s => {
    s.loans.forEach(loan => {
      const row = worksheet.addRow({
        account: s.customerAccount,
        name: s.customerName,
        ref: loan.fullReference,
        startDate: loan.startDate || '---',
        endDate: loan.endDate || '---',
        amount: loan.installmentAmount,
        duration: loan.installmentDuration,
        collected: loan.totalCollected,
        paid: loan.monthsPaid,
        remaining: loan.totalRemaining,
        status: loan.isOverpaid ? 'Trop-perçu' : loan.isStopList ? 'Terminé' : 'En cours'
      });

      if (loan.isOverpaid) {
        row.getCell('status').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF1C40F' } }; // Yellow
      } else if (loan.isStopList) {
        row.getCell('status').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF2ECC71' } }; // Green
      }
    });
  });

  worksheet.addRow([]);
  worksheet.addRow(['Note: Le mois de mensualité est déterminé par la date de prélèvement. Les prélèvements jusqu\'au 02 du mois sont considérés pour le mois précédent.']).font = { italic: true, size: 10 };

  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Base_de_Donnees_Clients.xlsx`;
  a.click();
};

/**
 * PDF EXPORTS
 */

export const exportMonthlyReportToPDF = (
  monthYear: string,
  summaries: CustomerSummary[]
) => {
  const doc = new jsPDF('p', 'mm', 'a4');
  const dateStr = new Date().toLocaleDateString('fr-FR');

  doc.setFontSize(18);
  doc.text('Rapport des Prélèvements Algérie Poste', 105, 15, { align: 'center' });
  
  doc.setFontSize(12);
  doc.text(`Mois: ${monthYear}`, 10, 25);
  doc.text(`Date d'émission: ${dateStr}`, 10, 32);

  const tableData: any[][] = [];
  summaries.forEach(s => {
    s.loans.forEach(loan => {
      const m = loan.monthlyBreakdown.find(mb => mb.monthYear === monthYear);
      if (m && m.records.length > 0) {
        m.records.forEach(record => {
          const { status: recStatus } = getStatusFromCode(record.statusCode);
          let displayStatus = recStatus;
          
          if (recStatus === PaymentStatus.PAID_ON_TIME) {
            const [rd, rm, ry] = record.installmentDate.split('/').map(Number);
            const instDate = new Date(ry, rm - 1, rd);
            
            let resMonth: number, resYear: number;
            if (record.deductionMonth && record.deductionYear) {
              resMonth = parseInt(record.deductionMonth, 10);
              resYear = parseInt(record.deductionYear, 10);
            } else {
              if (rd <= 2) {
                resMonth = rm;
                resYear = ry;
              } else {
                const next = new Date(ry, rm, 1);
                resMonth = next.getMonth() + 1;
                resYear = next.getFullYear();
              }
            }
            
            const limitDate = new Date(resYear, resMonth - 1, 2);
            displayStatus = instDate <= limitDate ? PaymentStatus.PAID_ON_TIME : PaymentStatus.PAID_LATE;
          }
          tableData.push([
            s.customerAccount,
            s.customerName,
            loan.fullReference,
            formatCurrency(loan.installmentAmount),
            record.installmentDate,
            getFrenchStatus(displayStatus)
          ]);
        });
      }
    });
  });

  autoTable(doc, {
    startY: 40,
    head: [['Compte', 'Nom', 'Référence', 'Montant', 'Date', 'Statut']],
    body: tableData,
    theme: 'grid',
    styles: { font: 'helvetica', halign: 'left', fontSize: 8 },
    headStyles: { fillColor: [41, 128, 185], textColor: 255 },
    didParseCell: (data) => {
      if (data.section === 'body' && data.column.index === 5) {
        const statusText = data.cell.text[0];
        if (statusText.includes('Bleu')) data.cell.styles.fillColor = [52, 152, 219]; 
        if (statusText.includes('Vert')) data.cell.styles.fillColor = [46, 204, 113]; 
        if (statusText.includes('Rouge')) data.cell.styles.fillColor = [231, 76, 60]; 
        if (statusText.includes('Jaune')) data.cell.styles.fillColor = [241, 196, 15]; 
      }
    }
  });

  const finalY = (doc as any).lastAutoTable.finalY + 10;
  
  let totalExpected = 0;
  let totalCollected = 0;
  let totalNotCollected = 0;
  const statusCounts: Record<string, number> = {};

  summaries.forEach(s => {
    s.loans.forEach(loan => {
      const m = loan.monthlyBreakdown.find(mb => mb.monthYear === monthYear);
      if (m) {
        totalExpected += loan.installmentAmount;
        totalCollected += m.collectedAmount;
        totalNotCollected += m.notCollectedAmount;
        statusCounts[m.status] = (statusCounts[m.status] || 0) + 1;
      }
    });
  });

  doc.text(`Total Attendu: ${formatCurrency(totalExpected)}`, 10, finalY);
  doc.text(`Total Collecté: ${formatCurrency(totalCollected)}`, 10, finalY + 7);
  doc.text(`Total Non Collecté: ${formatCurrency(totalNotCollected)}`, 10, finalY + 14);
  
  let currentY = finalY + 25;
  doc.text('Nombre de Clients par Statut:', 10, currentY);
  Object.entries(statusCounts).forEach(([status, count]) => {
    currentY += 7;
    doc.text(`${getFrenchStatus(status as PaymentStatus)}: ${count}`, 10, currentY);
  });

  doc.setFontSize(8);
  doc.text('Note: Le mois de mensualité est déterminé par la date de prélèvement. Les prélèvements jusqu\'au 02 du mois sont considérés pour le mois précédent.', 105, 285, { align: 'center' });

  doc.save(`Rapport_Mensuel_${monthYear.replace(' / ', '_')}.pdf`);
};

export const exportCustomerReportToPDF = (customer: CustomerSummary) => {
  const doc = new jsPDF('p', 'mm', 'a4');
  const dateStr = new Date().toLocaleDateString('fr-FR');

  doc.setFontSize(18);
  doc.text('Fiche Client - Algérie Poste', 105, 15, { align: 'center' });

  doc.setFontSize(12);
  doc.text(`Client: ${customer.customerName}`, 10, 25);
  doc.text(`Compte: ${customer.customerAccount}`, 10, 32);
  doc.text(`Date d'émission: ${dateStr}`, 10, 39);

  if (customer.isOverpaid) {
    doc.setTextColor(231, 76, 60);
    doc.setFontSize(10);
    doc.text('ALERTE: Le client a dépassé le montant total des mensualités sur un ou plusieurs prêts.', 10, 46);
    doc.setTextColor(0, 0, 0);
  }

  doc.setFontSize(12);
  doc.text(`Total Collecté: ${formatCurrency(customer.totalCollected)}`, 10, 55);
  doc.text(`Total Restant: ${formatCurrency(customer.totalRemaining)}`, 10, 62);

  let currentY = 75;

  customer.loans.forEach((loan, lIdx) => {
    if (currentY > 250) {
      doc.addPage();
      currentY = 20;
    }

    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text(`PRÊT ${lIdx + 1}: ${loan.fullReference}`, 10, currentY);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    currentY += 7;
    doc.text(`Période: ${loan.startDate || '---'} au ${loan.endDate || '---'} | Durée: ${loan.installmentDuration} mois`, 10, currentY);
    currentY += 7;
    doc.text(`Mensualité: ${formatCurrency(loan.installmentAmount)} | Collecté: ${formatCurrency(loan.totalCollected)} | Restant: ${formatCurrency(loan.totalRemaining)}`, 10, currentY);
    currentY += 10;

    const tableData: any[][] = [];
    loan.monthlyBreakdown.forEach(m => {
      if (m.records.length > 0) {
        m.records.forEach(record => {
          const { status: recStatus } = getStatusFromCode(record.statusCode);
          let displayStatus = recStatus;
          
          if (recStatus === PaymentStatus.PAID_ON_TIME) {
            const [rd, rm, ry] = record.installmentDate.split('/').map(Number);
            const instDate = new Date(ry, rm - 1, rd);
            
            let resMonth: number, resYear: number;
            if (record.deductionMonth && record.deductionYear) {
              resMonth = parseInt(record.deductionMonth, 10);
              resYear = parseInt(record.deductionYear, 10);
            } else {
              if (rd <= 2) {
                resMonth = rm;
                resYear = ry;
              } else {
                const next = new Date(ry, rm, 1);
                resMonth = next.getMonth() + 1;
                resYear = next.getFullYear();
              }
            }
            
            const limitDate = new Date(resYear, resMonth - 1, 2);
            displayStatus = instDate <= limitDate ? PaymentStatus.PAID_ON_TIME : PaymentStatus.PAID_LATE;
          }
          tableData.push([
            m.monthYear,
            record.installmentDate,
            formatCurrency(loan.installmentAmount),
            formatCurrency(displayStatus === PaymentStatus.PAID_ON_TIME || displayStatus === PaymentStatus.PAID_LATE ? record.installmentAmount : 0),
            getFrenchStatus(displayStatus)
          ]);
        });
      } else {
        tableData.push([
          m.monthYear,
          '',
          formatCurrency(loan.installmentAmount),
          formatCurrency(0),
          getFrenchStatus(PaymentStatus.NOT_PAID)
        ]);
      }
    });

    autoTable(doc, {
      startY: currentY,
      head: [['Mois', 'Date', 'Mensualité', 'Collecté', 'Statut']],
      body: tableData,
      theme: 'grid',
      styles: { font: 'helvetica', halign: 'left', fontSize: 8 },
      didParseCell: (data) => {
        if (data.section === 'body' && data.column.index === 4) {
          const statusText = data.cell.text[0];
          if (statusText.includes('Bleu')) data.cell.styles.fillColor = [52, 152, 219];
          if (statusText.includes('Vert')) data.cell.styles.fillColor = [46, 204, 113];
          if (statusText.includes('Rouge')) data.cell.styles.fillColor = [231, 76, 60];
          if (statusText.includes('Jaune')) data.cell.styles.fillColor = [241, 196, 15];
        }
      }
    });

    currentY = (doc as any).lastAutoTable.finalY + 15;
  });

  doc.setFontSize(8);
  doc.text('Note: Le mois de mensualité est déterminé par la date de prélèvement. Les prélèvements jusqu\'au 02 du mois sont considérés pour le mois précédent.', 105, 285, { align: 'center' });

  doc.save(`Fiche_Client_${customer.customerAccount}.pdf`);
};

export const exportStopListToPDF = (summaries: CustomerSummary[]) => {
  const stopList = summaries.filter(s => s.isStopList);
  const doc = new jsPDF('p', 'mm', 'a4');
  const dateStr = new Date().toLocaleDateString('fr-FR');

  doc.setFontSize(18);
  doc.text('Liste d\'Arrêt (Stop List)', 105, 15, { align: 'center' });
  doc.text(`Date d'émission: ${dateStr}`, 10, 25);

  const tableData = stopList.map(s => [
    s.customerAccount,
    s.customerName,
    formatCurrency(s.totalCollected),
    formatCurrency(s.totalExpected),
    s.completionDate || '---',
    s.isOverpaid ? 'Trop-perçu' : 'Fin de mensualités'
  ]);

  autoTable(doc, {
    startY: 35,
    head: [['Compte', 'Nom', 'Collecté', 'Attendu', 'Date Fin', 'Raison']],
    body: tableData,
    theme: 'grid',
    styles: { font: 'helvetica', halign: 'left' },
    headStyles: { fillColor: [192, 57, 43] }
  });

  doc.setFontSize(8);
  doc.text('Note: Le mois de mensualité est déterminé par la date de prélèvement. Les prélèvements jusqu\'au 02 du mois sont considérés pour le mois précédent.', 105, 285, { align: 'center' });

  doc.save(`Liste_Arret.pdf`);
};

export const exportStopListToExcel = async (summaries: CustomerSummary[]) => {
  const stopList = summaries.filter(s => s.isStopList);
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Liste d\'Arrêt');

  worksheet.columns = [
    { header: 'Numéro de Compte', key: 'account', width: 15 },
    { header: 'Nom du Client', key: 'name', width: 30 },
    { header: 'Total Attendu', key: 'expected', width: 15 },
    { header: 'Total Collecté', key: 'collected', width: 15 },
    { header: 'Date d\'Achèvement', key: 'date', width: 15 },
    { header: 'Raison', key: 'reason', width: 20 }
  ];

  stopList.forEach(s => {
    const row = worksheet.addRow({
      account: s.customerAccount,
      name: s.customerName,
      expected: s.totalExpected,
      collected: s.totalCollected,
      date: s.completionDate || '---',
      reason: s.isOverpaid ? 'Trop-perçu' : 'Fin de mensualités'
    });

    if (s.isOverpaid) {
      row.getCell('reason').font = { color: { argb: 'FFFF0000' }, bold: true };
    }
  });

  worksheet.addRow([]);
  worksheet.addRow(['Note: Le mois de mensualité est déterminé par la date de prélèvement. Les prélèvements jusqu\'au 02 du mois sont considérés pour le mois précédent.']).font = { italic: true, size: 10 };

  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Liste_Arret.xlsx`;
  a.click();
};

export const exportCustomerInstallmentMatrixToExcel = async (
  customer: CustomerSummary,
  matrix: any[]
) => {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Tableau de Suivi');

  worksheet.columns = [
    { header: 'Mensualité', key: 'month', width: 20 },
    { header: 'Période', key: 'period', width: 15 },
    { header: 'Date de Prélèvement', key: 'date', width: 20 },
    { header: 'Montant', key: 'amount', width: 15 },
    { header: 'Statut', key: 'status', width: 25 },
    { header: 'Référence', key: 'ref', width: 25 }
  ];

  matrix.forEach(m => {
    const row = worksheet.addRow({
      month: `Mensualité ${m.index}`,
      period: m.monthYear,
      date: m.data?.records[0]?.installmentDate || '---',
      amount: m.data ? m.data.installmentAmount : 0,
      status: m.status === 'paid' ? 'Payé (Bleu)' : m.status === 'late' ? 'Payé (Vert)' : m.status === 'unpaid' ? 'Non payé (Rouge)' : m.status === 'overpaid' ? 'Trop-perçu (Jaune)' : 'En attente',
      ref: m.data?.records[0]?.fullReference || '---'
    });

    if (m.status === 'paid') row.getCell('status').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF3498DB' } }; // Blue
    if (m.status === 'late') row.getCell('status').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF2ECC71' } }; // Green
    if (m.status === 'unpaid') row.getCell('status').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE74C3C' } }; // Red
    if (m.status === 'overpaid') row.getCell('status').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF1C40F' } }; // Yellow
  });

  worksheet.addRow([]);
  worksheet.addRow(['Note: Le mois de mensualité est déterminé par la date de prélèvement. Les prélèvements jusqu\'au 02 du mois sont considérés pour le mois précédent.']).font = { italic: true, size: 10 };

  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Suivi_Mensualites_${customer.customerAccount}.xlsx`;
  a.click();
};

export const exportCustomerInstallmentMatrixToPDF = (
  customer: CustomerSummary,
  matrix: any[]
) => {
  const doc = new jsPDF('l', 'mm', 'a4');
  const dateStr = new Date().toLocaleDateString('fr-FR');

  doc.setFontSize(18);
  doc.text('Tableau de Suivi des Mensualités - Algérie Poste', 148, 15, { align: 'center' });

  doc.setFontSize(12);
  doc.text(`Client: ${customer.customerName}`, 10, 25);
  doc.text(`Compte: ${customer.customerAccount}`, 10, 32);

  const tableData: any[][] = [];
  matrix.forEach(m => {
    if (m.data && m.data.records.length > 0) {
      m.data.records.forEach((record: any) => {
        const { status: recStatus } = getStatusFromCode(record.statusCode);
        let displayStatus = recStatus;
        
        if (recStatus === PaymentStatus.PAID_ON_TIME) {
          const [rd, rm, ry] = record.installmentDate.split('/').map(Number);
          const instDate = new Date(ry, rm - 1, rd);
          
          let resMonth: number, resYear: number;
          if (record.deductionMonth && record.deductionYear) {
            resMonth = parseInt(record.deductionMonth, 10);
            resYear = parseInt(record.deductionYear, 10);
          } else {
            if (rd <= 2) {
              resMonth = rm;
              resYear = ry;
            } else {
              const next = new Date(ry, rm, 1);
              resMonth = next.getMonth() + 1;
              resYear = next.getFullYear();
            }
          }
          
          const limitDate = new Date(resYear, resMonth - 1, 2);
          displayStatus = instDate <= limitDate ? PaymentStatus.PAID_ON_TIME : PaymentStatus.PAID_LATE;
        }
        tableData.push([
          `Mensualité ${m.index}`,
          m.monthYear,
          record.installmentDate,
          formatCurrency(record.installmentAmount),
          displayStatus === PaymentStatus.PAID_ON_TIME ? 'Payé (Bleu)' : displayStatus === PaymentStatus.PAID_LATE ? 'Payé (Vert)' : 'Échec'
        ]);
      });
    } else {
      tableData.push([
        `Mensualité ${m.index}`,
        m.monthYear,
        '---',
        '---',
        m.status === 'unpaid' ? 'Échec (Rouge)' : 'En attente'
      ]);
    }
  });

  autoTable(doc, {
    startY: 50,
    head: [['N°', 'Période', 'Date', 'Montant', 'Statut']],
    body: tableData,
    theme: 'grid',
    styles: { font: 'helvetica', halign: 'left' },
    didParseCell: (data) => {
      if (data.section === 'body' && data.column.index === 4) {
        const statusText = data.cell.text[0];
        if (statusText.includes('Bleu')) data.cell.styles.fillColor = [52, 152, 219];
        if (statusText.includes('Vert')) data.cell.styles.fillColor = [46, 204, 113];
        if (statusText.includes('Rouge')) data.cell.styles.fillColor = [231, 76, 60];
        if (statusText.includes('Jaune')) data.cell.styles.fillColor = [241, 196, 15];
      }
    }
  });

  doc.setFontSize(8);
  doc.text('Note: Le mois de mensualité est déterminé par la date de prélèvement. Les prélèvements jusqu\'au 02 du mois sont considérés pour le mois précédent.', 148, 200, { align: 'center' });

  doc.save(`Suivi_Mensualites_${customer.customerAccount}.pdf`);
};
