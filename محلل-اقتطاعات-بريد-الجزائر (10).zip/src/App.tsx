import React, { useState, useEffect, useMemo } from 'react';
import { FileUpload } from './components/FileUpload';
import { Dashboard } from './components/Dashboard';
import { CustomerTable } from './components/CustomerTable';
import { CustomerDetails } from './components/CustomerDetails';
import { MonthlyInstallmentTracker } from './components/MonthlyInstallmentTracker';
import { CustomerMonitoring } from './components/CustomerMonitoring';
import { MonthlyGlobalSummary } from './components/MonthlyGlobalSummary';
import { MonthlyInstallmentSummary } from './components/MonthlyInstallmentSummary';
import { TaxesDashboard } from './components/TaxesDashboard';
import { ZakatModule } from './components/ZakatModule';
import { CustomerInstallmentsManager } from './components/CustomerInstallmentsManager';
import { IDCardPrint } from './components/IDCardPrint';
import { PostalCheckPrint } from './components/PostalCheckPrint';
import { ReferenceChecker } from './components/ReferenceChecker';
import { CustomerDetailedReport } from './components/CustomerDetailedReport';
import { CodeAnalysisTool } from './components/CodeAnalysisTool';
import { ScrollIndicator } from './components/ScrollIndicator';
import { ErrorBoundary } from './components/ErrorBoundary';
import { RawRecord, CustomerSummary, GlobalStats, PaymentStatus, CustomerConfig, Language } from './types';
import { processRecords } from './utils/analyzer';
import { saveRecords, getAllRecords, clearAllData, getCustomerConfigs, saveCustomerConfig } from './services/db';
import { getStatusFromCode } from './utils/parser';
import { LayoutDashboard, Users, FileStack, Settings, Trash2, Download, Search, Table2, AlertCircle, FileText, Globe, Calendar, CreditCard, Table, Eye, Receipt, Calculator, ClipboardCheck } from 'lucide-react';
import { FilterBar } from './components/FilterBar';
import { exportFullDatabaseToExcel, exportStopListToExcel, exportStopListToPDF } from './utils/reports';
import { useTranslation } from './utils/translations';

export default function App() {
  const [records, setRecords] = useState<RawRecord[]>([]);
  const [summaries, setSummaries] = useState<CustomerSummary[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerSummary | null>(null);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'customers' | 'upload' | 'tracking' | 'monitoring' | 'monthly' | 'monthly-summary' | 'taxes' | 'zakat' | 'installments' | 'stop-report' | 'id-card' | 'postal-check' | 'reference-checker' | 'customer-report' | 'code-analysis'>('dashboard');
  const [searchTerm, setSearchTerm] = useState('');
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState('');
  const [activeFilter, setActiveFilter] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem('app_lang');
    return (saved as Language) || 'fr';
  });

  const [configs, setConfigs] = useState<Record<string, CustomerConfig>>({});

  const t = useTranslation(language);

  useEffect(() => {
    localStorage.setItem('app_lang', language);
    document.dir = language === 'ar' ? 'rtl' : 'ltr';
  }, [language]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  useEffect(() => {
    async function loadInitialData() {
      try {
        const [storedRecords, storedConfigs] = await Promise.all([
          getAllRecords(),
          getCustomerConfigs()
        ]);
        
        setConfigs(storedConfigs);
        if (storedRecords.length > 0) {
          setRecords(storedRecords);
          const processed = processRecords(storedRecords, storedConfigs);
          setSummaries(processed);
        }
      } catch (err) {
        console.error("Failed to load data from DB", err);
      } finally {
        setIsLoading(false);
      }
    }
    loadInitialData();
  }, []);

  const handleDataLoaded = async (newRecords: RawRecord[]) => {
    setIsLoading(true);
    try {
      await saveRecords(newRecords);
      const allRecords = await getAllRecords();
      const storedConfigs = await getCustomerConfigs();
      
      setConfigs(storedConfigs);
      setRecords(allRecords);
      const processed = processRecords(allRecords, storedConfigs);
      setSummaries(processed);
      setActiveTab('dashboard');
    } catch (err) {
      console.error("Error during data loading:", err);
      alert(language === 'ar' ? "حدث خطأ أثناء دمج البيانات." : "Une erreur est survenue lors de l'intégration des données.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearData = async () => {
    try {
      await clearAllData();
      setRecords([]);
      setSummaries([]);
      setConfigs({});
      setActiveTab('upload');
      setShowDeleteConfirm(false);
    } catch (err) {
      console.error("Failed to clear data", err);
      alert(t.unknown);
    }
  };

  const handleUpdateConfig = async (account: string, reference: string | null, config: CustomerConfig) => {
    const key = reference ? `${account}|${reference}` : account;
    await saveCustomerConfig(key, config);
    const storedConfigs = await getCustomerConfigs();
    setConfigs(storedConfigs);
    const processed = processRecords(records, storedConfigs);
    setSummaries(processed);
  };

  const stats = useMemo<GlobalStats>(() => {
    const totalExpectedAmount = Number(summaries.reduce((acc, s) => acc + s.totalExpected, 0).toFixed(2));
    const totalCollectedAmount = Number(summaries.reduce((acc, s) => acc + s.totalCollected, 0).toFixed(2));
    const totalNotCollectedAmount = Number(summaries.reduce((acc, s) => acc + s.totalNotCollected, 0).toFixed(2));
    const totalRemainingAmount = Number(summaries.reduce((acc, s) => acc + s.totalRemaining, 0).toFixed(2));
    
    let totalPaid = 0;
    let totalUnpaid = 0;
    let validInstallments = 0;
    let invalidInstallments = 0;

    records.forEach(r => {
      if (r.isValid) {
        validInstallments++;
        const { status } = getStatusFromCode(r.statusCode);
        if (status === PaymentStatus.PAID_ON_TIME || status === PaymentStatus.PAID_LATE) {
          totalPaid++;
        } else if (status === PaymentStatus.NOT_PAID || status === PaymentStatus.MONITORING_FAILURE) {
          totalUnpaid++;
        }
      } else {
        invalidInstallments++;
      }
    });

    return {
      totalCustomers: summaries.length,
      totalInstallments: records.length,
      validInstallments,
      invalidInstallments,
      totalPaid,
      totalUnpaid,
      totalExpectedAmount,
      totalCollectedAmount,
      totalNotCollectedAmount,
      totalRemainingAmount,
      rawCollectedAmount: totalCollectedAmount,
      stopListCount: summaries.filter(s => s.isStopList).length,
      overdueCount1Month: summaries.filter(s => s.overdueMonths === 1).length,
      overdueCount2PlusMonths: summaries.filter(s => s.overdueMonths >= 2).length,
    };
  }, [summaries, records]);

  const filteredSummaries = useMemo(() => {
    return summaries.filter(s => {
      const matchesSearch = s.customerName.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
                           s.customerAccount.includes(debouncedSearchTerm);
      
      if (!activeFilter) return matchesSearch;

      if (activeFilter === "STOP_LIST") {
        return matchesSearch && s.isStopList;
      }

      const lastRecord = s.records[s.records.length - 1];
      if (!lastRecord) return false;
      const { status } = getStatusFromCode(lastRecord.statusCode);
      return matchesSearch && status === activeFilter;
    });
  }, [summaries, debouncedSearchTerm, activeFilter]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-zinc-50 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-zinc-500 font-medium">{t.loading}</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen bg-zinc-50 flex flex-col lg:flex-row ${language === 'ar' ? 'font-arabic' : ''}`}>
      {/* Sidebar */}
      <aside className="w-full lg:w-72 bg-white border-r border-zinc-200 flex flex-col h-auto lg:h-screen sticky top-0 z-40">
        <div className="p-8 border-b border-zinc-100">
          <div className="flex items-center gap-3 text-emerald-600 mb-2">
            <div className="bg-emerald-600 text-white p-2 rounded-xl shadow-lg shadow-emerald-200">
              <FileStack size={24} />
            </div>
            <h1 className="text-xl font-black tracking-tight text-zinc-900">{t.appName}</h1>
          </div>
          <p className="text-xs text-zinc-400 font-medium">{t.appDescription}</p>
        </div>

        <nav className="flex-1 p-4 space-y-2 overflow-y-auto scrollbar-hide">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold text-sm
              ${activeTab === 'dashboard' ? 'bg-emerald-50 text-emerald-700' : 'text-zinc-500 hover:bg-zinc-50 hover:text-zinc-800'}`}
          >
            <LayoutDashboard size={20} />
            {t.dashboard}
          </button>
          <button
            onClick={() => setActiveTab('customers')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold text-sm
              ${activeTab === 'customers' ? 'bg-emerald-50 text-emerald-700' : 'text-zinc-500 hover:bg-zinc-50 hover:text-zinc-800'}`}
          >
            <Users size={20} />
            {t.customers}
          </button>
          <button
            onClick={() => setActiveTab('tracking')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold text-sm
              ${activeTab === 'tracking' ? 'bg-emerald-50 text-emerald-700' : 'text-zinc-500 hover:bg-zinc-50 hover:text-zinc-800'}`}
          >
            <Table2 size={20} />
            {t.tracking}
          </button>
          <button
            onClick={() => setActiveTab('monitoring')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold text-sm
              ${activeTab === 'monitoring' ? 'bg-emerald-50 text-emerald-700' : 'text-zinc-500 hover:bg-zinc-50 hover:text-zinc-800'}`}
          >
            <Eye size={20} />
            {t.customerMonitoring}
          </button>
          <button
            onClick={() => setActiveTab('monthly')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold text-sm
              ${activeTab === 'monthly' ? 'bg-emerald-50 text-emerald-700' : 'text-zinc-500 hover:bg-zinc-50 hover:text-zinc-800'}`}
          >
            <Calendar size={20} />
            {language === 'ar' ? 'النتائج الشهرية' : 'Résultats Mensuels'}
          </button>
          <button
            onClick={() => setActiveTab('customer-report')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold text-sm
              ${activeTab === 'customer-report' ? 'bg-emerald-50 text-emerald-700' : 'text-zinc-500 hover:bg-zinc-50 hover:text-zinc-800'}`}
          >
            <FileText size={20} />
            {t.customerReport}
          </button>
          <button
            onClick={() => setActiveTab('monthly-summary')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold text-sm
              ${activeTab === 'monthly-summary' ? 'bg-emerald-50 text-emerald-700' : 'text-zinc-500 hover:bg-zinc-50 hover:text-zinc-800'}`}
          >
            <Table size={20} />
            {t.monthlyInstallmentSummary}
          </button>
          <button
            onClick={() => setActiveTab('taxes')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold text-sm
              ${activeTab === 'taxes' ? 'bg-emerald-50 text-emerald-700' : 'text-zinc-500 hover:bg-zinc-50 hover:text-zinc-800'}`}
          >
            <Receipt size={20} />
            {t.taxes}
          </button>
          <button
            onClick={() => setActiveTab('zakat')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold text-sm
              ${activeTab === 'zakat' ? 'bg-emerald-50 text-emerald-700' : 'text-zinc-500 hover:bg-zinc-50 hover:text-zinc-800'}`}
          >
            <Calculator size={20} />
            {t.zakat}
          </button>
          <button
            onClick={() => setActiveTab('installments')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold text-sm
              ${activeTab === 'installments' ? 'bg-emerald-50 text-emerald-700' : 'text-zinc-500 hover:bg-zinc-50 hover:text-zinc-800'}`}
          >
            <CreditCard size={20} />
            {t.customerInstallments}
          </button>
          <button
            onClick={() => setActiveTab('stop-report')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold text-sm
              ${activeTab === 'stop-report' ? 'bg-emerald-50 text-emerald-700' : 'text-zinc-500 hover:bg-zinc-50 hover:text-zinc-800'}`}
          >
            <AlertCircle size={20} />
            {t.stopReport}
          </button>
          <button
            onClick={() => setActiveTab('id-card')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold text-sm
              ${activeTab === 'id-card' ? 'bg-emerald-50 text-emerald-700' : 'text-zinc-500 hover:bg-zinc-50 hover:text-zinc-800'}`}
          >
            <CreditCard size={20} />
            {t.idCardPrint}
          </button>
          <button
            onClick={() => setActiveTab('postal-check')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold text-sm
              ${activeTab === 'postal-check' ? 'bg-emerald-50 text-emerald-700' : 'text-zinc-500 hover:bg-zinc-50 hover:text-zinc-800'}`}
          >
            <Table size={20} />
            {t.postalCheckPrint}
          </button>
          <button
            onClick={() => setActiveTab('reference-checker')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold text-sm
              ${activeTab === 'reference-checker' ? 'bg-emerald-50 text-emerald-700' : 'text-zinc-500 hover:bg-zinc-50 hover:text-zinc-800'}`}
          >
            <Search size={20} />
            {t.referenceChecker}
          </button>
          <button
            onClick={() => setActiveTab('code-analysis')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold text-sm
              ${activeTab === 'code-analysis' ? 'bg-emerald-50 text-emerald-700' : 'text-zinc-500 hover:bg-zinc-50 hover:text-zinc-800'}`}
          >
            <ClipboardCheck size={20} />
            {t.codeAnalysis}
          </button>
          <button
            onClick={() => setActiveTab('upload')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold text-sm
              ${activeTab === 'upload' ? 'bg-emerald-50 text-emerald-700' : 'text-zinc-500 hover:bg-zinc-50 hover:text-zinc-800'}`}
          >
            <FileStack size={20} />
            {t.upload}
          </button>
        </nav>

        <div className="p-4 border-t border-zinc-100 space-y-2">
          <div className="flex items-center gap-2 mb-4 px-4">
            <Globe size={16} className="text-zinc-400" />
            <div className="flex bg-zinc-100 rounded-lg p-1 w-full">
              <button
                onClick={() => setLanguage('ar')}
                className={`flex-1 py-1 text-[10px] font-bold rounded-md transition-all ${language === 'ar' ? 'bg-white text-emerald-600 shadow-sm' : 'text-zinc-500'}`}
              >
                العربية
              </button>
              <button
                onClick={() => setLanguage('fr')}
                className={`flex-1 py-1 text-[10px] font-bold rounded-md transition-all ${language === 'fr' ? 'bg-white text-emerald-600 shadow-sm' : 'text-zinc-500'}`}
              >
                Français
              </button>
            </div>
          </div>
          
          <button
            onClick={() => setShowDeleteConfirm(true)}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-500 hover:bg-red-50 transition-all font-bold text-sm"
          >
            <Trash2 size={20} />
            {t.clearData}
          </button>
          <div className="p-4 bg-zinc-50 rounded-2xl border border-zinc-100">
            <p className="text-[10px] text-zinc-400 uppercase tracking-widest font-bold mb-2">{t.systemStatus}</p>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
              <p className="text-xs font-bold text-zinc-600">{t.connected}</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-4 lg:p-10 max-w-7xl mx-auto w-full">
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-10">
          <div>
            <h2 className="text-3xl font-black text-zinc-900">
              {activeTab === 'dashboard' && t.overview}
              {activeTab === 'customers' && t.customerManagement}
              {activeTab === 'tracking' && t.installmentTracking}
              {activeTab === 'monitoring' && t.customerMonitoring}
              {activeTab === 'monthly' && (language === 'ar' ? 'النتائج الشهرية' : 'Résultats Mensuels')}
              {activeTab === 'customer-report' && t.customerReport}
              {activeTab === 'monthly-summary' && t.monthlyInstallmentSummary}
              {activeTab === 'taxes' && t.taxes}
              {activeTab === 'zakat' && t.zakat}
              {activeTab === 'installments' && t.customerInstallments}
              {activeTab === 'stop-report' && t.stopReportTitle}
              {activeTab === 'id-card' && t.idCardPrint}
              {activeTab === 'postal-check' && t.postalCheckPrint}
              {activeTab === 'reference-checker' && t.referenceChecker}
              {activeTab === 'code-analysis' && t.codeAnalysis}
              {activeTab === 'upload' && t.importReports}
            </h2>
            <p className="text-zinc-500 mt-1">
              {activeTab === 'dashboard' && t.statsFinancial}
              {activeTab === 'customers' && `${t.totalCustomers}: ${summaries.length}`}
              {activeTab === 'tracking' && t.installmentTracking}
              {activeTab === 'monitoring' && (language === 'ar' ? 'نظام مراقبة متقدم لتتبع حالة دفع الزبائن' : 'Système de monitoring avancé pour suivre l\'état de paiement des clients')}
              {activeTab === 'monthly' && (language === 'ar' ? 'تجميع الاقتطاعات حسب الشهر والسنة' : 'Groupement des déductions par mois et année')}
              {activeTab === 'customer-report' && (language === 'ar' ? 'تقرير مفصل لجميع أقساط الزبون وحالة الدفع' : 'Rapport détaillé de toutes les mensualités du client et de l\'état de paiement')}
              {activeTab === 'monthly-summary' && (language === 'ar' ? 'تجميع الأقساط حسب تاريخ الدفع لكل زبون' : 'Groupement des versements par date de paiement pour chaque client')}
              {activeTab === 'taxes' && (language === 'ar' ? 'حساب الضرائب التلقائي بناءً على دخل التأخير' : 'Calcul automatique des taxes basé sur le revenu de retard')}
              {activeTab === 'zakat' && (language === 'ar' ? 'حساب وعاء الزكاة بناءً على الأقساط المتبقية في الحول' : 'Calcul de la base de la Zakat selon les mensualités restantes dans le Hawl')}
              {activeTab === 'stop-report' && t.stopListDesc}
              {activeTab === 'id-card' && (language === 'ar' ? 'توليد صفحة A4 تحتوي على 10 بطاقات هوية' : 'Générer une page A4 contenant 10 cartes d\'identité')}
              {activeTab === 'postal-check' && (language === 'ar' ? 'توليد صفحة A4 تحتوي على 6 صكوك بريدية' : 'Générer une page A4 contenant 6 chèques postaux')}
              {activeTab === 'reference-checker' && (language === 'ar' ? 'تدقيق المراجع عبر قاعدة البيانات العالمية' : 'Vérifier les références à travers la base de données globale')}
              {activeTab === 'code-analysis' && t.codeAnalysisDesc}
              {activeTab === 'upload' && t.importReports}
            </p>
          </div>

          <div className="flex items-center gap-3">
            {activeTab === 'customers' && (
              <div className="relative">
                <Search className={`absolute ${language === 'ar' ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2 text-zinc-400`} size={18} />
                <input
                  type="text"
                  placeholder={t.searchPlaceholder}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className={`${language === 'ar' ? 'pr-10 pl-4' : 'pl-10 pr-4'} py-2 bg-white border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all w-64 text-sm`}
                />
              </div>
            )}
            <button
              onClick={() => exportFullDatabaseToExcel(summaries)}
              disabled={summaries.length === 0}
              className="flex items-center gap-2 px-5 py-2 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100 disabled:opacity-50 disabled:shadow-none text-sm"
            >
              <Download size={18} />
              {t.exportExcel}
            </button>
          </div>
        </header>

        <div className="space-y-10">
          {activeTab === 'dashboard' && (
            <>
              {summaries.length > 0 ? (
                <Dashboard stats={stats} summaries={summaries} language={language} />
              ) : (
                <div className="bg-white border border-zinc-200 rounded-3xl p-20 text-center space-y-4">
                  <div className="bg-zinc-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto text-zinc-300">
                    <FileStack size={40} />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-xl font-bold text-zinc-800">{t.noData}</h3>
                    <p className="text-zinc-500 max-w-xs mx-auto">{t.importPrompt}</p>
                  </div>
                  <button
                    onClick={() => setActiveTab('upload')}
                    className="px-8 py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-all"
                  >
                    {t.goToImport}
                  </button>
                </div>
              )}
            </>
          )}

          {activeTab === 'customers' && (
            <div className="space-y-6">
              <FilterBar activeFilter={activeFilter} onFilterChange={setActiveFilter} language={language} />
              <CustomerTable 
                summaries={filteredSummaries} 
                onSelectCustomer={setSelectedCustomer} 
                language={language}
              />
            </div>
          )}

          {activeTab === 'tracking' && (
            <ErrorBoundary message={language === 'ar' ? 'تعذر تحميل تتبع الأقساط' : 'Impossible de charger le suivi des mensualités'}>
              <MonthlyInstallmentTracker 
                summaries={summaries} 
                onUpdateConfig={handleUpdateConfig}
                language={language}
              />
            </ErrorBoundary>
          )}

          {activeTab === 'monitoring' && (
            <ErrorBoundary message={language === 'ar' ? 'تعذر تحميل مراقبة الزبائن' : 'Impossible de charger le monitoring des clients'}>
              <CustomerMonitoring 
                summaries={summaries} 
                onUpdateConfig={handleUpdateConfig}
                onDataLoaded={handleDataLoaded}
                language={language}
              />
            </ErrorBoundary>
          )}

          {activeTab === 'monthly' && (
            <MonthlyGlobalSummary summaries={summaries} language={language} />
          )}

          {activeTab === 'customer-report' && (
            <CustomerDetailedReport language={language} />
          )}

          {activeTab === 'monthly-summary' && (
            <MonthlyInstallmentSummary summaries={summaries} language={language} />
          )}

          {activeTab === 'taxes' && (
            <TaxesDashboard summaries={summaries} language={language} />
          )}

          {activeTab === 'zakat' && (
            <ZakatModule language={language} />
          )}

          {activeTab === 'installments' && (
            <CustomerInstallmentsManager
              summaries={summaries}
              configs={configs}
              onUpdateConfig={handleUpdateConfig}
              language={language}
            />
          )}

          {activeTab === 'stop-report' && (
            <div className="bg-white border border-zinc-200 rounded-3xl overflow-hidden shadow-sm">
              <div className="p-6 border-b border-zinc-100 bg-zinc-50/50 flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-bold text-zinc-900 flex items-center gap-2">
                    <AlertCircle className="text-red-500" size={20} />
                    {t.stopListTitle}
                  </h3>
                  <p className="text-sm text-zinc-500">{t.stopListDesc}</p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => exportStopListToExcel(summaries)}
                    className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-xl font-bold text-xs hover:bg-emerald-700 transition-all"
                  >
                    <Download size={14} />
                    Excel
                  </button>
                  <button
                    onClick={() => exportStopListToPDF(summaries)}
                    className="flex items-center gap-2 px-4 py-2 bg-zinc-800 text-white rounded-xl font-bold text-xs hover:bg-zinc-900 transition-all"
                  >
                    <FileText size={14} />
                    PDF
                  </button>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-zinc-50 text-zinc-500 text-xs uppercase tracking-wider font-bold">
                      <th className="px-6 py-4">{t.accountNumber}</th>
                      <th className="px-6 py-4">{t.customerName}</th>
                      <th className="px-6 py-4">{t.installment}</th>
                      <th className="px-6 py-4">{t.totalExpected}</th>
                      <th className="px-6 py-4">{t.totalCollected}</th>
                      <th className="px-6 py-4">{t.endDate}</th>
                      <th className="px-6 py-4">{t.realEndDate}</th>
                      <th className="px-6 py-4">{t.status}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-100">
                    {summaries.filter(s => s.isStopList).map(s => (
                      <tr key={s.customerAccount} className="hover:bg-zinc-50 transition-colors">
                        <td className="px-6 py-4 font-mono text-sm text-zinc-600">{s.customerAccount}</td>
                        <td className="px-6 py-4 font-bold text-zinc-900">{s.customerName}</td>
                        <td className="px-6 py-4 text-emerald-600 font-bold">{(s.loans.reduce((sum, l) => sum + l.installmentAmount, 0)).toLocaleString()} DZD</td>
                        <td className="px-6 py-4 text-zinc-600">{s.totalExpected.toLocaleString()} DZD</td>
                        <td className="px-6 py-4 text-emerald-700 font-bold">{s.totalCollected.toLocaleString()} DZD</td>
                        <td className="px-6 py-4 text-zinc-500">{s.loans.length > 0 ? s.loans[0].endDate : '---'}</td>
                        <td className="px-6 py-4 text-zinc-500">{s.completionDate || '---'}</td>
                        <td className="px-6 py-4">
                          <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-xs font-bold">
                            {t.toStop}
                          </span>
                        </td>
                      </tr>
                    ))}
                    {summaries.filter(s => s.isStopList).length === 0 && (
                      <tr>
                        <td colSpan={8} className="px-6 py-20 text-center text-zinc-400">
                          {t.noData}
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'id-card' && (
            <IDCardPrint language={language} />
          )}

          {activeTab === 'postal-check' && (
            <PostalCheckPrint language={language} />
          )}

          {activeTab === 'reference-checker' && (
            <ReferenceChecker language={language} />
          )}

          {activeTab === 'code-analysis' && (
            <CodeAnalysisTool language={language} />
          )}

          {activeTab === 'upload' && (
            <div className="max-w-2xl mx-auto">
              <FileUpload onDataLoaded={handleDataLoaded} language={language} />
            </div>
          )}
        </div>
      </main>

      {selectedCustomer && (
        <CustomerDetails 
          customer={selectedCustomer} 
          onClose={() => setSelectedCustomer(null)} 
          onUpdateConfig={handleUpdateConfig}
          language={language}
        />
      )}

      {showDeleteConfirm && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl p-8 space-y-6 animate-in zoom-in-95 duration-200">
            <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto text-red-600">
              <Trash2 size={32} />
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-xl font-bold text-zinc-900">{t.confirmDelete}</h3>
              <p className="text-zinc-500">{t.deleteWarning}</p>
            </div>
            <div className="flex flex-col gap-3">
              <button
                onClick={handleClearData}
                className="w-full py-3 bg-red-600 text-white rounded-xl font-bold hover:bg-red-700 transition-all"
              >
                {t.yesDelete}
              </button>
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="w-full py-3 bg-zinc-100 text-zinc-600 rounded-xl font-bold hover:bg-zinc-200 transition-all"
              >
                {t.cancel}
              </button>
            </div>
          </div>
        </div>
      )}

      <ScrollIndicator language={language} />
    </div>
  );
}
