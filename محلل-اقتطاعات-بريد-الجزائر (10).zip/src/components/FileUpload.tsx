import React, { useState, useCallback, useRef } from 'react';
import { Upload, FileText, AlertCircle, CheckCircle2, Loader2, Clipboard, Settings2, X } from 'lucide-react';
import { parseTxtLine, parseRecord, createInvalidRecord } from '../utils/parser';
import { RawRecord } from '../types';
import * as XLSX from 'xlsx';
import { motion, AnimatePresence } from 'motion/react';

interface FileUploadProps {
  onDataLoaded: (records: RawRecord[]) => void;
  language: 'ar' | 'fr';
}

type Encoding = 'utf-8' | 'windows-1256' | 'iso-8859-1';

interface ImportSummary {
  total: number;
  imported: number;
  success: number;
  failed: number;
  customers: number;
  errors: string[];
}

export const FileUpload: React.FC<FileUploadProps> = ({ onDataLoaded, language }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isParsing, setIsParsing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [summary, setSummary] = useState<ImportSummary | null>(null);
  const [encoding, setEncoding] = useState<Encoding>('utf-8');
  const [resultMonth, setResultMonth] = useState<string>(String(new Date().getMonth() + 1).padStart(2, '0'));
  const [resultYear, setResultYear] = useState<string>(String(new Date().getFullYear()));
  const [pasteText, setPasteText] = useState('');
  const [showPaste, setShowPaste] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processData = useCallback(async (data: any[], fileName: string, overrideMonth?: string, overrideYear?: string) => {
    setIsParsing(true);
    setProgress(0);
    setError(null);
    setSummary(null);

    const total = data.length;
    const records: RawRecord[] = [];
    const errors: string[] = [];
    let successCount = 0;
    let failedCount = 0;
    
    const CHUNK_SIZE = 2000;

    try {
      for (let i = 0; i < total; i += CHUNK_SIZE) {
        const chunk = data.slice(i, i + CHUNK_SIZE);
        for (let j = 0; j < chunk.length; j++) {
          const item = chunk[j];
          const globalIndex = i + j;
          let record: RawRecord | null = null;
          
          if (typeof item === 'string') {
            record = parseTxtLine(item, fileName, overrideMonth, overrideYear, globalIndex);
            if (!record) {
              record = createInvalidRecord(fileName, globalIndex);
              failedCount++;
              if (errors.length < 10) {
                errors.push(`Ligne ${globalIndex + 1}: Format non reconnu`);
              }
            } else {
              successCount++;
            }
          } else {
            record = parseRecord(item, fileName, overrideMonth, overrideYear, globalIndex);
            if (!record) {
              record = createInvalidRecord(fileName, globalIndex);
              failedCount++;
              if (errors.length < 10) {
                errors.push(`Enregistrement ${globalIndex + 1}: Données manquantes`);
              }
            } else {
              successCount++;
            }
          }

          if (record) {
            records.push(record);
          }
        }
        
        setProgress(Math.min(100, Math.round(((i + CHUNK_SIZE) / total) * 100)));
        await new Promise(resolve => setTimeout(resolve, 0));
      }

      const uniqueCustomers = new Set(records.filter(r => r.isValid).map(r => r.customerAccount));

      setSummary({
        total,
        imported: records.length,
        success: successCount,
        failed: failedCount,
        customers: uniqueCustomers.size,
        errors
      });

      if (records.length > 0) {
        onDataLoaded(records);
      } else {
        setError("Aucune donnée valide n'a été trouvée dans le fichier.");
      }
    } catch (err) {
      setError("Une erreur est survenue lors du traitement des données.");
    } finally {
      setIsParsing(false);
    }
  }, [onDataLoaded]);

  const handleFile = async (file: File) => {
    const extension = file.name.split('.').pop()?.toLowerCase();
    
    if (extension === 'xlsx' || extension === 'xls') {
      const reader = new FileReader();
      reader.onload = (e) => {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const workbookSheet = workbook.Sheets[firstSheetName];
        const jsonData = XLSX.utils.sheet_to_json(workbookSheet);
        processData(jsonData, file.name, resultMonth, resultYear);
      };
      reader.readAsArrayBuffer(file);
    } else {
      // TXT or CSV
      const reader = new FileReader();
      reader.onload = (e) => {
        const buffer = e.target?.result as ArrayBuffer;
        const decoder = new TextDecoder(encoding);
        const text = decoder.decode(buffer);
        const lines = text.split(/\r?\n/);
        processData(lines, file.name, resultMonth, resultYear);
      };
      reader.readAsArrayBuffer(file);
    }
  };

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFile(files[0]);
    }
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      handleFile(files[0]);
    }
  };

  const handlePasteSubmit = () => {
    if (pasteText.trim()) {
      const lines = pasteText.split(/\r?\n/);
      processData(lines, "Texte collé", resultMonth, resultYear);
      setShowPaste(false);
      setPasteText('');
    }
  };

  return (
    <div className="w-full space-y-6">
      {/* Import Settings */}
      <div className="bg-white border border-zinc-200 rounded-3xl p-6 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-emerald-100 p-3 rounded-2xl text-emerald-600">
              <Settings2 size={24} />
            </div>
            <div>
              <p className="text-lg font-black text-zinc-800">
                {language === 'ar' ? 'إعدادات الاستيراد' : 'Paramètres d\'importation'}
              </p>
              <p className="text-sm text-zinc-500">
                {language === 'ar' ? 'اختر شهر النتائج والترميز' : 'Sélectionnez le mois des résultats et l\'encodage'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2 bg-zinc-50 p-1.5 rounded-2xl border border-zinc-200">
              <span className="text-xs font-bold text-zinc-400 px-2 uppercase tracking-wider">
                {language === 'ar' ? 'شهر النتائج' : 'Mois des résultats'}
              </span>
              <select 
                value={resultMonth}
                onChange={(e) => setResultMonth(e.target.value)}
                className="bg-white border border-zinc-200 rounded-xl px-3 py-2 text-sm font-bold text-zinc-700 outline-none focus:ring-2 focus:ring-emerald-500"
              >
                {Array.from({ length: 12 }, (_, i) => {
                  const m = String(i + 1).padStart(2, '0');
                  return <option key={m} value={m}>{m}</option>;
                })}
              </select>
              <select 
                value={resultYear}
                onChange={(e) => setResultYear(e.target.value)}
                className="bg-white border border-zinc-200 rounded-xl px-3 py-2 text-sm font-bold text-zinc-700 outline-none focus:ring-2 focus:ring-emerald-500"
              >
                {Array.from({ length: 5 }, (_, i) => {
                  const y = String(new Date().getFullYear() - 2 + i);
                  return <option key={y} value={y}>{y}</option>;
                })}
              </select>
            </div>

            <div className="flex items-center gap-2 bg-zinc-50 p-1.5 rounded-2xl border border-zinc-200">
              <span className="text-xs font-bold text-zinc-400 px-2 uppercase tracking-wider">
                {language === 'ar' ? 'الترميز' : 'Encodage'}
              </span>
              <select
                value={encoding}
                onChange={(e) => setEncoding(e.target.value as Encoding)}
                className="bg-white border border-zinc-200 rounded-xl px-3 py-2 text-sm font-bold text-zinc-700 outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="utf-8">UTF-8</option>
                <option value="windows-1256">Windows-1256</option>
                <option value="iso-8859-1">ISO-8859-1</option>
              </select>
            </div>
          </div>
        </div>
        
        <div className="bg-amber-50 border border-amber-100 rounded-2xl p-4 flex items-start gap-3">
          <AlertCircle size={20} className="text-amber-600 shrink-0 mt-0.5" />
          <p className="text-sm text-amber-800">
            {language === 'ar' 
              ? 'تذكير: نتائج شهر مارس تمثل اقتطاعات شهر فيفري. يرجى اختيار الشهر المكتوب على الملف.' 
              : 'Rappel : Les résultats de Mars représentent les déductions de Février. Sélectionnez le mois indiqué sur le fichier.'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div
          onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={onDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`relative border-2 border-dashed rounded-3xl p-10 transition-all flex flex-col items-center justify-center space-y-4 cursor-pointer
            ${isDragging ? 'border-emerald-500 bg-emerald-50' : 'border-zinc-300 hover:border-emerald-400 hover:bg-zinc-50'}`}
        >
          <input
            type="file"
            ref={fileInputRef}
            accept=".txt,.csv,.xls,.xlsx"
            onChange={onFileChange}
            className="hidden"
          />
          <div className="bg-emerald-100 p-5 rounded-full text-emerald-600">
            <Upload size={40} />
          </div>
          <div className="text-center">
            <p className="text-lg font-black text-zinc-800">Importer un fichier</p>
            <p className="text-sm text-zinc-500">TXT, CSV, XLS, XLSX</p>
          </div>
        </div>

        <div
          onClick={() => setShowPaste(true)}
          className="border-2 border-dashed border-zinc-300 rounded-3xl p-10 hover:border-emerald-400 hover:bg-zinc-50 transition-all flex flex-col items-center justify-center space-y-4 cursor-pointer"
        >
          <div className="bg-blue-100 p-5 rounded-full text-blue-600">
            <Clipboard size={40} />
          </div>
          <div className="text-center">
            <p className="text-lg font-black text-zinc-800">Coller du texte</p>
            <p className="text-sm text-zinc-500">Copier-coller depuis un rapport</p>
          </div>
        </div>
      </div>

      {showPaste && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl p-8 space-y-6"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-black text-zinc-900">Coller le contenu du rapport</h3>
              <button onClick={() => setShowPaste(false)} className="text-zinc-400 hover:text-zinc-600 p-2 hover:bg-zinc-100 rounded-full transition-colors">
                <X size={24} />
              </button>
            </div>
            <textarea
              value={pasteText}
              onChange={(e) => setPasteText(e.target.value)}
              placeholder="Collez ici les lignes du rapport Algérie Poste..."
              className="w-full h-64 p-4 bg-zinc-50 border border-zinc-200 rounded-2xl font-mono text-sm outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
            />
            <div className="flex gap-3">
              <button
                onClick={handlePasteSubmit}
                disabled={!pasteText.trim() || isParsing}
                className="flex-1 py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isParsing ? <Loader2 size={20} className="animate-spin" /> : null}
                Analyser le texte
              </button>
              <button
                onClick={() => setShowPaste(false)}
                className="px-6 py-3 bg-zinc-100 text-zinc-600 rounded-xl font-bold hover:bg-zinc-200 transition-all"
              >
                Annuler
              </button>
            </div>
          </motion.div>
        </div>
      )}

      <AnimatePresence>
        {isParsing && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm space-y-4"
          >
            <div className="flex items-center justify-between text-sm font-bold">
              <span className="flex items-center gap-3 text-zinc-700">
                <Loader2 size={20} className="animate-spin text-emerald-500" />
                Traitement des données en cours...
              </span>
              <span className="text-emerald-600">{progress}%</span>
            </div>
            <div className="w-full bg-zinc-100 rounded-full h-3 overflow-hidden">
              <motion.div
                className="bg-emerald-500 h-full shadow-[0_0_10px_rgba(16,185,129,0.5)]"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.3 }}
              />
            </div>
          </motion.div>
        )}

        {error && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-red-50 border border-red-200 text-red-700 p-5 rounded-2xl flex items-start gap-4"
          >
            <AlertCircle size={24} className="shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-bold">Erreur d'importation</p>
              <p className="text-sm opacity-90">{error}</p>
            </div>
          </motion.div>
        )}

        {summary && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-white border border-zinc-200 rounded-3xl p-6 shadow-sm space-y-6"
          >
            <div className="flex items-center gap-4 border-b border-zinc-100 pb-4">
              <div className="bg-emerald-100 p-3 rounded-2xl text-emerald-600">
                <CheckCircle2 size={24} />
              </div>
              <div>
                <h3 className="text-lg font-black text-zinc-900">Importation terminée</h3>
                <p className="text-sm text-zinc-500">Résumé du traitement du fichier</p>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-zinc-50 p-4 rounded-2xl border border-zinc-100 text-center">
                <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider mb-1">Lignes dans le fichier</p>
                <p className="text-2xl font-black text-zinc-800">{summary.total}</p>
              </div>
              <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-100 text-center">
                <p className="text-[10px] text-emerald-600 font-bold uppercase tracking-wider mb-1">Mensualités importées</p>
                <p className="text-2xl font-black text-emerald-700">{summary.imported}</p>
              </div>
              <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100 text-center">
                <p className="text-[10px] text-blue-600 font-bold uppercase tracking-wider mb-1">Clients détectés</p>
                <p className="text-2xl font-black text-blue-700">{summary.customers}</p>
              </div>
              <div className="bg-amber-50 p-4 rounded-2xl border border-amber-100 text-center">
                <p className="text-[10px] text-amber-600 font-bold uppercase tracking-wider mb-1">Alertes/Erreurs</p>
                <p className="text-2xl font-black text-amber-700">{summary.failed}</p>
              </div>
            </div>

            {summary.errors.length > 0 && (
              <div className="space-y-3">
                <p className="text-xs font-bold text-zinc-400 uppercase tracking-wider">Détails des erreurs (Top 10)</p>
                <div className="bg-zinc-50 rounded-2xl p-4 border border-zinc-100 max-h-40 overflow-y-auto">
                  <ul className="space-y-2">
                    {summary.errors.map((err, idx) => (
                      <li key={idx} className="text-xs text-red-600 flex items-center gap-2">
                        <AlertCircle size={12} />
                        {err}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
