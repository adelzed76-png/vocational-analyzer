import React, { useState, useRef } from 'react';
import { Language } from '../types';
import { useTranslation } from '../utils/translations';
import { CreditCard, Printer, Download, Eye, Upload, X, FileImage, Scissors } from 'lucide-react';
import jsPDF from 'jspdf';

interface IDCardPrintProps {
  language: Language;
}

export const IDCardPrint: React.FC<IDCardPrintProps> = ({ language }) => {
  const t = useTranslation(language);
  const isRtl = language === 'ar';
  
  const [frontImage, setFrontImage] = useState<string | null>(null);
  const [backImage, setBackImage] = useState<string | null>(null);
  const [isPreviewMode, setIsPreviewMode] = useState(false);

  const frontInputRef = useRef<HTMLInputElement>(null);
  const backInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, side: 'front' | 'back') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          if (side === 'front') setFrontImage(event.target.result as string);
          else setBackImage(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePrint = () => {
    if (!isReady) return;
    setIsPreviewMode(false);
    // Ensure the browser has time to switch out of preview mode if needed
    // though the @media print CSS handles the actual visibility.
    setTimeout(() => {
      window.print();
    }, 150);
  };

  const handleDownloadPDF = () => {
    if (!frontImage && !backImage) return;

    const doc = new jsPDF('p', 'mm', 'a4');
    const pageWidth = 210;
    const pageHeight = 297;
    
    // High-density dimensions for 5x2 grid with minimal margins
    const margin = 3;
    const gap = 2.5;
    const cardW = 100.5; 
    const cardH = 56;

    doc.setDrawColor(180, 180, 180);
    doc.setLineWidth(0.1); 
    doc.setLineDashPattern([2, 2], 0);

    for (let row = 0; row < 5; row++) {
      const y = margin + (row * (cardH + gap));
      
      // Front side (Left column)
      const xFront = margin;
      if (frontImage) {
        doc.addImage(frontImage, 'JPEG', xFront, y, cardW, cardH, undefined, 'FAST');
      } else {
        doc.rect(xFront, y, cardW, cardH);
        doc.setFontSize(8);
        doc.text('FRONT', xFront + cardW/2, y + cardH/2, { align: 'center' });
      }
      doc.rect(xFront, y, cardW, cardH);

      // Back side (Right column)
      const xBack = margin + cardW + gap;
      if (backImage) {
        doc.addImage(backImage, 'JPEG', xBack, y, cardW, cardH, undefined, 'FAST');
      } else {
        doc.rect(xBack, y, cardW, cardH);
        doc.setFontSize(8);
        doc.text('BACK', xBack + cardW/2, y + cardH/2, { align: 'center' });
      }
      doc.rect(xBack, y, cardW, cardH);
    }

    // Horizontal Cutting Guides
    for (let i = 1; i < 5; i++) {
      const y = margin + (i * cardH) + (i - 0.5) * gap;
      doc.line(0, y, pageWidth, y);
    }

    // Vertical Cutting Guide
    const midX = margin + cardW + (gap / 2);
    doc.line(midX, 0, midX, pageHeight);

    doc.save('ID_Cards_HighDensity_Portrait.pdf');
  };

  const isReady = frontImage || backImage;

  return (
    <div className="space-y-6 pb-20">
      {/* Controls - Hidden on Print */}
      <div className="bg-white border border-zinc-200 rounded-3xl p-6 shadow-sm space-y-6 no-print">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="bg-indigo-100 p-3 rounded-2xl text-indigo-600">
              <CreditCard size={24} />
            </div>
            <div>
              <h2 className="text-xl font-bold text-zinc-900">{t.idCardPrint}</h2>
              <p className="text-sm text-zinc-500">{language === 'ar' ? 'رفع الصور لتوليد صفحة A4 تحتوي على 10 بطاقات' : 'Uploadez les images pour générer une page A4 de 10 cartes'}</p>
            </div>
          </div>
          
          {isReady && (
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsPreviewMode(!isPreviewMode)}
                className="flex items-center gap-2 px-4 py-2 bg-zinc-100 text-zinc-700 rounded-xl font-bold text-xs hover:bg-zinc-200 transition-all"
              >
                <Eye size={14} />
                {language === 'ar' ? 'معاينة' : 'Preview'}
              </button>
              <button
                onClick={handleDownloadPDF}
                className="flex items-center gap-2 px-4 py-2 bg-zinc-800 text-white rounded-xl font-bold text-xs hover:bg-zinc-900 transition-all"
              >
                <Download size={14} />
                PDF
              </button>
              <button
                onClick={handlePrint}
                className="flex items-center gap-2 px-6 py-2 bg-indigo-600 text-white rounded-xl font-bold text-xs hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200"
              >
                <Printer size={14} />
                {language === 'ar' ? 'طباعة' : 'Print'}
              </button>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Front Side Upload */}
          <div 
            onClick={() => frontInputRef.current?.click()}
            className={`relative group cursor-pointer border-2 border-dashed rounded-3xl p-8 transition-all flex flex-col items-center justify-center gap-4 ${frontImage ? 'border-emerald-200 bg-emerald-50/30' : 'border-zinc-200 hover:border-indigo-300 hover:bg-indigo-50/30'}`}
          >
            <input 
              type="file" 
              ref={frontInputRef} 
              className="hidden" 
              accept="image/*,.pdf" 
              onChange={(e) => handleFileChange(e, 'front')} 
            />
            {frontImage ? (
              <>
                <div className="relative w-full aspect-[1.586/1] rounded-xl overflow-hidden shadow-md border border-emerald-100">
                  <img src={frontImage} alt="Front" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Upload className="text-white" size={32} />
                  </div>
                </div>
                <div className="flex items-center gap-2 text-emerald-700 font-bold text-sm">
                  <FileImage size={18} />
                  {t.uploadIdFront}
                </div>
              </>
            ) : (
              <>
                <div className="w-16 h-16 bg-zinc-100 rounded-2xl flex items-center justify-center text-zinc-400 group-hover:text-indigo-500 group-hover:bg-white transition-all">
                  <Upload size={32} />
                </div>
                <div className="text-center">
                  <p className="font-bold text-zinc-700">{t.uploadIdFront}</p>
                  <p className="text-xs text-zinc-400 mt-1">JPG, PNG, PDF</p>
                </div>
              </>
            )}
          </div>

          {/* Back Side Upload */}
          <div 
            onClick={() => backInputRef.current?.click()}
            className={`relative group cursor-pointer border-2 border-dashed rounded-3xl p-8 transition-all flex flex-col items-center justify-center gap-4 ${backImage ? 'border-emerald-200 bg-emerald-50/30' : 'border-zinc-200 hover:border-indigo-300 hover:bg-indigo-50/30'}`}
          >
            <input 
              type="file" 
              ref={backInputRef} 
              className="hidden" 
              accept="image/*,.pdf" 
              onChange={(e) => handleFileChange(e, 'back')} 
            />
            {backImage ? (
              <>
                <div className="relative w-full aspect-[1.586/1] rounded-xl overflow-hidden shadow-md border border-emerald-100">
                  <img src={backImage} alt="Back" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Upload className="text-white" size={32} />
                  </div>
                </div>
                <div className="flex items-center gap-2 text-emerald-700 font-bold text-sm">
                  <FileImage size={18} />
                  {t.uploadIdBack}
                </div>
              </>
            ) : (
              <>
                <div className="w-16 h-16 bg-zinc-100 rounded-2xl flex items-center justify-center text-zinc-400 group-hover:text-indigo-500 group-hover:bg-white transition-all">
                  <Upload size={32} />
                </div>
                <div className="text-center">
                  <p className="font-bold text-zinc-700">{t.uploadIdBack}</p>
                  <p className="text-xs text-zinc-400 mt-1">JPG, PNG, PDF</p>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Layout Preview / Print View */}
      {isReady && (
        <div className={`${isPreviewMode ? 'block' : 'hidden print:block'} bg-white border border-zinc-200 shadow-xl mx-auto w-fit relative overflow-hidden`}>
          <style dangerouslySetInnerHTML={{ __html: `
            @media print {
              body * { visibility: hidden; }
              .print-area, .print-area * { visibility: visible; }
              .print-area { 
                position: absolute; 
                left: 0; 
                top: 0; 
                width: 210mm; 
                height: 297mm; 
                padding: 0; 
                margin: 0;
                background: white; 
              }
              .no-print { display: none !important; }
              @page {
                size: A4 portrait;
                margin: 0;
              }
            }
            .id-card-grid {
              display: grid;
              grid-template-columns: 100.5mm 100.5mm;
              grid-template-rows: repeat(5, 56mm);
              gap: 2.5mm;
              width: 210mm;
              height: 297mm;
              padding: 3mm;
              position: relative;
              background: #f8fafc;
              justify-content: center;
              align-content: center;
            }
            .id-card-item {
              width: 100.5mm;
              height: 56mm;
              position: relative;
              overflow: hidden;
              border: 0.2mm dashed #cbd5e1;
              background: white;
              display: flex;
              align-items: center;
              justify-content: center;
              box-shadow: 0 1mm 3mm rgba(0,0,0,0.05);
            }
            .id-card-item img {
              width: 100%;
              height: 100%;
              object-fit: contain;
            }
            .id-card-placeholder {
              display: flex;
              flex-direction: column;
              align-items: center;
              justify-content: center;
              gap: 2mm;
              color: #94a3b8;
            }
            .guide-line-h {
              position: absolute;
              left: 0;
              right: 0;
              height: 0;
              border-top: 0.2mm dashed #94a3b8;
              z-index: 20;
              pointer-events: none;
            }
            .guide-line-v {
              position: absolute;
              top: 0;
              bottom: 0;
              width: 0;
              border-left: 0.2mm dashed #94a3b8;
              z-index: 20;
              pointer-events: none;
            }
            .safe-margin-box {
              position: absolute;
              top: 3mm;
              bottom: 3mm;
              left: 3mm;
              right: 3mm;
              border: 0.1mm solid rgba(79, 70, 229, 0.1);
              pointer-events: none;
              z-index: 0;
            }
          `}} />
          
          <div className="print-area">
            <div className="id-card-grid">
              <div className="safe-margin-box" />
              
              {/* Vertical Guide Line */}
              <div className="guide-line-v" style={{ left: '105mm' }} />
              
              {/* Horizontal Guide Lines */}
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="guide-line-h" style={{ top: `${3 + i * 56 + (i - 0.5) * 2.5}mm` }} />
              ))}
              
              {[...Array(5)].map((_, i) => (
                <React.Fragment key={i}>
                  {/* Front Side */}
                  <div className="id-card-item">
                    {frontImage ? (
                      <img src={frontImage} alt="Front" />
                    ) : (
                      <div className="id-card-placeholder">
                        <CreditCard size={40} strokeWidth={1} />
                        <span className="text-[9pt] font-medium uppercase tracking-widest opacity-50">Front Side</span>
                      </div>
                    )}
                  </div>
                  
                  {/* Back Side */}
                  <div className="id-card-item">
                    {backImage ? (
                      <img src={backImage} alt="Back" />
                    ) : (
                      <div className="id-card-placeholder">
                        <CreditCard size={40} strokeWidth={1} />
                        <span className="text-[9pt] font-medium uppercase tracking-widest opacity-50">Back Side</span>
                      </div>
                    )}
                  </div>
                </React.Fragment>
              ))}
            </div>
          </div>

          {/* Floating Instruction Overlay for Preview */}
          {isPreviewMode && (
            <div className="absolute top-4 right-4 bg-indigo-600 text-white px-4 py-2 rounded-full text-xs font-bold shadow-lg flex items-center gap-2 no-print">
              <Scissors size={14} />
              {language === 'ar' ? 'معاينة التخطيط والقص' : 'Aperçu de la mise en page et découpe'}
            </div>
          )}
        </div>
      )}

      {!isReady && (
        <div className="bg-zinc-50 border border-zinc-200 rounded-3xl p-12 text-center space-y-4">
          <div className="bg-white w-16 h-16 rounded-2xl flex items-center justify-center mx-auto text-zinc-300 shadow-sm">
            <CreditCard size={32} />
          </div>
          <div className="space-y-1">
            <h3 className="font-bold text-zinc-800">{language === 'ar' ? 'بانتظار الصور' : 'En attente des images'}</h3>
            <p className="text-sm text-zinc-500 max-w-xs mx-auto">
              {language === 'ar' ? 'يرجى رفع وجه وظهر بطاقة الهوية لتوليد صفحة الطباعة.' : 'Veuillez uploader le recto et le verso de la carte ID pour générer la page d\'impression.'}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
