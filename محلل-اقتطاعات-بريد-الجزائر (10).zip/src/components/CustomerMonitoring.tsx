import React, { useState, useMemo, useRef } from 'react';
import { CustomerSummary, Language, PaymentStatus, LoanSummary, CustomerConfig, RawRecord } from '../types';
import { formatCurrency } from '../utils/formatters';
import { Calendar, Users, TrendingUp, AlertCircle, Search, ArrowLeft, Hash, DollarSign, Clock, ShieldAlert, Ban, Upload, FileText, CheckCircle2, XCircle } from 'lucide-react';
import * as XLSX from 'xlsx';
import { parseTxtLine } from '../utils/parser';

interface CustomerMonitoringProps {
  summaries: CustomerSummary[];
  onUpdateConfig: (account: string, reference: string | null, config: CustomerConfig) => void;
  onDataLoaded: (records: RawRecord[]) => void;
  language: Language;
}

export const CustomerMonitoring: React.FC<CustomerMonitoringProps> = ({ summaries, onUpdateConfig, onDataLoaded, language }) => {
  const [view, setView] = useState<'search' | 'details'>('search');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCustomerAccount, setSelectedCustomerAccount] = useState<string | null>(null);
  
  // Global Config State
  const [isEditingGlobal, setIsEditingGlobal] = useState(false);
  const [globalDuration, setGlobalDuration] = useState(12);
  const [globalStartDate, setGlobalStartDate] = useState('');

  // Individual Config State
  const [editingLoanRef, setEditingLoanRef] = useState<string | null>(null);
  const [individualDuration, setIndividualDuration] = useState(12);
  const [individualStartDate, setIndividualStartDate] = useState('');

  const [individualEndDate, setIndividualEndDate] = useState('');
  const [error, setError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [showPasteModal, setShowPasteModal] = useState(false);
  const [pastedText, setPastedText] = useState('');

  const isRtl = language === 'ar';

  const filteredCustomers = useMemo(() => {
    if (!searchQuery.trim()) return summaries.slice(0, 10);
    const query = searchQuery.toLowerCase();
    return summaries.filter(c => 
      c.customerName.toLowerCase().includes(query) || 
      c.customerAccount.includes(query)
    ).slice(0, 20);
  }, [summaries, searchQuery]);

  const selectedCustomer = useMemo(() => {
    return summaries.find(c => c.customerAccount === selectedCustomerAccount);
  }, [summaries, selectedCustomerAccount]);

  const monthSummaries = useMemo(() => {
    if (!selectedCustomer) return {};
    const summary: Record<string, { total: number; paidOnTime: number; paidLate: number; unpaid: number; paidAmount: number; unpaidAmount: number }> = {};
    selectedCustomer.loans.forEach(loan => {
      loan.monthlyBreakdown.forEach(month => {
        if (!summary[month.monthYear]) {
          summary[month.monthYear] = { total: 0, paidOnTime: 0, paidLate: 0, unpaid: 0, paidAmount: 0, unpaidAmount: 0 };
        }
        summary[month.monthYear].total++;
        summary[month.monthYear].paidOnTime += month.paidOnTimeCount;
        summary[month.monthYear].paidLate += month.paidLateCount;
        summary[month.monthYear].unpaid += month.unpaidCount;
        summary[month.monthYear].paidAmount += month.totalPaidAmount;
        summary[month.monthYear].unpaidAmount += month.totalUnpaidAmount;
      });
    });
    return summary;
  }, [selectedCustomer]);

  const isUnderMonitoring = useMemo(() => selectedCustomer?.loans.some(l => l.records.some(r => r.statusCode === "100")), [selectedCustomer]);
  const isFrozen = useMemo(() => selectedCustomer?.loans.some(l => l.records.some(r => r.statusCode === "200")), [selectedCustomer]);
  const isMonitoringFailure = useMemo(() => selectedCustomer?.loans.some(l => l.records.some(r => ["126", "127", "226", "227"].includes(r.statusCode))), [selectedCustomer]);

  const financialStats = useMemo(() => {
    if (!selectedCustomer) return null;
    try {
      return {
        totalExpectedAmount: selectedCustomer.loans.reduce((sum, l) => sum + l.totalExpected, 0),
        totalCollectedAmount: selectedCustomer.loans.reduce((sum, l) => sum + l.totalCollected, 0),
        totalRemainingAmount: selectedCustomer.loans.reduce((sum, l) => sum + l.totalRemaining, 0),
        totalInstallments: selectedCustomer.loans.reduce((sum, l) => sum + l.installmentDuration, 0),
        totalPaidInstallments: selectedCustomer.loans.reduce((sum, l) => sum + l.monthsPaid, 0),
        totalUnpaidInstallments: selectedCustomer.loans.reduce((sum, l) => sum + l.monthsMissed, 0),
      };
    } catch (e) {
      console.error("Error calculating financial stats", e);
      return null;
    }
  }, [selectedCustomer]);

  const currentMonthStats = useMemo(() => {
    if (!selectedCustomer) return null;
    try {
      const now = new Date();
      const currentMonthKey = `${String(now.getMonth() + 1).padStart(2, '0')} / ${now.getFullYear()}`;
      return selectedCustomer.loans.reduce((acc, loan) => {
        const month = loan.monthlyBreakdown.find(m => m.monthYear === currentMonthKey);
        if (month) {
          acc.expected += month.installmentAmount;
          acc.collected += month.collectedAmount;
          acc.remaining += month.notCollectedAmount;
        }
        return acc;
      }, { expected: 0, collected: 0, remaining: 0, key: currentMonthKey });
    } catch (e) {
      console.error("Error calculating current month stats", e);
      return null;
    }
  }, [selectedCustomer]);

  const handleSelectCustomer = (account: string) => {
    try {
      setSelectedCustomerAccount(account);
      setView('details');
      const customer = summaries.find(c => c.customerAccount === account);
      if (customer && customer.loans.length > 0) {
        setGlobalDuration(customer.loans[0].installmentDuration || 12);
        setGlobalStartDate(customer.loans[0].startDate || '');
      }
    } catch (e) {
      console.error("Error selecting customer", e);
      setError("Erreur lors de la sélection du client");
    }
  };

  const handleSaveGlobalConfig = () => {
    if (selectedCustomerAccount) {
      onUpdateConfig(selectedCustomerAccount, null, {
        duration: globalDuration,
        startDate: globalStartDate
      });
      setIsEditingGlobal(false);
    }
  };

  const handleEditIndividual = (loan: LoanSummary) => {
    setEditingLoanRef(loan.fullReference);
    setIndividualDuration(loan.installmentDuration || 12);
    setIndividualStartDate(loan.startDate || '');
    setIndividualEndDate(loan.endDate || '');
  };

  const handleSaveIndividualConfig = (loanRef: string) => {
    if (selectedCustomerAccount) {
      onUpdateConfig(selectedCustomerAccount, loanRef, {
        duration: individualDuration,
        startDate: individualStartDate,
        endDate: individualEndDate
      });
      setEditingLoanRef(null);
    }
  };

  const getStatusColor = (statusCode: string) => {
    if (statusCode === "000") return "bg-blue-600"; // Blue - On time
    // Rule 1: 001 to 027 are late payments (string comparison)
    if (statusCode >= "001" && statusCode <= "027") {
      return "bg-emerald-600"; // Green - Late
    }
    // Rule 3: All other codes are Not Paid (Red)
    return "bg-red-600"; 
  };

  const getStatusText = (statusCode: string) => {
    if (statusCode === "000") return language === 'ar' ? 'مسدد في الوقت' : 'Payé à temps';
    // Rule 1: 001 to 027 are late payments (string comparison)
    if (statusCode >= "001" && statusCode <= "027") {
      return language === 'ar' ? 'مسدد متأخر' : 'Payé en retard';
    }
    // Rule 3: All other codes are Not Paid
    return language === 'ar' ? 'غير مسدد' : 'Non payé';
  };

  const monthNamesFrench = ["Jan", "Fév", "Mar", "Avr", "Mai", "Jun", "Jul", "Aoû", "Sep", "Oct", "Nov", "Déc"];
  const monthNamesArabic = ["جانفي", "فيفري", "مارس", "أفريل", "ماي", "جوان", "جويلية", "أوت", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];

  const formatMonth = (monthYear: string) => {
    const [m, y] = monthYear.split(' / ').map(Number);
    return language === 'ar' ? `${monthNamesArabic[m - 1]} ${y}` : `${monthNamesFrench[m - 1]} ${y}`;
  };

  const handlePasteResults = () => {
    if (!pastedText.trim()) return;
    
    const lines = pastedText.split('\n');
    const allNewRecords: RawRecord[] = [];
    
    lines.forEach(line => {
      if (line.trim()) {
        const record = parseTxtLine(line, 'Pasted Content');
        if (record) allNewRecords.push(record);
      }
    });

    if (allNewRecords.length > 0) {
      onDataLoaded(allNewRecords);
    }
    
    setPastedText('');
    setShowPasteModal(false);
  };
  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);
    const allNewRecords: RawRecord[] = [];

    for (const file of Array.from(files)) {
      const extension = file.name.split('.').pop()?.toLowerCase();

      if (extension === 'txt' || extension === 'csv') {
        const text = await file.text();
        const lines = text.split('\n');
        lines.forEach(line => {
          if (line.trim()) {
            const record = parseTxtLine(line, file.name);
            if (record) allNewRecords.push(record);
          }
        });
      } else if (extension === 'xls' || extension === 'xlsx') {
        const data = await file.arrayBuffer();
        const workbook = XLSX.read(data);
        const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
        const jsonData = XLSX.utils.sheet_to_json(firstSheet);
        // Map Excel data to RawRecord if needed, for now we rely on the TXT parser logic
      }
    }

    if (allNewRecords.length > 0) {
      onDataLoaded(allNewRecords);
    }
    setIsUploading(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const renderTrackingTable = (loan: LoanSummary) => {
    return (
      <div className="mt-4 overflow-x-auto pb-4">
        <div className="flex gap-2 min-w-max">
          {loan.monthlyBreakdown.map((month, idx) => {
            const hasPaidOnTime = month.paidOnTimeCount > 0;
            const hasPaidLate = month.paidLateCount > 0;
            const hasUnpaid = month.unpaidCount > 0;
            
            let bgColor = "bg-zinc-100";
            if (hasPaidOnTime) bgColor = "bg-blue-600";
            else if (hasPaidLate) bgColor = "bg-emerald-600";
            else if (hasUnpaid) bgColor = "bg-red-600";

            return (
              <div key={idx} className="flex flex-col items-center gap-1">
                <div 
                  className={`w-10 h-10 rounded-xl ${bgColor} shadow-sm flex items-center justify-center text-[10px] font-black text-white cursor-help transition-transform hover:scale-110`}
                  title={`${formatMonth(month.monthYear)}: ${hasPaidOnTime ? 'Payé à temps' : hasPaidLate ? 'Payé en retard' : 'Non payé'}`}
                >
                  {month.monthYear.split(' / ')[0]}
                </div>
                <span className="text-[8px] font-bold text-zinc-400">{month.monthYear.split(' / ')[1].slice(-2)}</span>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  if (view === 'details') {
    if (!selectedCustomer) {
      return (
        <div className="bg-white border border-zinc-200 rounded-[2.5rem] p-20 text-center space-y-6 shadow-xl">
          <div className="bg-zinc-50 w-24 h-24 rounded-full flex items-center justify-center mx-auto text-zinc-300">
            <Users size={48} />
          </div>
          <div className="space-y-2">
            <h3 className="text-2xl font-black text-zinc-800">
              {language === 'ar' ? 'لم يتم العثور على الزبون' : 'Client non trouvé'}
            </h3>
            <p className="text-zinc-500 max-w-xs mx-auto">
              {language === 'ar' ? 'لا توجد نتائج متاحة لهذا الزبون.' : 'No results available for this customer.'}
            </p>
          </div>
          <button onClick={() => setView('search')} className="px-8 py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-all">
            {language === 'ar' ? 'العودة للبحث' : 'Retour à la recherche'}
          </button>
        </div>
      );
    }

    if (!financialStats || !currentMonthStats) {
      return (
        <div className="bg-red-50 border border-red-200 rounded-[2.5rem] p-20 text-center space-y-6">
          <div className="bg-red-100 w-24 h-24 rounded-full flex items-center justify-center mx-auto text-red-600">
            <AlertCircle size={48} />
          </div>
          <div className="space-y-2">
            <h3 className="text-2xl font-black text-red-800">
              {language === 'ar' ? 'خطأ في تحميل البيانات' : 'Erreur de chargement'}
            </h3>
            <p className="text-red-600 max-w-xs mx-auto">
              {language === 'ar' ? 'حدث خطأ أثناء معالجة بيانات هذا الزبون.' : 'Une erreur est survenue lors du traitement des données de ce client.'}
            </p>
          </div>
          <button onClick={() => setView('search')} className="px-8 py-3 bg-red-600 text-white rounded-xl font-bold hover:bg-red-700 transition-all">
            {language === 'ar' ? 'العودة للبحث' : 'Retour à la recherche'}
          </button>
        </div>
      );
    }

    return (
      <div className="space-y-8 animate-in fade-in duration-500">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <button onClick={() => setView('search')} className="p-3 bg-white border border-zinc-200 rounded-2xl text-zinc-500 hover:text-zinc-900 transition-all hover:shadow-md">
              <ArrowLeft size={24} />
            </button>
            <div>
              <h2 className="text-3xl font-black text-zinc-900 leading-tight">{selectedCustomer.customerName}</h2>
              <p className="text-sm font-bold text-zinc-500 font-mono tracking-wider">{selectedCustomer.customerAccount}</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            {isUnderMonitoring && (
              <div className="flex items-center gap-2 px-4 py-2 bg-amber-100 text-amber-700 rounded-xl border border-amber-200">
                <ShieldAlert size={18} />
                <span className="text-xs font-black uppercase tracking-widest">{language === 'ar' ? 'تحت المراقبة' : 'Sous Surveillance'}</span>
              </div>
            )}
            {isMonitoringFailure && (
              <div className="flex items-center gap-2 px-4 py-2 bg-red-100 text-red-700 rounded-xl border border-red-200">
                <AlertCircle size={18} />
                <span className="text-xs font-black uppercase tracking-widest">{language === 'ar' ? 'فشل المراقبة' : 'Échec Surveillance'}</span>
              </div>
            )}
            {isFrozen && (
              <div className="flex items-center gap-2 px-4 py-2 bg-zinc-900 text-white rounded-xl border border-zinc-800">
                <Ban size={18} />
                <span className="text-xs font-black uppercase tracking-widest">{language === 'ar' ? 'حساب محجور' : 'Compte Bloqué'}</span>
              </div>
            )}
          </div>
        </div>

        {/* Financial Panel */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white border border-zinc-200 rounded-[2rem] p-8 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">{language === 'ar' ? 'إجمالي قيمة العقد' : 'Valeur Totale Contrat'}</p>
              <DollarSign size={20} className="text-emerald-500" />
            </div>
            <p className="text-3xl font-black text-zinc-900">{formatCurrency(financialStats.totalExpectedAmount)}</p>
            <div className="flex items-center gap-2 text-xs font-bold text-zinc-500">
              <Hash size={14} />
              <span>{financialStats.totalInstallments} {language === 'ar' ? 'دفعة إجمالية' : 'total installments'}</span>
            </div>
          </div>

          <div className="bg-emerald-600 rounded-[2rem] p-8 shadow-xl shadow-emerald-100 space-y-4 text-white">
            <div className="flex items-center justify-between">
              <p className="text-[10px] font-black text-emerald-100 uppercase tracking-widest">{language === 'ar' ? 'المبلغ المحصل' : 'Montant Collecté'}</p>
              <CheckCircle2 size={20} className="text-emerald-200" />
            </div>
            <p className="text-3xl font-black">{formatCurrency(financialStats.totalCollectedAmount)}</p>
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-100">
              <Clock size={14} />
              <span>{financialStats.totalPaidInstallments} {language === 'ar' ? 'دفعة مسددة' : 'paid installments'}</span>
            </div>
          </div>

          <div className="bg-zinc-900 rounded-[2rem] p-8 shadow-xl shadow-zinc-200 space-y-4 text-white">
            <div className="flex items-center justify-between">
              <p className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">{language === 'ar' ? 'المبلغ المتبقي' : 'Montant Restant'}</p>
              <AlertCircle size={20} className="text-red-400" />
            </div>
            <p className="text-3xl font-black">{formatCurrency(financialStats.totalRemainingAmount)}</p>
            <div className="flex items-center gap-2 text-xs font-bold text-zinc-500">
              <XCircle size={14} />
              <span>{financialStats.totalUnpaidInstallments} {language === 'ar' ? 'دفعة غير مسددة' : 'unpaid installments'}</span>
            </div>
          </div>
        </div>

        {/* Monthly Comparison */}
        <div className="bg-white border border-zinc-200 rounded-[2rem] p-8 shadow-sm">
          <h3 className="text-xl font-black text-zinc-900 mb-8 flex items-center gap-3">
            <TrendingUp className="text-emerald-600" />
            {language === 'ar' ? 'مقارنة الأداء الشهري' : 'Comparaison de Performance Mensuelle'}
            <span className="text-sm font-bold text-zinc-400 ml-2">({formatMonth(currentMonthStats.key)})</span>
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="space-y-2">
              <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">{language === 'ar' ? 'المتوقع تحصيله' : 'Attendu'}</p>
              <p className="text-2xl font-black text-zinc-900">{formatCurrency(currentMonthStats.expected)}</p>
              <div className="h-2 bg-zinc-100 rounded-full overflow-hidden">
                <div className="h-full bg-zinc-300 w-full" />
              </div>
            </div>
            <div className="space-y-2">
              <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">{language === 'ar' ? 'تم تحصيله' : 'Collecté'}</p>
              <p className="text-2xl font-black text-emerald-600">{formatCurrency(currentMonthStats.collected)}</p>
              <div className="h-2 bg-zinc-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-emerald-500 transition-all duration-1000" 
                  style={{ width: `${currentMonthStats.expected > 0 ? (currentMonthStats.collected / currentMonthStats.expected) * 100 : 0}%` }} 
                />
              </div>
            </div>
            <div className="space-y-2">
              <p className="text-[10px] font-black text-red-600 uppercase tracking-widest">{language === 'ar' ? 'المتبقي' : 'Restant'}</p>
              <p className="text-2xl font-black text-red-600">{formatCurrency(currentMonthStats.remaining)}</p>
              <div className="h-2 bg-zinc-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-red-500 transition-all duration-1000" 
                  style={{ width: `${currentMonthStats.expected > 0 ? (currentMonthStats.remaining / currentMonthStats.expected) * 100 : 0}%` }} 
                />
              </div>
            </div>
          </div>
        </div>

        {/* Global Controls */}
        <div className="bg-white border border-zinc-200 rounded-[2rem] p-8 shadow-sm">
          <div className="flex flex-wrap items-center justify-between gap-8 mb-8">
            <h3 className="text-xl font-black text-zinc-900 flex items-center gap-3">
              <TrendingUp className="text-emerald-600" />
              {language === 'ar' ? 'إعدادات المراقبة العامة' : 'Configuration Globale'}
            </h3>
            
            {!isEditingGlobal ? (
              <div className="flex flex-wrap items-center gap-8">
                <div className="space-y-1">
                  <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">{language === 'ar' ? 'تاريخ البدء العام' : 'Date début globale'}</p>
                  <p className="text-sm font-black text-zinc-800">{selectedCustomer.loans[0]?.startDate || '-'}</p>
                </div>
                <div className="w-px h-8 bg-zinc-100 hidden sm:block" />
                <div className="space-y-1">
                  <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">{language === 'ar' ? 'المدة العامة' : 'Durée globale'}</p>
                  <p className="text-sm font-black text-zinc-800">{selectedCustomer.loans[0]?.installmentDuration || 12} {language === 'ar' ? 'شهر' : 'mois'}</p>
                </div>
                <button onClick={() => setIsEditingGlobal(true)} className="px-6 py-2 bg-zinc-900 text-white rounded-xl text-xs font-black uppercase tracking-widest hover:bg-zinc-800 transition-all">
                  {language === 'ar' ? 'تعديل الكل' : 'Modifier Tout'}
                </button>
              </div>
            ) : (
              <div className="flex flex-wrap items-end gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-zinc-400 uppercase tracking-widest block">{language === 'ar' ? 'تاريخ البدء' : 'Date début'}</label>
                  <input type="text" placeholder="DD/MM/YYYY" value={globalStartDate} onChange={(e) => setGlobalStartDate(e.target.value)} className="bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-2 text-sm font-bold text-zinc-800 outline-none focus:ring-2 focus:ring-emerald-500 w-40" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-zinc-400 uppercase tracking-widest block">{language === 'ar' ? 'المدة' : 'Durée'}</label>
                  <select value={globalDuration} onChange={(e) => setGlobalDuration(Number(e.target.value))} className="bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-2 text-sm font-bold text-zinc-800 outline-none focus:ring-2 focus:ring-emerald-500">
                    {[12, 15, 18, 45, 48, 60].map(d => <option key={d} value={d}>{d} {language === 'ar' ? 'شهر' : 'mois'}</option>)}
                  </select>
                </div>
                <div className="flex gap-2">
                  <button onClick={handleSaveGlobalConfig} className="px-6 py-2 bg-emerald-600 text-white rounded-xl text-xs font-black uppercase tracking-widest hover:bg-emerald-700 transition-all">{language === 'ar' ? 'حفظ الكل' : 'Sauver Tout'}</button>
                  <button onClick={() => setIsEditingGlobal(false)} className="px-6 py-2 bg-zinc-100 text-zinc-600 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-zinc-200 transition-all">{language === 'ar' ? 'إلغاء' : 'Annuler'}</button>
                </div>
              </div>
            )}
          </div>

          <div className="space-y-6">
            {selectedCustomer.loans.map((loan, idx) => (
              <div key={idx} className="bg-zinc-50 border border-zinc-100 rounded-3xl p-6 hover:shadow-md transition-all">
                <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
                  <div className="flex items-center gap-4">
                    <div className="bg-white p-3 rounded-xl text-zinc-400 border border-zinc-100"><Hash size={20} /></div>
                    <div>
                      <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">{language === 'ar' ? 'رقم المرجع' : 'Référence'}</p>
                      <p className="text-lg font-black text-zinc-900 font-mono">{loan.fullReference}</p>
                    </div>
                  </div>
                  
                  {editingLoanRef === loan.fullReference ? (
                    <div className="flex flex-wrap items-end gap-4 bg-white p-4 rounded-2xl border border-zinc-200 shadow-sm">
                      <div className="space-y-1">
                        <label className="text-[9px] font-black text-zinc-400 uppercase tracking-widest block">{language === 'ar' ? 'تاريخ البدء' : 'Début'}</label>
                        <input type="text" value={individualStartDate} onChange={(e) => setIndividualStartDate(e.target.value)} className="bg-zinc-50 border border-zinc-200 rounded-lg px-3 py-1 text-xs font-bold w-28 outline-none focus:ring-1 focus:ring-emerald-500" />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[9px] font-black text-zinc-400 uppercase tracking-widest block">{language === 'ar' ? 'تاريخ الانتهاء' : 'Fin'}</label>
                        <input type="text" value={individualEndDate} onChange={(e) => setIndividualEndDate(e.target.value)} className="bg-zinc-50 border border-zinc-200 rounded-lg px-3 py-1 text-xs font-bold w-28 outline-none focus:ring-1 focus:ring-emerald-500" />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[9px] font-black text-zinc-400 uppercase tracking-widest block">{language === 'ar' ? 'المدة' : 'Durée'}</label>
                        <select value={individualDuration} onChange={(e) => setIndividualDuration(Number(e.target.value))} className="bg-zinc-50 border border-zinc-200 rounded-lg px-3 py-1 text-xs font-bold outline-none focus:ring-1 focus:ring-emerald-500">
                          {[12, 15, 18, 45, 48, 60].map(d => <option key={d} value={d}>{d}</option>)}
                        </select>
                      </div>
                      <div className="flex gap-1">
                        <button onClick={() => handleSaveIndividualConfig(loan.fullReference)} className="p-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-all"><CheckCircle2 size={16} /></button>
                        <button onClick={() => setEditingLoanRef(null)} className="p-2 bg-zinc-100 text-zinc-400 rounded-lg hover:bg-zinc-200 transition-all"><XCircle size={16} /></button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-6">
                      <div className="text-right">
                        <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">{language === 'ar' ? 'تاريخ الانتهاء' : 'Date fin'}</p>
                        <p className="text-sm font-black text-zinc-900">{loan.endDate || '-'}</p>
                      </div>
                      <button onClick={() => handleEditIndividual(loan)} className="px-4 py-2 bg-white border border-zinc-200 text-zinc-600 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-zinc-50 transition-all">
                        {language === 'ar' ? 'تعديل فردي' : 'Modifier'}
                      </button>
                    </div>
                  )}
                </div>
                
                <div className="bg-white p-6 rounded-2xl border border-zinc-100">
                  <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                    <Calendar size={14} className="text-emerald-500" />
                    {language === 'ar' ? 'جدول المراقبة الشهري' : 'Tableau de Monitoring Mensuel'}
                  </p>
                  {renderTrackingTable(loan)}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* All Operations List */}
        <div className="space-y-6">
          <h3 className="text-2xl font-black text-zinc-900 px-2 flex items-center gap-3">
            <FileText className="text-emerald-600" />
            {language === 'ar' ? 'جميع عمليات الدفع' : 'Toutes les opérations de paiement'}
          </h3>
          <div className="bg-white border border-zinc-200 rounded-[2rem] overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-zinc-50 border-b border-zinc-100">
                    <th className="px-6 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest">{language === 'ar' ? 'التاريخ' : 'Date'}</th>
                    <th className="px-6 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest">{language === 'ar' ? 'المبلغ' : 'Montant'}</th>
                    <th className="px-6 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest">{language === 'ar' ? 'المرجع' : 'Référence'}</th>
                    <th className="px-6 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest">{language === 'ar' ? 'الحالة' : 'Statut'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-50">
                  {selectedCustomer.loans.flatMap(l => l.records).sort((a, b) => {
                    const [da, ma, ya] = a.installmentDate.split('/').map(Number);
                    const [db, mb, yb] = b.installmentDate.split('/').map(Number);
                    return new Date(yb, mb - 1, db).getTime() - new Date(ya, ma - 1, da).getTime();
                  }).map((record, idx) => (
                    <tr key={record.id} className="hover:bg-zinc-50 transition-colors">
                      <td className="px-6 py-4 text-sm font-bold text-zinc-600 font-mono">{record.installmentDate}</td>
                      <td className="px-6 py-4 text-sm font-black text-zinc-900">{formatCurrency(record.installmentAmount)}</td>
                      <td className="px-6 py-4 text-sm font-bold text-zinc-500 font-mono">{record.fullReference}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div className={`w-3 h-3 rounded-full ${getStatusColor(record.statusCode)}`} />
                          <span className="text-xs font-black text-zinc-700">{getStatusText(record.statusCode)}</span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Monthly Summary */}
        <div className="grid grid-cols-1 gap-6">
          <h3 className="text-2xl font-black text-zinc-900 px-2">{language === 'ar' ? 'الملخص المالي الشهري' : 'Résumé Financier Mensuel'}</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Object.entries(monthSummaries).sort((a, b) => {
              const [ma, ya] = a[0].split(' / ').map(Number);
              const [mb, yb] = b[0].split(' / ').map(Number);
              return new Date(yb, mb - 1, 1).getTime() - new Date(ya, ma - 1, 1).getTime();
            }).map(([monthYear, stats]) => (
              <div key={monthYear} className="bg-zinc-900 rounded-3xl p-6 shadow-xl shadow-zinc-200 text-white space-y-4">
                <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
                  <div className="flex items-center gap-3">
                    <Calendar size={20} className="text-emerald-400" />
                    <span className="text-lg font-black">{formatMonth(monthYear)}</span>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <p className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">{language === 'ar' ? 'إجمالي الأقساط' : 'Total Échéances'}</p>
                    <p className="text-lg font-black">{stats.total}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest">{language === 'ar' ? 'مسدد في الوقت' : 'Payé à temps'}</p>
                    <p className="text-lg font-black text-blue-400">{stats.paidOnTime}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">{language === 'ar' ? 'مسدد متأخر' : 'Payé en retard'}</p>
                    <p className="text-lg font-black text-emerald-400">{stats.paidLate}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-[10px] font-black text-red-400 uppercase tracking-widest">{language === 'ar' ? 'غير مسدد' : 'Non Payé'}</p>
                    <p className="text-lg font-black text-red-400">{stats.unpaid}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">{language === 'ar' ? 'إجمالي المسدد' : 'Total Payé'}</p>
                    <p className="text-lg font-black text-zinc-100">{stats.paidOnTime + stats.paidLate}</p>
                  </div>
                </div>
                <div className="pt-4 border-t border-zinc-800 grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">{language === 'ar' ? 'المبلغ المحصل' : 'Montant Payé'}</p>
                    <p className="text-sm font-black">{formatCurrency(stats.paidAmount)}</p>
                  </div>
                  <div>
                    <p className="text-[10px] font-black text-red-500 uppercase tracking-widest">{language === 'ar' ? 'المبلغ المتبقي' : 'Montant Restant'}</p>
                    <p className="text-sm font-black">{formatCurrency(stats.unpaidAmount)}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in slide-in-from-bottom-4 duration-500">
      <div className="text-center space-y-4 mb-12">
        <div className="bg-emerald-600 w-20 h-20 rounded-3xl flex items-center justify-center mx-auto text-white shadow-2xl shadow-emerald-200 mb-6">
          <ShieldAlert size={40} />
        </div>
        <h2 className="text-4xl font-black text-zinc-900 tracking-tight">{language === 'ar' ? 'مراقبة الزبائن' : 'Monitoring des Clients'}</h2>
        
        <div className="flex justify-center gap-4 mt-8">
          <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" accept=".txt,.csv,.xls,.xlsx" multiple />
          <button onClick={() => fileInputRef.current?.click()} disabled={isUploading} className="flex items-center gap-3 px-8 py-4 bg-zinc-900 text-white rounded-2xl font-black uppercase tracking-widest hover:bg-zinc-800 transition-all shadow-xl disabled:opacity-50">
            <Upload size={20} />
            {isUploading ? (language === 'ar' ? 'جاري الرفع...' : 'Upload...') : (language === 'ar' ? 'رفع ملف النتائج' : 'Upload File')}
          </button>
          <button onClick={() => setShowPasteModal(true)} className="flex items-center gap-3 px-8 py-4 bg-white border-2 border-zinc-900 text-zinc-900 rounded-2xl font-black uppercase tracking-widest hover:bg-zinc-50 transition-all shadow-xl">
            <FileText size={20} />
            {language === 'ar' ? 'لصق النتائج' : 'Paste Results'}
          </button>
        </div>

        {/* Paste Modal */}
        {showPasteModal && (
          <div className="fixed inset-0 bg-zinc-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-[2.5rem] w-full max-w-2xl p-8 shadow-2xl animate-in zoom-in-95 duration-200">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-black text-zinc-900">{language === 'ar' ? 'لصق نتائج الجزائر بريد' : 'Coller les résultats Algérie Poste'}</h3>
                <button onClick={() => setShowPasteModal(false)} className="p-2 hover:bg-zinc-100 rounded-xl transition-colors">
                  <XCircle size={24} className="text-zinc-400" />
                </button>
              </div>
              <textarea
                value={pastedText}
                onChange={(e) => setPastedText(e.target.value)}
                placeholder={language === 'ar' ? 'الصق الأسطر هنا...' : 'Collez les lignes ici...'}
                className="w-full h-64 bg-zinc-50 border-2 border-zinc-100 rounded-3xl p-6 text-sm font-mono outline-none focus:border-emerald-500 transition-all resize-none"
              />
              <div className="flex gap-4 mt-8">
                <button onClick={handlePasteResults} className="flex-1 py-4 bg-emerald-600 text-white rounded-2xl font-black uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-200">
                  {language === 'ar' ? 'تحليل النتائج' : 'Analyser les résultats'}
                </button>
                <button onClick={() => setShowPasteModal(false)} className="flex-1 py-4 bg-zinc-100 text-zinc-600 rounded-2xl font-black uppercase tracking-widest hover:bg-zinc-200 transition-all">
                  {language === 'ar' ? 'إلغاء' : 'Annuler'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="relative group">
        <div className="absolute inset-y-0 left-6 flex items-center pointer-events-none text-zinc-400 group-focus-within:text-emerald-500 transition-colors">
          <Search size={24} />
        </div>
        <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder={language === 'ar' ? 'ابحث باسم الزبون أو رقم الحساب البريدي...' : 'Rechercher par nom ou compte CCP...'} className="w-full pl-16 pr-8 py-6 bg-white border-2 border-zinc-100 rounded-[2.5rem] text-xl font-bold text-zinc-800 outline-none focus:border-emerald-500 shadow-xl shadow-zinc-200/50 transition-all" />
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filteredCustomers.map((customer) => (
          <button key={customer.customerAccount} onClick={() => handleSelectCustomer(customer.customerAccount)} className="bg-white border border-zinc-200 p-6 rounded-[2rem] flex items-center justify-between hover:border-emerald-500 hover:shadow-lg transition-all group">
            <div className="flex items-center gap-6">
              <div className="bg-zinc-100 p-4 rounded-2xl text-zinc-400 group-hover:bg-emerald-50 group-hover:text-emerald-600 transition-colors"><Users size={24} /></div>
              <div className="text-left">
                <p className="text-lg font-black text-zinc-800 group-hover:text-emerald-700 transition-colors">{customer.customerName}</p>
                <p className="text-sm font-bold text-zinc-400 font-mono">{customer.customerAccount}</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              {customer.loans.some(l => l.records.some(r => r.statusCode === "100")) && <div className="w-3 h-3 bg-amber-500 rounded-full" title="Monitoring" />}
              {customer.loans.some(l => l.records.some(r => ["126", "127"].includes(r.statusCode))) && <div className="w-3 h-3 bg-red-500 rounded-full" title="Monitoring Failure" />}
              {customer.loans.some(l => l.records.some(r => r.statusCode === "200")) && <div className="w-3 h-3 bg-zinc-900 rounded-full" title="Frozen Account" />}
              <div className="bg-zinc-50 px-4 py-2 rounded-xl text-xs font-black text-zinc-400 group-hover:bg-emerald-600 group-hover:text-white transition-all">{language === 'ar' ? 'عرض المراقبة' : 'Voir Monitoring'}</div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};
