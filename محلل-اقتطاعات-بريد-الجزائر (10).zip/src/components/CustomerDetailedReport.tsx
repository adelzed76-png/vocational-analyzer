import React, { useState, useMemo, useEffect } from 'react';
import { Language } from '../types';
import { useTranslation } from '../utils/translations';
import { formatCurrency } from '../utils/formatters';
import { 
  Search, 
  FileText, 
  User, 
  CreditCard, 
  Calendar, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  TrendingUp, 
  TrendingDown,
  ChevronRight,
  ChevronDown,
  Printer,
  Download,
  Trash2,
  Filter
} from 'lucide-react';

interface CustomerDetailedReportProps {
  language: Language;
}

interface Installment {
  ccp: string;
  name: string;
  amount: number;
  date: string;
  sellerCcp: string;
  code: string;
  reference: string;
  status: 'PAID_ON_TIME' | 'PAID_LATE' | 'UNPAID';
  month: number;
  year: number;
  raw: string;
}

export const CustomerDetailedReport: React.FC<CustomerDetailedReportProps> = ({ language }) => {
  const [resultsRaw, setResultsRaw] = useState(() => localStorage.getItem('cust_report_results') || '');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCustomerKey, setSelectedCustomerKey] = useState<string | null>(null);
  const t = useTranslation(language);
  const isRtl = language === 'ar';

  useEffect(() => {
    localStorage.setItem('cust_report_results', resultsRaw);
  }, [resultsRaw]);

  const parseResults = (raw: string): Installment[] => {
    if (!raw.trim()) return [];
    const lines = raw.split('\n');
    const records: Installment[] = [];

    lines.forEach((line) => {
      const trimmed = line.trim();
      if (!trimmed) return;

      try {
        // Logical sequence:
        // 1. Customer account
        // 2. Name
        // 3. Amount
        // 4. Date
        // 5. Seller account (ends with 93)
        // 6. Code (3 digits)
        // 7. Reference (rest of line)

        // a. Customer postal account (digits at the start, possibly preceded by dots/spaces)
        const ccpMatch = trimmed.match(/^[.\s]*(\d+)/);
        if (!ccpMatch) return;
        const ccp = ccpMatch[1];
        let remaining = trimmed.substring(ccpMatch[0].length);

        // b. Amount (we look for the first number with two decimals after the account)
        const amountMatch = remaining.match(/[.\s]*(\d+\.\d{2})/);
        if (!amountMatch) return;
        
        // Name is everything between ccp and amount, ignoring dots/spaces
        const name = remaining.substring(0, amountMatch.index!).replace(/[.\s]+/g, ' ').trim();
        if (!name) return;
        
        const amount = parseFloat(amountMatch[1]);
        remaining = remaining.substring(amountMatch.index! + amountMatch[0].length);

        // d. Deduction date (DD/MM/YYYY)
        const dateMatch = remaining.match(/[.\s]*(\d{1,2}\/\d{1,2}\/\d{4})/);
        if (!dateMatch) return;
        const date = dateMatch[1];
        remaining = remaining.substring(remaining.indexOf(date) + date.length);

        // e. Seller's postal account (ending with 93)
        const sellerCcpMatch = remaining.match(/[.\s]*(\d*93)/);
        if (!sellerCcpMatch) return;
        const sellerCcp = sellerCcpMatch[1];
        remaining = remaining.substring(remaining.indexOf(sellerCcp) + sellerCcp.length);

        // f. Payment code (3 digits)
        const codeMatch = remaining.match(/[.\s]*(\d{3})/);
        if (!codeMatch) return;
        const code = codeMatch[1];
        remaining = remaining.substring(remaining.indexOf(code) + 3);

        // g. Customer reference (rest of the line)
        const reference = remaining.replace(/^[.\s]+|[.\s]+$/g, '').trim();
        if (!reference) return;

        // Determine payment status
        const codeNum = parseInt(code, 10);
        let status: 'PAID_ON_TIME' | 'PAID_LATE' | 'UNPAID' = 'UNPAID';
        
        if (code === '000') {
          status = 'PAID_ON_TIME';
        } else if (codeNum >= 1 && codeNum <= 27) {
          status = 'PAID_LATE';
        } else if (code === '226' || code === '227') {
          status = 'UNPAID';
        }

        // Extract month/year from date
        const [d, m, y] = date.split('/').map(Number);

        records.push({ 
          ccp, name, amount, date, sellerCcp, code, reference, status,
          month: m, year: y, raw: trimmed
        });
      } catch (e) {
        // Skip malformed lines
      }
    });

    return records;
  };

  const allInstallments = useMemo(() => parseResults(resultsRaw), [resultsRaw]);

  const customers = useMemo(() => {
    const map = new Map<string, { name: string; ccp: string; references: Set<string> }>();
    allInstallments.forEach(inst => {
      const key = inst.ccp;
      if (!map.has(key)) {
        map.set(key, { name: inst.name, ccp: inst.ccp, references: new Set() });
      }
      map.get(key)!.references.add(inst.reference);
    });
    return Array.from(map.values());
  }, [allInstallments]);

  const filteredCustomers = useMemo(() => {
    if (!searchQuery.trim()) return [];
    const query = searchQuery.toLowerCase();
    return customers.filter(c => 
      c.name.toLowerCase().includes(query) || 
      c.ccp.includes(query) || 
      Array.from(c.references).some(ref => ref.toLowerCase().includes(query))
    );
  }, [customers, searchQuery]);

  const reportData = useMemo(() => {
    if (!selectedCustomerKey) return null;
    
    const customerInstallments = allInstallments.filter(inst => inst.ccp === selectedCustomerKey);
    if (customerInstallments.length === 0) return null;

    const customerInfo = {
      name: customerInstallments[0].name,
      ccp: customerInstallments[0].ccp
    };

    // Group by unique reference + month + year (Isolated Logic)
    const installmentGroups = new Map<string, Installment[]>();
    customerInstallments.forEach(inst => {
      const key = `${inst.reference}|${inst.month}|${inst.year}`;
      if (!installmentGroups.has(key)) {
        installmentGroups.set(key, []);
      }
      installmentGroups.get(key)!.push(inst);
    });

    const uniqueInstallments = Array.from(installmentGroups.entries()).map(([key, insts]) => {
      // Final Status Logic per installment (Ref + Month + Year):
      // - If any occurrence is PAID_ON_TIME (000) -> PAID_ON_TIME
      // - Else if any occurrence is PAID_LATE (001-027) -> PAID_LATE
      // - Else -> UNPAID
      
      let finalStatus: 'PAID_ON_TIME' | 'PAID_LATE' | 'UNPAID' = 'UNPAID';
      if (insts.some(i => i.status === 'PAID_ON_TIME')) {
        finalStatus = 'PAID_ON_TIME';
      } else if (insts.some(i => i.status === 'PAID_LATE')) {
        finalStatus = 'PAID_LATE';
      }

      // For the representative date/amount, prioritize PAID attempts
      const paidAttempts = insts.filter(i => i.status !== 'UNPAID');
      const candidates = paidAttempts.length > 0 ? paidAttempts : insts;
      
      const relevantAttempt = [...candidates].sort((a, b) => {
        const [dA, mA, yA] = a.date.split('/').map(Number);
        const [dB, mB, yB] = b.date.split('/').map(Number);
        const dateA = new Date(yA, mA - 1, dA);
        const dateB = new Date(yB, mB - 1, dB);
        return dateB.getTime() - dateA.getTime();
      })[0];

      return {
        reference: insts[0].reference,
        name: insts[0].name,
        ccp: insts[0].ccp,
        amount: relevantAttempt.amount,
        date: relevantAttempt.date,
        status: finalStatus,
        month: relevantAttempt.month,
        year: relevantAttempt.year,
        allAttempts: insts
      };
    });

    // Sort unique installments by date
    uniqueInstallments.sort((a, b) => {
      const [dA, mA, yA] = a.date.split('/').map(Number);
      const [dB, mB, yB] = b.date.split('/').map(Number);
      const dateA = new Date(yA, mA - 1, dA);
      const dateB = new Date(yB, mB - 1, dB);
      return dateA.getTime() - dateB.getTime();
    });

    // Financial Summary (Based on Unique Installments)
    const totalExpected = uniqueInstallments.reduce((sum, r) => sum + r.amount, 0);
    const totalPaid = uniqueInstallments.reduce((sum, r) => sum + (r.status !== 'UNPAID' ? r.amount : 0), 0);
    const totalUnpaid = uniqueInstallments.reduce((sum, r) => sum + (r.status === 'UNPAID' ? r.amount : 0), 0);
    
    const paidCount = uniqueInstallments.filter(r => r.status !== 'UNPAID').length;
    const unpaidCount = uniqueInstallments.filter(r => r.status === 'UNPAID').length;
    const totalCount = uniqueInstallments.length;
    const paymentRate = totalCount > 0 ? (paidCount / totalCount) * 100 : 0;

    let globalStatus: 'Excellent' | 'Good' | 'Average' | 'Low' = 'Low';
    if (paymentRate >= 90) globalStatus = 'Excellent';
    else if (paymentRate >= 70) globalStatus = 'Good';
    else if (paymentRate >= 50) globalStatus = 'Average';

    // Grouping by Month for display
    const monthlyGroupsMap = new Map<string, typeof uniqueInstallments>();
    uniqueInstallments.forEach(inst => {
      const monthKey = `${inst.month}/${inst.year}`;
      if (!monthlyGroupsMap.has(monthKey)) {
        monthlyGroupsMap.set(monthKey, []);
      }
      monthlyGroupsMap.get(monthKey)!.push(inst);
    });

    const monthlyGroups = Array.from(monthlyGroupsMap.entries()).map(([monthYear, refs]) => ({
      monthYear,
      references: refs,
      hasUnpaid: refs.some(r => r.status === 'UNPAID')
    }));

    return {
      customerInfo,
      uniqueReferences: uniqueInstallments,
      monthlyGroups,
      summary: {
        totalExpected,
        totalPaid,
        totalUnpaid,
        remainingBalance: totalExpected - totalPaid,
        paymentRate,
        paidCount,
        unpaidCount,
        status: globalStatus
      }
    };
  }, [selectedCustomerKey, allInstallments]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Excellent': return 'text-emerald-600 bg-emerald-50 border-emerald-100';
      case 'Good': return 'text-blue-600 bg-blue-50 border-blue-100';
      case 'Average': return 'text-amber-600 bg-amber-50 border-amber-100';
      case 'Low': return 'text-red-600 bg-red-50 border-red-100';
      default: return 'text-zinc-600 bg-zinc-50 border-zinc-100';
    }
  };

  const copyReportToClipboard = () => {
    if (!reportData) return;

    let text = `-------------------------------------\n`;
    text += `A. CUSTOMER INFORMATION\n`;
    text += `-------------------------------------\n`;
    text += `- Account: ${reportData.customerInfo.ccp}\n`;
    text += `- Name: ${reportData.customerInfo.name}\n\n`;

    text += `-------------------------------------\n`;
    text += `B. INSTALLMENT DETAILS (BY MONTH)\n`;
    text += `-------------------------------------\n`;
    
    reportData.monthlyGroups.forEach(group => {
      text += `\n[ ${group.monthYear} ]\n`;
      group.references.forEach(ref => {
        let statusLabel = '';
        if (ref.status === 'PAID_ON_TIME') {
          statusLabel = language === 'ar' ? 'مدفوع في الوقت 🔵' : 'PAID ON TIME 🔵';
        } else if (ref.status === 'PAID_LATE') {
          statusLabel = language === 'ar' ? 'مدفوع (متأخر) 🟢' : 'PAID (LATE) 🟢';
        } else {
          statusLabel = language === 'ar' ? 'غير مدفوع 🔴' : 'UNPAID 🔴';
        }
        text += `- Ref: ${ref.reference} | ${ref.name} | ${ref.ccp} | ${ref.date} | ${ref.amount.toFixed(2)} DZD | ${statusLabel}\n`;
      });
    });

    text += `\n-------------------------------------\n`;
    text += `FINANCIAL SUMMARY\n`;
    text += `-------------------------------------\n`;
    text += `- Total Expected: ${reportData.summary.totalExpected.toFixed(2)} DZD\n`;
    text += `- Total Paid: ${reportData.summary.totalPaid.toFixed(2)} DZD\n`;
    text += `- Total Unpaid: ${reportData.summary.totalUnpaid.toFixed(2)} DZD\n`;
    text += `- Remaining: ${reportData.summary.remainingBalance.toFixed(2)} DZD\n`;
    text += `- Paid Installments: ${reportData.summary.paidCount}\n`;
    text += `- Unpaid Installments: ${reportData.summary.unpaidCount}\n`;
    text += `- Global Rate: ${reportData.summary.paymentRate.toFixed(1)}%\n`;

    navigator.clipboard.writeText(text);
    alert(language === 'ar' ? 'تم نسخ التقرير!' : 'Rapport copié !');
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Input Section */}
      <div className="bg-white border border-zinc-200 rounded-3xl p-8 shadow-sm">
        <div className="flex items-center gap-4 mb-8">
          <div className="bg-indigo-100 text-indigo-600 p-3 rounded-2xl">
            <FileText size={32} />
          </div>
          <div>
            <h3 className="text-2xl font-black text-zinc-900">
              {language === 'ar' ? 'تقارير شهرية / تقرير مفصل للزبون' : 'Rapports Mensuels / Rapport Détaillé du Client'}
            </h3>
            <p className="text-zinc-500">
              {language === 'ar' ? 'تحليل شامل لجميع أقساط الزبون وحالة الدفع' : 'Analyse complète de toutes les mensualités du client et de l\'état de paiement'}
            </p>
          </div>
        </div>

        <div className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-bold text-zinc-700 ml-1">
              {language === 'ar' ? '1. تحميل ملف النتائج' : '1. Charger le fichier des résultats'}
            </label>
            <div className="relative">
              <textarea
                value={resultsRaw}
                onChange={(e) => setResultsRaw(e.target.value)}
                placeholder={language === 'ar' ? 'الصق محتوى ملف النتائج هنا...' : 'Collez le contenu du fichier des résultats ici...'}
                className="w-full h-32 p-4 bg-zinc-50 border border-zinc-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all font-mono text-sm resize-none"
              />
              {resultsRaw && (
                <button 
                  onClick={() => setResultsRaw('')}
                  className="absolute top-4 right-4 text-red-500 hover:text-red-600 p-2 hover:bg-red-50 rounded-xl transition-all"
                >
                  <Trash2 size={16} />
                </button>
              )}
            </div>
          </div>

          <div className="space-y-2 relative">
            <label className="text-sm font-bold text-zinc-700 ml-1">
              {language === 'ar' ? '2. اختر الزبون' : '2. Choisir le client'}
            </label>
            <div className="relative">
              <Search className={`absolute ${isRtl ? 'right-4' : 'left-4'} top-1/2 -translate-y-1/2 text-zinc-400`} size={20} />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  if (selectedCustomerKey) setSelectedCustomerKey(null);
                }}
                placeholder={language === 'ar' ? 'ابحث بالاسم، الحساب البريدي، أو المرجع...' : 'Rechercher par nom, CCP, ou référence...'}
                className={`w-full ${isRtl ? 'pr-12 pl-4' : 'pl-12 pr-4'} py-4 bg-zinc-50 border border-zinc-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all font-bold`}
              />
            </div>

            {filteredCustomers.length > 0 && !selectedCustomerKey && (
              <div className="absolute z-50 w-full mt-2 bg-white border border-zinc-200 rounded-2xl shadow-xl max-h-64 overflow-y-auto">
                {filteredCustomers.map((c) => (
                  <button
                    key={c.ccp}
                    onClick={() => {
                      setSelectedCustomerKey(c.ccp);
                      setSearchQuery(c.name);
                    }}
                    className="w-full flex items-center justify-between p-4 hover:bg-zinc-50 transition-colors border-b border-zinc-100 last:border-0"
                  >
                    <div className="flex items-center gap-3">
                      <div className="bg-zinc-100 p-2 rounded-lg text-zinc-500">
                        <User size={16} />
                      </div>
                      <div className="text-left">
                        <p className="font-bold text-zinc-900">{c.name}</p>
                        <p className="text-xs text-zinc-500 font-mono">{c.ccp}</p>
                      </div>
                    </div>
                    <ChevronRight size={16} className="text-zinc-300" />
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {reportData && (
        <div className="space-y-8 print:space-y-4">
          {/* A. Customer Information */}
          <div className="bg-white border border-zinc-200 rounded-3xl p-8 shadow-sm">
            <h3 className="text-lg font-black text-zinc-900 mb-6 flex items-center gap-2">
              <span className="bg-zinc-100 text-zinc-500 w-8 h-8 rounded-lg flex items-center justify-center text-sm">A</span>
              {language === 'ar' ? 'معلومات الزبون' : 'INFORMATIONS DU CLIENT'}
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="flex items-center gap-4 p-4 bg-zinc-50 rounded-2xl border border-zinc-100">
                <div className="bg-white p-3 rounded-xl shadow-sm text-indigo-600">
                  <CreditCard size={24} />
                </div>
                <div>
                  <p className="text-[10px] text-zinc-400 uppercase font-bold tracking-widest">
                    {language === 'ar' ? 'الحساب البريدي' : 'Compte postal'}
                  </p>
                  <p className="text-lg font-black text-zinc-900 font-mono">{reportData.customerInfo.ccp}</p>
                </div>
              </div>
              <div className="flex items-center gap-4 p-4 bg-zinc-50 rounded-2xl border border-zinc-100">
                <div className="bg-white p-3 rounded-xl shadow-sm text-indigo-600">
                  <User size={24} />
                </div>
                <div>
                  <p className="text-[10px] text-zinc-400 uppercase font-bold tracking-widest">
                    {language === 'ar' ? 'الاسم الكامل' : 'Nom complet'}
                  </p>
                  <p className="text-lg font-black text-zinc-900">{reportData.customerInfo.name}</p>
                </div>
              </div>
            </div>
          </div>

          {/* B, C. Installment Details Grouped by Month */}
          <div className="space-y-6">
            <h3 className="text-lg font-black text-zinc-900 flex items-center gap-2 px-4">
              <span className="bg-zinc-100 text-zinc-500 w-8 h-8 rounded-lg flex items-center justify-center text-sm">B</span>
              {language === 'ar' ? 'تفاصيل الأقساط (حسب المرجع)' : 'DÉTAILS DES MENSUALITÉS (PAR RÉFÉRENCE)'}
            </h3>
            
            {reportData.monthlyGroups.map((group) => (
              <div key={group.monthYear} className="bg-white border border-zinc-200 rounded-3xl overflow-hidden shadow-sm">
                <div className={`p-6 border-b border-zinc-100 flex items-center justify-between ${group.hasUnpaid ? 'bg-red-50/50' : 'bg-zinc-50/50'}`}>
                  <div className="flex items-center gap-3">
                    <Calendar size={20} className="text-zinc-400" />
                    <h4 className="font-black text-zinc-900">{group.monthYear}</h4>
                  </div>
                  {group.hasUnpaid && (
                    <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-[10px] font-black uppercase tracking-wider">
                      {language === 'ar' ? 'توجد أقساط غير مدفوعة' : 'Mensualités impayées'}
                    </span>
                  )}
                </div>
                <div className="divide-y divide-zinc-100">
                  {group.references.map((ref) => (
                    <div key={ref.reference} className="p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-zinc-50/50 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className="bg-white p-3 rounded-xl shadow-sm text-zinc-400 border border-zinc-100">
                          <FileText size={20} />
                        </div>
                        <div>
                          <p className="text-xs font-mono text-zinc-500 mb-1">{ref.reference}</p>
                          <div className="flex items-center gap-2 text-[10px] text-zinc-400 font-bold uppercase tracking-wider mb-1">
                            <span>{ref.name}</span>
                            <span>•</span>
                            <span className="font-mono">{ref.ccp}</span>
                          </div>
                          <p className="text-sm font-black text-zinc-900">{ref.date}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-8">
                        <div className="text-right">
                          <p className="text-lg font-black text-zinc-900">{formatCurrency(ref.amount)}</p>
                          <p className="text-[10px] text-zinc-400 uppercase font-bold tracking-widest">
                            {language === 'ar' ? 'المبلغ' : 'Montant'}
                          </p>
                        </div>
                        <div className="w-40 flex justify-center">
                          {ref.status === 'PAID_ON_TIME' ? (
                            <div className="flex items-center gap-2 px-4 py-2 bg-blue-100 text-blue-700 rounded-xl font-bold text-xs">
                              <CheckCircle2 size={16} />
                              {language === 'ar' ? 'مدفوع في الوقت' : 'PAID ON TIME'} 🔵
                            </div>
                          ) : ref.status === 'PAID_LATE' ? (
                            <div className="flex items-center gap-2 px-4 py-2 bg-emerald-100 text-emerald-700 rounded-xl font-bold text-xs">
                              <CheckCircle2 size={16} />
                              {language === 'ar' ? 'مدفوع (متأخر)' : 'PAID (LATE)'} 🟢
                            </div>
                          ) : (
                            <div className="flex items-center gap-2 px-4 py-2 bg-red-100 text-red-700 rounded-xl font-bold text-xs">
                              <XCircle size={16} />
                              {language === 'ar' ? 'غير مدفوع' : 'UNPAID'} 🔴
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* E, F. Financial Summary & Performance */}
          <div className="bg-zinc-900 text-white border border-zinc-800 rounded-[40px] p-10 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 blur-[100px] -mr-32 -mt-32"></div>
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-emerald-500/10 blur-[100px] -ml-32 -mb-32"></div>
            
            <div className="relative z-10 space-y-10">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div>
                  <h3 className="text-2xl font-black mb-2 flex items-center gap-3">
                    <TrendingUp size={32} className="text-emerald-400" />
                    {language === 'ar' ? 'الملخص المالي ومؤشرات الأداء' : 'RÉSUMÉ FINANCIER & INDICATEURS'}
                  </h3>
                  <p className="text-zinc-400 font-medium">
                    {language === 'ar' ? 'تحليل شامل للأداء المالي للزبون' : 'Analyse complète de la performance financière du client'}
                  </p>
                </div>
                <div className={`px-6 py-3 rounded-2xl border-2 font-black text-lg ${getStatusColor(reportData.summary.status).replace('bg-', 'bg-opacity-10 bg-')}`}>
                  {reportData.summary.status === 'Excellent' && (language === 'ar' ? 'ممتاز' : 'Excellent')}
                  {reportData.summary.status === 'Good' && (language === 'ar' ? 'جيد' : 'Bon')}
                  {reportData.summary.status === 'Average' && (language === 'ar' ? 'متوسط' : 'Moyen')}
                  {reportData.summary.status === 'Low' && (language === 'ar' ? 'ضعيف' : 'Faible')}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div className="space-y-1">
                  <p className="text-[10px] text-zinc-500 uppercase font-bold tracking-widest">{language === 'ar' ? 'إجمالي المبلغ المتوقع' : 'Total attendu'}</p>
                  <p className="text-2xl font-black">{formatCurrency(reportData.summary.totalExpected)}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] text-emerald-500 uppercase font-bold tracking-widest">{language === 'ar' ? 'إجمالي المبلغ المدفوع' : 'Total payé'}</p>
                  <p className="text-2xl font-black text-emerald-400">{formatCurrency(reportData.summary.totalPaid)}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] text-red-500 uppercase font-bold tracking-widest">{language === 'ar' ? 'إجمالي المبلغ غير المدفوع' : 'Total impayé'}</p>
                  <p className="text-2xl font-black text-red-400">{formatCurrency(reportData.summary.totalUnpaid)}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] text-indigo-500 uppercase font-bold tracking-widest">{language === 'ar' ? 'الرصيد المتبقي' : 'Solde restant'}</p>
                  <p className="text-2xl font-black text-indigo-400">{formatCurrency(reportData.summary.remainingBalance)}</p>
                </div>
              </div>

              <div className="pt-8 border-t border-zinc-800 flex flex-col md:flex-row items-center justify-between gap-8">
                <div className="flex items-center gap-8">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 bg-emerald-500 rounded-full"></div>
                    <div>
                      <p className="text-[10px] text-zinc-500 uppercase font-bold">{language === 'ar' ? 'أقساط مدفوعة' : 'Mensualités payées'}</p>
                      <p className="text-lg font-black">{reportData.summary.paidCount}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <div>
                      <p className="text-[10px] text-zinc-500 uppercase font-bold">{language === 'ar' ? 'أقساط غير مدفوعة' : 'Mensualités impayées'}</p>
                      <p className="text-lg font-black">{reportData.summary.unpaidCount}</p>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-6">
                  <div className="text-right">
                    <p className="text-[10px] text-zinc-500 uppercase font-bold">{language === 'ar' ? 'معدل الدفع' : 'Taux de paiement'}</p>
                    <p className="text-4xl font-black text-white">{reportData.summary.paymentRate.toFixed(1)}%</p>
                  </div>
                  <div className="w-24 h-24 relative">
                    <svg className="w-full h-full" viewBox="0 0 36 36">
                      <path
                        className="text-zinc-800"
                        strokeDasharray="100, 100"
                        strokeWidth="3"
                        stroke="currentColor"
                        fill="none"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      />
                      <path
                        className="text-emerald-500"
                        strokeDasharray={`${reportData.summary.paymentRate}, 100`}
                        strokeWidth="3"
                        strokeLinecap="round"
                        stroke="currentColor"
                        fill="none"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-center gap-4 no-print">
            <button 
              onClick={() => window.print()}
              className="flex items-center gap-2 px-8 py-4 bg-zinc-900 text-white rounded-2xl font-black hover:bg-zinc-800 transition-all shadow-xl shadow-zinc-200"
            >
              <Printer size={20} />
              {language === 'ar' ? 'طباعة التقرير' : 'Imprimer le rapport'}
            </button>
            <button 
              onClick={copyReportToClipboard}
              className="flex items-center gap-2 px-8 py-4 bg-white border border-zinc-200 text-zinc-900 rounded-2xl font-black hover:bg-zinc-50 transition-all shadow-sm"
            >
              <Download size={20} />
              {language === 'ar' ? 'نسخ التقرير' : 'Copier le rapport'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
