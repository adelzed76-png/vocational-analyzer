import React, { useState, useEffect } from 'react';
import { ChevronDown } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Language } from '../types';

interface ScrollIndicatorProps {
  language: Language;
}

export const ScrollIndicator: React.FC<ScrollIndicatorProps> = ({ language }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const checkScroll = () => {
      // Show only if there is content to scroll to and we are at the top
      const scrollableHeight = document.documentElement.scrollHeight - window.innerHeight;
      // We show it if the page is significantly longer than the viewport and we are near the top
      if (scrollableHeight > 150 && window.scrollY < 50) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    // Initial check with a small delay to allow content to render
    const timer = setTimeout(checkScroll, 500);

    window.addEventListener('scroll', checkScroll);
    window.addEventListener('resize', checkScroll);
    
    return () => {
      window.removeEventListener('scroll', checkScroll);
      window.removeEventListener('resize', checkScroll);
      clearTimeout(timer);
    };
  }, []);

  const scrollToContent = () => {
    // Scroll down to reveal more content
    window.scrollTo({
      top: 400,
      behavior: 'smooth'
    });
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
          className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50 flex flex-col items-center gap-2 cursor-pointer group"
          onClick={scrollToContent}
        >
          <span className="text-[10px] font-black uppercase tracking-widest text-zinc-400 group-hover:text-emerald-600 transition-colors drop-shadow-sm">
            {language === 'ar' ? 'انزل للأسفل' : 'Voir plus'}
          </span>
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ 
              duration: 2, 
              repeat: Infinity, 
              ease: "easeInOut" 
            }}
            className="bg-white p-3 rounded-full shadow-xl border border-zinc-100 text-emerald-600 group-hover:bg-emerald-50 transition-colors"
          >
            <ChevronDown size={24} />
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
