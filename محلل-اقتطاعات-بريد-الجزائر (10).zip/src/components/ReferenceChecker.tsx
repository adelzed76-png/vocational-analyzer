import React, { useState, useMemo, useEffect } from 'react';
import { Language } from '../types';
import { useTranslation } from '../utils/translations';
import { formatCurrency } from '../utils/formatters';
import { AlertCircle, Calculator, Trash2, ClipboardList, CheckCircle2, Table as TableIcon, User, FileText, ShieldAlert } from 'lucide-react';

interface ReferenceCheckerProps {
  language: Language;
}

interface ParsedLine {
  ccp: string;
  name: string;
  amount: number;
  date: string;
  sellerCcp: string;
  code: string;
  reference: string;
  status: 'PAID' | 'UNPAID';
  deductedAmount: number;
  undeductedAmount: number;
  raw: string;
}

interface MalformedLine {
  line: string;
  reason: string;
}

interface AuditResult {
  reference: string;
  name: string;
  ccp: string;
  amount: number;
  date: string;
  deductedAmount: number;
  undeductedAmount: number;
  totalPerReference: number;
  status: 'PAID' | 'UNPAID' | 'NOT_FOUND';
}

export const ReferenceChecker: React.FC<ReferenceCheckerProps> = ({ language }) => {
  const [expectedRaw, setExpectedRaw] = useState(() => localStorage.getItem('audit_expected_raw') || '');
  const [actualRaw, setActualRaw] = useState(() => localStorage.getItem('audit_actual_raw') || '');
  const t = useTranslation(language);
  const isRtl = language === 'ar';

  useEffect(() => {
    localStorage.setItem('audit_expected_raw', expectedRaw);
    localStorage.setItem('audit_actual_raw', actualRaw);
  }, [expectedRaw, actualRaw]);

  const parseResults = (raw: string): { records: ParsedLine[], malformed: MalformedLine[] } => {
    if (!raw.trim()) return { records: [], malformed: [] };
    const lines = raw.split('\n');
    const records: ParsedLine[] = [];
    const malformed: MalformedLine[] = [];

    lines.forEach((line) => {
      const trimmed = line.trim();
      if (!trimmed) return;

      try {
        let remaining = trimmed;

        // a. Customer postal account: first number/letters at the start of the line
        const ccpMatch = remaining.match(/^(\d+)/);
        if (!ccpMatch) throw new Error(language === 'ar' ? 'حساب الزبون مفقود' : 'Customer CCP missing');
        const ccp = ccpMatch[1];
        remaining = remaining.substring(ccp.length);

        // b. Customer last name and first name: text following the account
        // c. Amount due: first number after the name
        // We look for the first number that looks like an amount (e.g. 000004166.00)
        // Using a regex that finds digits followed by a dot and exactly 2 digits
        const amountMatch = remaining.match(/(\d+\.\d{2})/);
        if (!amountMatch) throw new Error(language === 'ar' ? 'المبلغ مفقود' : 'Amount missing');
        
        const name = remaining.substring(0, amountMatch.index!).replace(/^[.\s]+|[.\s]+$/g, '').trim();
        if (!name) throw new Error(language === 'ar' ? 'اسم الزبون مفقود' : 'Customer name missing');
        
        const amount = parseFloat(amountMatch[1]);
        remaining = remaining.substring(amountMatch.index! + amountMatch[0].length);

        // d. Deduction date: day/month/year immediately after amount
        const dateMatch = remaining.match(/(\d{1,2}\/\d{1,2}\/\d{4})/);
        if (!dateMatch) throw new Error(language === 'ar' ? 'التاريخ مفقود' : 'Date missing');
        const date = dateMatch[1];
        remaining = remaining.substring(dateMatch.index! + dateMatch[0].length);

        // e. Seller's postal account: number ending with '93' after date
        const sellerCcpMatch = remaining.match(/(\d*93)/);
        if (!sellerCcpMatch) throw new Error(language === 'ar' ? 'حساب البائع مفقود' : 'Seller CCP missing');
        const sellerCcp = sellerCcpMatch[1];
        remaining = remaining.substring(remaining.indexOf(sellerCcp) + sellerCcp.length);

        // f. Payment code: three digits immediately after seller's postal account
        const codeMatch = remaining.match(/(\d{3})/);
        if (!codeMatch) throw new Error(language === 'ar' ? 'كود الدفع مفقود' : 'Payment code missing');
        const code = codeMatch[1];
        remaining = remaining.substring(remaining.indexOf(code) + 3).trim();

        // g. Customer reference: everything remaining after payment code
        const reference = remaining;
        if (!reference) throw new Error(language === 'ar' ? 'المرجع مفقود' : 'Reference missing');

        // 5. Determine payment status
        const codeNum = parseInt(code, 10);
        const isPaid = code === '000' || (codeNum >= 1 && codeNum <= 27);
        const isUnpaid = code === '226' || code === '227';
        
        // Status logic: follow the prompt's paid/unpaid codes
        // For calculations, we treat anything not paid as undeducted
        const status: ParsedLine['status'] = isPaid ? 'PAID' : 'UNPAID';
        const deductedAmount = isPaid ? amount : 0;
        const undeductedAmount = !isPaid ? amount : 0;

        records.push({ 
          ccp, name, amount, date, sellerCcp, code, reference, status,
          deductedAmount, undeductedAmount, raw: trimmed
        });
      } catch (e: any) {
        malformed.push({ line: trimmed, reason: e.message });
      }
    });

    return { records, malformed };
  };

  const { analysisResults, globalStats, malformedLines } = useMemo(() => {
    const { records: resultRecords, malformed } = parseResults(actualRaw);
    
    // Extract references from expectedRaw (one per line or space separated)
    const expectedRefs = expectedRaw.split(/\s+/).filter(r => r.trim() !== '');
    const uniqueExpectedRefs = Array.from(new Set(expectedRefs));

    const results: AuditResult[] = [];
    
    uniqueExpectedRefs.forEach(ref => {
      // Focus analysis ONLY on the references provided
      const matches = resultRecords.filter(r => r.reference === ref);
      
      if (matches.length > 0) {
        // Sum all paid + unpaid installments for each reference
        const totalDeducted = matches.reduce((sum, m) => sum + m.deductedAmount, 0);
        const totalUndeducted = matches.reduce((sum, m) => sum + m.undeductedAmount, 0);
        const totalPerReference = totalDeducted + totalUndeducted;
        
        const firstMatch = matches[0];
        const isPaid = matches.some(m => m.status === 'PAID');

        results.push({
          reference: ref,
          name: firstMatch.name,
          ccp: firstMatch.ccp,
          amount: firstMatch.amount,
          date: firstMatch.date,
          deductedAmount: totalDeducted,
          undeductedAmount: totalUndeducted,
          totalPerReference,
          status: isPaid ? 'PAID' : 'UNPAID'
        });
      } else {
        // Any reference in the sent list but not found in the results -> mark as unpaid
        results.push({
          reference: ref,
          name: '---',
          ccp: '---',
          amount: 0,
          date: '---',
          deductedAmount: 0,
          undeductedAmount: 0,
          totalPerReference: 0,
          status: 'NOT_FOUND'
        });
      }
    });

    const stats = results.reduce((acc, curr) => {
      acc.totalPaid += curr.deductedAmount;
      acc.totalUnpaid += curr.undeductedAmount;
      if (curr.status === 'PAID') acc.paidCount++;
      else acc.unpaidCount++;
      return acc;
    }, { totalPaid: 0, totalUnpaid: 0, paidCount: 0, unpaidCount: 0 });

    return { 
      analysisResults: results, 
      globalStats: {
        ...stats,
        totalReferences: uniqueExpectedRefs.length
      },
      malformedLines: malformed
    };
  }, [expectedRaw, actualRaw, language]);

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Malformed Lines Report */}
      {malformedLines.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-2xl p-6 space-y-3">
          <div className="flex items-center gap-3 text-red-700 font-bold">
            <AlertCircle size={20} />
            <h3>{language === 'ar' ? 'تقرير الأسطر غير الصالحة' : 'Rapport des lignes malformées'}</h3>
          </div>
          <div className="max-h-32 overflow-y-auto space-y-2">
            {malformedLines.map((m, i) => (
              <div key={i} className="text-xs text-red-600 font-mono bg-white/50 p-2 rounded border border-red-100">
                <span className="font-bold">[{m.reason}]</span> {m.line}
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="bg-white border border-zinc-200 rounded-3xl p-8 shadow-sm">
        <div className="flex items-center gap-4 mb-8">
          <div className="bg-emerald-100 text-emerald-600 p-3 rounded-2xl">
            <ShieldAlert size={32} />
          </div>
          <div>
            <h3 className="text-2xl font-black text-zinc-900">{t.referenceChecker}</h3>
            <p className="text-zinc-500">{language === 'ar' ? 'تدقيق المراجع بناءً على نتائج بريد الجزائر' : 'Audit des références basé sur les résultats d\'Algérie Poste'}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Area 1: References */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-zinc-100 text-zinc-600 p-2 rounded-xl">
                  <FileText size={24} />
                </div>
                <h3 className="text-lg font-bold text-zinc-900">{language === 'ar' ? '1. قائمة المراجع المرسلة' : '1. Liste des références envoyées'}</h3>
              </div>
              {expectedRaw && (
                <button 
                  onClick={() => setExpectedRaw('')}
                  className="text-red-500 hover:text-red-600 p-2 hover:bg-red-50 rounded-xl transition-all flex items-center gap-2 text-xs font-bold"
                >
                  <Trash2 size={16} />
                  {t.clearData}
                </button>
              )}
            </div>
            <textarea
              value={expectedRaw}
              onChange={(e) => setExpectedRaw(e.target.value)}
              placeholder={language === 'ar' ? 'الصق قائمة المراجع هنا...' : 'Collez la liste des références ici...'}
              className="w-full h-48 p-6 bg-zinc-50 border border-zinc-200 rounded-2xl focus:ring-2 focus:ring-zinc-500 focus:border-zinc-500 outline-none transition-all font-mono text-sm resize-none"
            />
          </div>

          {/* Area 2: Results */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-emerald-100 text-emerald-600 p-2 rounded-xl">
                  <ClipboardList size={24} />
                </div>
                <h3 className="text-lg font-bold text-zinc-900">{language === 'ar' ? '2. ملف النتائج (بريد الجزائر)' : '2. Fichier des résultats (Algérie Poste)'}</h3>
              </div>
              {actualRaw && (
                <button 
                  onClick={() => setActualRaw('')}
                  className="text-red-500 hover:text-red-600 p-2 hover:bg-red-50 rounded-xl transition-all flex items-center gap-2 text-xs font-bold"
                >
                  <Trash2 size={16} />
                  {t.clearData}
                </button>
              )}
            </div>
            <textarea
              value={actualRaw}
              onChange={(e) => setActualRaw(e.target.value)}
              placeholder={language === 'ar' ? 'الصق محتوى ملف النتائج هنا...' : 'Collez le contenu du fichier des résultats ici...'}
              className="w-full h-48 p-6 bg-zinc-50 border border-zinc-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all font-mono text-sm resize-none"
            />
          </div>
        </div>
      </div>

      {analysisResults.length > 0 && (
        <>
          {/* Global Summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-zinc-900 text-white p-8 rounded-3xl shadow-xl relative overflow-hidden group">
              <div className="absolute -right-4 -top-4 text-white/5 group-hover:opacity-10 transition-opacity">
                <Calculator size={80} />
              </div>
              <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest mb-1">{language === 'ar' ? 'إجمالي المراجع المرسلة' : 'Total Références Envoyées'}</p>
              <p className="text-4xl font-black">{globalStats.totalReferences}</p>
            </div>

            <div className="bg-emerald-600 text-white p-8 rounded-3xl shadow-xl relative overflow-hidden group">
              <div className="absolute -right-4 -top-4 text-white/5 group-hover:opacity-10 transition-opacity">
                <CheckCircle2 size={80} />
              </div>
              <p className="text-[10px] text-emerald-200 font-bold uppercase tracking-widest mb-1">{language === 'ar' ? 'إجمالي المبالغ المقتطعة' : 'Total Montants Déduits'}</p>
              <p className="text-3xl font-black">{formatCurrency(globalStats.totalPaid)}</p>
              <p className="text-xs text-emerald-100 mt-2 font-bold">{globalStats.paidCount} {language === 'ar' ? 'مرجع مدفوع' : 'références payées'}</p>
            </div>

            <div className="bg-red-600 text-white p-8 rounded-3xl shadow-xl relative overflow-hidden group">
              <div className="absolute -right-4 -top-4 text-white/5 group-hover:opacity-10 transition-opacity">
                <AlertCircle size={80} />
              </div>
              <p className="text-[10px] text-red-200 font-bold uppercase tracking-widest mb-1">{language === 'ar' ? 'إجمالي المبالغ غير المقتطعة' : 'Total Montants Non Déduits'}</p>
              <p className="text-3xl font-black">{formatCurrency(globalStats.totalUnpaid)}</p>
              <p className="text-xs text-red-100 mt-2 font-bold">{globalStats.unpaidCount} {language === 'ar' ? 'مرجع غير مدفوع' : 'références non payées'}</p>
            </div>
          </div>

          {/* Results Table */}
          <div className="bg-white border border-zinc-200 rounded-3xl overflow-hidden shadow-sm">
            <div className="p-6 border-b border-zinc-100 bg-zinc-50/50 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <TableIcon className="text-emerald-600" size={24} />
                <h3 className="text-lg font-bold text-zinc-900">{language === 'ar' ? 'تقرير تدقيق المراجع' : 'Rapport d\'Audit des Références'}</h3>
              </div>
              <button 
                onClick={() => {
                  const headers = [
                    language === 'ar' ? 'الاسم واللقب' : 'Nom & Prénom',
                    language === 'ar' ? 'الحساب البريدي' : 'CCP',
                    language === 'ar' ? 'المرجع' : 'Référence',
                    language === 'ar' ? 'المبلغ' : 'Montant',
                    language === 'ar' ? 'تاريخ الاقتطاع' : 'Date Deduction',
                    language === 'ar' ? 'المبلغ المقتطع' : 'Montant Déduit',
                    language === 'ar' ? 'المبلغ غير المقتطع' : 'Montant Non Déduit',
                    language === 'ar' ? 'الإجمالي لكل مرجع' : 'Total per Reference'
                  ];
                  const rows = analysisResults.map(res => [
                    res.name,
                    res.ccp,
                    res.reference,
                    res.amount,
                    res.date,
                    res.deductedAmount,
                    res.undeductedAmount,
                    res.totalPerReference
                  ]);
                  const csvContent = [headers, ...rows].map(e => e.join("\t")).join("\n");
                  navigator.clipboard.writeText(csvContent);
                  alert(language === 'ar' ? 'تم نسخ التحليل!' : 'Analyse copiée !');
                }}
                className="flex items-center gap-2 px-4 py-2 bg-emerald-50 text-emerald-600 rounded-xl text-xs font-bold hover:bg-emerald-100 transition-all"
              >
                <ClipboardList size={16} />
                {language === 'ar' ? 'نسخ التقرير' : 'Copier le rapport'}
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left" dir={isRtl ? 'rtl' : 'ltr'}>
                <thead>
                  <tr className="bg-zinc-50 text-zinc-500 text-[10px] uppercase tracking-wider font-black">
                    <th className="px-6 py-4">{language === 'ar' ? 'الاسم واللقب' : 'Nom & Prénom'}</th>
                    <th className="px-6 py-4">{language === 'ar' ? 'الحساب البريدي' : 'CCP'}</th>
                    <th className="px-6 py-4">{language === 'ar' ? 'المرجع' : 'Référence'}</th>
                    <th className="px-6 py-4">{language === 'ar' ? 'المبلغ' : 'Montant'}</th>
                    <th className="px-6 py-4">{language === 'ar' ? 'تاريخ الاقتطاع' : 'Date'}</th>
                    <th className="px-6 py-4 text-emerald-600">{language === 'ar' ? 'مقتطع' : 'Déduit'}</th>
                    <th className="px-6 py-4 text-red-600">{language === 'ar' ? 'غير مقتطع' : 'Non Déduit'}</th>
                    <th className="px-6 py-4 font-black">{language === 'ar' ? 'الإجمالي' : 'Total'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100">
                  {analysisResults.map((res, idx) => (
                    <tr key={idx} className="hover:bg-zinc-50 transition-colors group/row">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="bg-zinc-100 text-zinc-400 p-2 rounded-lg group-hover/row:bg-emerald-100 group-hover/row:text-emerald-600 transition-colors">
                            <User size={16} />
                          </div>
                          <span className="font-bold text-zinc-900">{res.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 font-mono text-xs text-zinc-500">{res.ccp}</td>
                      <td className="px-6 py-4 font-mono text-sm font-bold text-zinc-900">{res.reference}</td>
                      <td className="px-6 py-4 font-bold text-zinc-900">{formatCurrency(res.amount)}</td>
                      <td className="px-6 py-4 text-zinc-500 font-mono text-xs">{res.date}</td>
                      <td className="px-6 py-4 font-bold text-emerald-600">{formatCurrency(res.deductedAmount)}</td>
                      <td className="px-6 py-4 font-bold text-red-600">{formatCurrency(res.undeductedAmount)}</td>
                      <td className="px-6 py-4 font-black text-zinc-900 bg-zinc-50/50">
                        <div className="flex flex-col">
                          {formatCurrency(res.totalPerReference)}
                          {res.status === 'NOT_FOUND' && (
                            <span className="text-[8px] text-red-500 uppercase tracking-tighter">
                              {language === 'ar' ? 'غير موجود' : 'Non trouvé'}
                            </span>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
