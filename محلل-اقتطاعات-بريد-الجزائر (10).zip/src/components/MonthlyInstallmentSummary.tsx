import React, { useMemo, useState } from 'react';
import { CustomerSummary, Language } from '../types';
import { Table, Calendar, Search, ArrowUpDown, FileText } from 'lucide-react';
import { formatCurrency } from '../utils/formatters';

interface MonthlyInstallmentSummaryProps {
  summaries: CustomerSummary[];
  language: Language;
}

interface GroupedInstallment {
  customerName: string;
  count: number;
  totalAmount: number;
  date: string;
  paidAmount: number;
  unpaidAmount: number;
}

export const MonthlyInstallmentSummary: React.FC<MonthlyInstallmentSummaryProps> = ({ summaries, language }) => {
  const [selectedMonth, setSelectedMonth] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState('');
  const [sortConfig, setSortConfig] = useState<{ key: keyof GroupedInstallment; direction: 'asc' | 'desc' } | null>(null);

  const availableMonths = useMemo(() => {
    const months = new Set<string>();
    summaries.forEach(s => {
      s.records.forEach(r => {
        const dateParts = r.installmentDate.split('/');
        if (dateParts.length === 3) {
          months.add(`${dateParts[1].padStart(2, '0')} / ${dateParts[2]}`);
        }
      });
    });
    const sorted = Array.from(months).sort((a, b) => {
      const [mA, yA] = a.split(' / ').map(Number);
      const [mB, yB] = b.split(' / ').map(Number);
      return yB !== yA ? yB - yA : mB - mA;
    });

    if (sorted.length > 0 && !selectedMonth) {
      setSelectedMonth(sorted[0]);
    }

    return sorted;
  }, [summaries]);

  const groupedData = useMemo(() => {
    if (!selectedMonth) return [];

    const groups: Record<string, GroupedInstallment> = {};

    summaries.forEach(customer => {
      customer.records.forEach(record => {
        const dateParts = record.installmentDate.split('/');
        if (dateParts.length !== 3) return;
        
        const monthYear = `${dateParts[1].padStart(2, '0')} / ${dateParts[2]}`;
        if (monthYear !== selectedMonth) return;

        const key = `${customer.customerName}_${record.installmentDate}`;
        const isPaid = parseInt(record.statusCode) <= 27;

        if (!groups[key]) {
          groups[key] = {
            customerName: customer.customerName,
            count: 0,
            totalAmount: 0,
            date: record.installmentDate,
            paidAmount: 0,
            unpaidAmount: 0
          };
        }

        groups[key].count += 1;
        groups[key].totalAmount += record.installmentAmount;
        if (isPaid) {
          groups[key].paidAmount += record.installmentAmount;
        } else {
          groups[key].unpaidAmount += record.installmentAmount;
        }
      });
    });

    let result = Object.values(groups);

    if (searchTerm) {
      const lowerSearch = searchTerm.toLowerCase();
      result = result.filter(item => 
        item.customerName.toLowerCase().includes(lowerSearch) || 
        item.date.includes(searchTerm)
      );
    }

    if (sortConfig) {
      result.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) return sortConfig.direction === 'asc' ? -1 : 1;
        if (a[sortConfig.key] > b[sortConfig.key]) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return result;
  }, [summaries, selectedMonth, searchTerm, sortConfig]);

  const requestSort = (key: keyof GroupedInstallment) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="bg-white border border-zinc-200 rounded-3xl p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="bg-blue-50 text-blue-600 p-3 rounded-2xl">
              <Table size={24} />
            </div>
            <div>
              <h3 className="text-lg font-black text-zinc-900">
                {language === 'ar' ? 'ملخص الأقساط الشهري' : 'Résumé Mensuel des Versements'}
              </h3>
              <p className="text-xs text-zinc-500 font-medium">
                {language === 'ar' ? 'تجميع الأقساط حسب تاريخ الدفع لكل زبون' : 'Groupement des versements par date de paiement pour chaque client'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
              <input
                type="text"
                placeholder={language === 'ar' ? 'بحث عن زبون...' : 'Rechercher un client...'}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 bg-zinc-50 border border-zinc-200 rounded-xl text-sm font-bold outline-none focus:ring-2 focus:ring-blue-500 transition-all w-64"
              />
            </div>
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-2 text-sm font-bold outline-none focus:ring-2 focus:ring-blue-500"
            >
              {availableMonths.map(m => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <div className="bg-white border border-zinc-200 rounded-3xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-zinc-50 text-zinc-500 text-[10px] uppercase tracking-widest font-black">
                <th className="px-6 py-4 cursor-pointer hover:bg-zinc-100 transition-colors" onClick={() => requestSort('customerName')}>
                  <div className="flex items-center gap-2">
                    {language === 'ar' ? 'اسم الزبون' : 'Nom du Client'}
                    <ArrowUpDown size={12} />
                  </div>
                </th>
                <th className="px-6 py-4 cursor-pointer hover:bg-zinc-100 transition-colors" onClick={() => requestSort('count')}>
                  <div className="flex items-center gap-2">
                    {language === 'ar' ? 'الأقساط' : 'Versements'}
                    <ArrowUpDown size={12} />
                  </div>
                </th>
                <th className="px-6 py-4 cursor-pointer hover:bg-zinc-100 transition-colors" onClick={() => requestSort('totalAmount')}>
                  <div className="flex items-center gap-2">
                    {language === 'ar' ? 'المجموع' : 'Total'}
                    <ArrowUpDown size={12} />
                  </div>
                </th>
                <th className="px-6 py-4 cursor-pointer hover:bg-zinc-100 transition-colors" onClick={() => requestSort('date')}>
                  <div className="flex items-center gap-2">
                    {language === 'ar' ? 'التاريخ' : 'Date'}
                    <ArrowUpDown size={12} />
                  </div>
                </th>
                <th className="px-6 py-4 cursor-pointer hover:bg-zinc-100 transition-colors" onClick={() => requestSort('paidAmount')}>
                  <div className="flex items-center gap-2">
                    {language === 'ar' ? 'المبلغ المدفوع' : 'Montant Payé'}
                    <ArrowUpDown size={12} />
                  </div>
                </th>
                <th className="px-6 py-4 cursor-pointer hover:bg-zinc-100 transition-colors" onClick={() => requestSort('unpaidAmount')}>
                  <div className="flex items-center gap-2">
                    {language === 'ar' ? 'المبلغ غير المدفوع' : 'Montant Impayé'}
                    <ArrowUpDown size={12} />
                  </div>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {groupedData.map((item, idx) => (
                <tr key={`${item.customerName}_${item.date}_${idx}`} className="hover:bg-zinc-50 transition-colors">
                  <td className="px-6 py-4">
                    <span className="font-black text-zinc-900">{item.customerName}</span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <div className="bg-zinc-100 text-zinc-600 px-2 py-1 rounded-lg text-xs font-black">
                        {item.count} {language === 'ar' ? 'أقساط' : 'inst.'}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="font-black text-zinc-900">{formatCurrency(item.totalAmount)}</span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-zinc-600">
                      <Calendar size={14} />
                      <span className="font-bold text-sm">{item.date}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="font-black text-emerald-600">{formatCurrency(item.paidAmount)}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="font-black text-red-600">{formatCurrency(item.unpaidAmount)}</span>
                  </td>
                </tr>
              ))}
              {groupedData.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-6 py-20 text-center">
                    <div className="flex flex-col items-center gap-3 text-zinc-400">
                      <FileText size={48} className="opacity-20" />
                      <p className="font-bold">{language === 'ar' ? 'لا توجد بيانات متاحة لهذا الشهر' : 'Aucune donnée disponible pour ce mois'}</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
