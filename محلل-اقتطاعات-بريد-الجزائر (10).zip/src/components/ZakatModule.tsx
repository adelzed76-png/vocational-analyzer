import React, { useState, useMemo, useEffect } from 'react';
import { Language } from '../types';
import { useTranslation } from '../utils/translations';
import { Calculator, FileText, AlertCircle, Trash2, ClipboardList, Table as TableIcon, ArrowRight, DollarSign, Calendar } from 'lucide-react';
import { formatCurrency } from '../utils/formatters';

interface ZakatModuleProps {
  language: Language;
}

interface ZakatGroup {
  startDate: string;
  endDate: string;
  monthlyAmount: number;
  months: number;
  remainingMonths: number;
  remainingAmount: number;
}

export const ZakatModule: React.FC<ZakatModuleProps> = ({ language }) => {
  const t = useTranslation(language);
  const isRtl = language === 'ar';
  const [rawData, setRawData] = useState(() => localStorage.getItem('zakat_raw_data') || '');

  useEffect(() => {
    localStorage.setItem('zakat_raw_data', rawData);
  }, [rawData]);

  // Fixed Parameters
  const HAWL_END_MONTH = 1; // February (0-indexed)
  const HAWL_END_YEAR = 2026;
  const START_COUNTING_MONTH = 2; // March (0-indexed)
  const START_COUNTING_YEAR = 2026;

  const parseDate = (dateStr: string) => {
    // Accept DD-MM-YYYY or DD/MM/YYYY
    const parts = dateStr.split(/[-/]/);
    if (parts.length !== 3) return null;
    const day = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10);
    const year = parseInt(parts[2], 10);
    if (isNaN(day) || isNaN(month) || isNaN(year)) return null;
    return { day, month, year };
  };

  const formatDate = (day: number, month: number, year: number) => {
    return `${day.toString().padStart(2, '0')}/${month.toString().padStart(2, '0')}/${year}`;
  };

  const calculateEndDate = (startDay: number, startMonth: number, startYear: number, months: number) => {
    // End Date = Start Date + Months - 1
    const date = new Date(startYear, startMonth - 1 + months - 1, startDay);
    return {
      day: date.getDate(),
      month: date.getMonth() + 1,
      year: date.getFullYear()
    };
  };

  const calculateRemainingMonths = (endMonth: number, endYear: number) => {
    // Start Counting From: March 2026
    const startCount = new Date(START_COUNTING_YEAR, START_COUNTING_MONTH, 1);
    const endCount = new Date(endYear, endMonth - 1, 1);

    if (endCount < startCount) return 0;

    const diffMonths = (endCount.getFullYear() - startCount.getFullYear()) * 12 + (endCount.getMonth() - startCount.getMonth());
    return diffMonths + 1; // Include both start and end months
  };

  const { groupedData, ignoredLinesCount } = useMemo(() => {
    if (!rawData.trim()) return { groupedData: [], ignoredLinesCount: 0 };

    const lines = rawData.split('\n');
    const groups: Record<string, number> = {};
    let ignored = 0;

    lines.forEach(line => {
      const trimmed = line.trim();
      if (!trimmed) return;

      // Pattern recognition
      // 1. Find date: DD-MM-YYYY or DD/MM/YYYY
      const dateRegex = /\b(\d{1,2})[-/](\d{1,2})[-/](\d{4})\b/;
      const dateMatch = trimmed.match(dateRegex);
      
      if (!dateMatch) {
        ignored++;
        return;
      }

      const startDateStr = dateMatch[0];
      const parsedStart = parseDate(startDateStr);
      if (!parsedStart) {
        ignored++;
        return;
      }

      // 2. Remove date from line to find numbers
      const lineWithoutDate = trimmed.replace(dateMatch[0], ' ');
      
      // 3. Find all numbers (handling commas)
      const parts = lineWithoutDate.split(/\s+/);
      const numbers: number[] = [];
      
      parts.forEach(part => {
        // Remove commas and check if it's a valid number
        const cleanPart = part.replace(/,/g, '');
        if (cleanPart && !isNaN(Number(cleanPart)) && /^-?\d+(\.\d+)?$/.test(cleanPart)) {
          numbers.push(Number(cleanPart));
        }
      });

      if (numbers.length < 2) {
        ignored++;
        return;
      }

      // Heuristic: Last two numbers are Amount and Months
      const months = Math.round(numbers[numbers.length - 1]);
      const amount = numbers[numbers.length - 2];

      const normalizedStart = formatDate(parsedStart.day, parsedStart.month, parsedStart.year);
      const key = `${normalizedStart}|${months}`;

      groups[key] = (groups[key] || 0) + amount;
    });

    const result: ZakatGroup[] = [];
    Object.entries(groups).forEach(([key, totalAmount]) => {
      const [startDateStr, months] = key.split('|');
      const m = parseInt(months, 10);
      const start = parseDate(startDateStr)!;
      
      const end = calculateEndDate(start.day, start.month, start.year, m);
      const normalizedEnd = formatDate(end.day, end.month, end.year);

      // IF End Date < March 2026 -> Ignore completely
      const endObj = new Date(end.year, end.month - 1, 1);
      const march2026 = new Date(START_COUNTING_YEAR, START_COUNTING_MONTH, 1);

      if (endObj < march2026) return;

      const remainingMonths = calculateRemainingMonths(end.month, end.year);
      const remainingAmount = totalAmount * remainingMonths;

      result.push({
        startDate: startDateStr,
        endDate: normalizedEnd,
        monthlyAmount: totalAmount,
        months: m,
        remainingMonths,
        remainingAmount
      });
    });

    // Sort by start date
    const sorted = result.sort((a, b) => {
      const da = parseDate(a.startDate)!;
      const db = parseDate(b.startDate)!;
      return new Date(da.year, da.month - 1, da.day).getTime() - new Date(db.year, db.month - 1, db.day).getTime();
    });

    return { groupedData: sorted, ignoredLinesCount: ignored };
  }, [rawData]);

  const zakatBase = useMemo(() => {
    return groupedData.reduce((acc, curr) => acc + curr.remainingAmount, 0);
  }, [groupedData]);

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Warning for Ignored Lines */}
      {ignoredLinesCount > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-center gap-3 text-amber-700 animate-pulse">
          <AlertCircle size={20} />
          <p className="text-sm font-bold">
            {language === 'ar' 
              ? `تم تجاهل ${ignoredLinesCount} أسطر بسبب أخطاء في التنسيق` 
              : `${ignoredLinesCount} lignes ont été ignorées en raison de problèmes de format`}
          </p>
        </div>
      )}
      <div className="bg-white border border-zinc-200 rounded-3xl p-8 shadow-sm">
        <div className="flex items-center gap-4 mb-6">
          <div className="bg-emerald-100 text-emerald-600 p-3 rounded-2xl">
            <Calculator size={32} />
          </div>
          <div>
            <h3 className="text-2xl font-black text-zinc-900">{t.zakatModule}</h3>
            <p className="text-zinc-500">{t.zakatDescription}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-zinc-50 rounded-2xl border border-zinc-100 flex items-center gap-4">
            <div className="bg-white p-2 rounded-xl shadow-sm">
              <Calendar className="text-emerald-600" size={20} />
            </div>
            <div>
              <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest">{language === 'ar' ? 'نهاية الحول' : 'Fin du Hawl'}</p>
              <p className="text-sm font-black text-zinc-900">Février 2026</p>
            </div>
          </div>
          <div className="p-4 bg-zinc-50 rounded-2xl border border-zinc-100 flex items-center gap-4">
            <div className="bg-white p-2 rounded-xl shadow-sm">
              <ArrowRight className="text-emerald-600" size={20} />
            </div>
            <div>
              <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest">{language === 'ar' ? 'بدء الحساب من' : 'Début du calcul'}</p>
              <p className="text-sm font-black text-zinc-900">Mars 2026</p>
            </div>
          </div>
        </div>
      </div>

      {/* Input Section */}
      <div className="bg-white border border-zinc-200 rounded-3xl p-8 shadow-sm space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-emerald-100 text-emerald-600 p-2 rounded-xl">
              <ClipboardList size={24} />
            </div>
            <h3 className="text-xl font-bold text-zinc-900">{language === 'ar' ? 'لصق البيانات الخام' : 'Coller les données brutes'}</h3>
          </div>
          {rawData && (
            <button 
              onClick={() => setRawData('')}
              className="text-red-500 hover:text-red-600 p-2 hover:bg-red-50 rounded-xl transition-all flex items-center gap-2 text-sm font-bold"
            >
              <Trash2 size={18} />
              {t.clearData}
            </button>
          )}
        </div>

        <div className="space-y-2">
          <p className="text-xs text-zinc-400 font-medium">
            {language === 'ar' 
              ? 'التنسيق مرن: الاسم، اللقب، المبلغ، التاريخ، والأشهر (الترتيب غير مهم)' 
              : 'Format flexible : Nom, Prénom, Montant, Date, et Mois (l\'ordre n\'est pas strict)'}
          </p>
          <textarea
            value={rawData}
            onChange={(e) => setRawData(e.target.value)}
            placeholder={language === 'ar' 
              ? 'مثال: كشرود يوسف 500.00 02-07-2025 12' 
              : 'Ex: KECHROUD YOUCEF 500.00 02-07-2025 12'}
            className="w-full h-64 p-6 bg-zinc-50 border border-zinc-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all font-mono text-sm resize-none"
          />
        </div>
      </div>

      {groupedData.length > 0 && (
        <>
          {/* Zakat Base Card */}
          <div className="bg-zinc-900 rounded-3xl p-10 text-white shadow-2xl relative overflow-hidden group">
            <div className="absolute -right-10 -top-10 text-white/5 group-hover:scale-110 transition-transform duration-700">
              <Calculator size={240} />
            </div>
            <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-8">
              <div className="space-y-4">
                <div className="bg-emerald-500/20 w-16 h-16 rounded-2xl flex items-center justify-center backdrop-blur-md border border-emerald-500/30">
                  <Calculator size={32} className="text-emerald-400" />
                </div>
                <div>
                  <p className="text-emerald-400 text-xs font-bold uppercase tracking-widest mb-1">{t.totalZakatBase}</p>
                  <h3 className="text-5xl font-black tracking-tight">{formatCurrency(zakatBase)}</h3>
                </div>
              </div>
              <div className="h-px md:h-20 w-full md:w-px bg-white/10" />
              <div className="space-y-4">
                <div className="bg-white/10 w-16 h-16 rounded-2xl flex items-center justify-center backdrop-blur-md border border-white/10">
                  <DollarSign size={32} className="text-white" />
                </div>
                <div>
                  <p className="text-zinc-400 text-xs font-bold uppercase tracking-widest mb-1">{t.zakatAmount} (2.5%)</p>
                  <h3 className="text-5xl font-black tracking-tight text-emerald-400">{formatCurrency(zakatBase * 0.025)}</h3>
                </div>
              </div>
            </div>
          </div>

          {/* Grouped Results Table */}
          <div className="bg-white border border-zinc-200 rounded-3xl overflow-hidden shadow-sm">
            <div className="p-6 border-b border-zinc-100 bg-zinc-50/50 flex items-center gap-3">
              <TableIcon className="text-emerald-600" size={24} />
              <h3 className="text-lg font-bold text-zinc-900">{language === 'ar' ? 'النتائج المجمعة' : 'Résultats groupés'}</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left" dir={isRtl ? 'rtl' : 'ltr'}>
                <thead>
                  <tr className="bg-zinc-50 text-zinc-500 text-[10px] uppercase tracking-wider font-black">
                    <th className="px-6 py-4">{t.startDate}</th>
                    <th className="px-6 py-4">{t.endDate}</th>
                    <th className="px-6 py-4">{t.monthlyInstallment}</th>
                    <th className="px-6 py-4">{t.duration}</th>
                    <th className="px-6 py-4">{t.remainingMonths}</th>
                    <th className="px-6 py-4 text-emerald-600">{t.remainingAfterHawl}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100">
                  {groupedData.map((group, idx) => (
                    <tr key={idx} className="hover:bg-zinc-50 transition-colors group/row">
                      <td className="px-6 py-4 font-mono text-sm text-zinc-600">{group.startDate}</td>
                      <td className="px-6 py-4 font-mono text-sm text-zinc-600">{group.endDate}</td>
                      <td className="px-6 py-4 font-bold text-zinc-900">{formatCurrency(group.monthlyAmount)}</td>
                      <td className="px-6 py-4 text-zinc-500 font-medium">{group.months}</td>
                      <td className="px-6 py-4 font-black text-zinc-900">{group.remainingMonths}</td>
                      <td className="px-6 py-4 font-black text-emerald-600 text-lg">
                        {formatCurrency(group.remainingAmount)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {rawData && groupedData.length === 0 && (
        <div className="bg-red-50 border border-red-100 rounded-3xl p-10 text-center space-y-4">
          <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mx-auto text-red-500 shadow-sm">
            <AlertCircle size={32} />
          </div>
          <div className="space-y-2">
            <h3 className="text-lg font-bold text-red-900">{language === 'ar' ? 'خطأ في معالجة البيانات' : 'Erreur de traitement des données'}</h3>
            <p className="text-red-600 text-sm max-w-md mx-auto">
              {language === 'ar' 
                ? 'يرجى التأكد من أن البيانات المنسوقة تتبع التنسيق الصحيح: الاسم اللقب المبلغ التاريخ الأشهر' 
                : 'Veuillez vous assurer que les données collées suivent le format correct : Nom Prénom Montant Date Mois'}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
