import React, { useState, useRef } from 'react';
import { Language } from '../types';
import { useTranslation } from '../utils/translations';
import { Table, Printer, Download, Eye, Upload, X, FileImage, Scissors, Image as ImageIcon } from 'lucide-react';
import jsPDF from 'jspdf';
import { toJpeg, toPng } from 'html-to-image';

interface PostalCheckPrintProps {
  language: Language;
}

export const PostalCheckPrint: React.FC<PostalCheckPrintProps> = ({ language }) => {
  const t = useTranslation(language);
  const isRtl = language === 'ar';
  
  const [checkImage, setCheckImage] = useState<string | null>(null);
  const [isPreviewMode, setIsPreviewMode] = useState(false);

  const inputRef = useRef<HTMLInputElement>(null);
  const printRef = useRef<HTMLDivElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setCheckImage(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePrint = () => {
    if (!checkImage) return;
    setIsPreviewMode(false);
    setTimeout(() => {
      window.print();
    }, 150);
  };

  const handleDownloadPDF = () => {
    if (!checkImage) return;

    const doc = new jsPDF('l', 'mm', 'a4');
    const pageWidth = 297;
    const pageHeight = 210;
    
    // Optimized dimensions for 3x2 grid with balanced margins
    const topMargin = 3;
    const sideMargin = 6;
    const gap = 3;
    const checkW = 141;
    const checkH = 66;

    doc.setDrawColor(180, 180, 180);
    doc.setLineWidth(0.1); 
    doc.setLineDashPattern([2, 2], 0);

    // Draw 3x2 Grid
    for (let row = 0; row < 3; row++) {
      for (let col = 0; col < 2; col++) {
        const x = sideMargin + (col * (checkW + gap));
        const y = topMargin + (row * (checkH + gap));
        
        doc.addImage(checkImage, 'JPEG', x, y, checkW, checkH, undefined, 'FAST');
        doc.rect(x, y, checkW, checkH);
      }
    }

    // Horizontal Cutting Guides
    for (let i = 1; i < 3; i++) {
      const y = topMargin + (i * checkH) + (i - 0.5) * gap;
      doc.line(0, y, pageWidth, y);
    }

    // Vertical Cutting Guide
    const midX = sideMargin + checkW + (gap / 2);
    doc.line(midX, 0, midX, pageHeight);

    doc.save('Postal_Cheques_Balanced_3x2.pdf');
  };

  const handleDownloadImage = async (format: 'jpg' | 'png') => {
    if (!printRef.current) return;
    
    try {
      // Ensure the element is visible for capture if it's hidden by print styles
      const dataUrl = format === 'jpg' 
        ? await toJpeg(printRef.current, { quality: 0.95, backgroundColor: '#fff', pixelRatio: 2 })
        : await toPng(printRef.current, { pixelRatio: 2 });
        
      const link = document.createElement('a');
      link.download = `Postal_Cheques_Layout.${format}`;
      link.href = dataUrl;
      link.click();
    } catch (err) {
      console.error('Error generating image:', err);
    }
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Controls - Hidden on Print */}
      <div className="bg-white border border-zinc-200 rounded-3xl p-6 shadow-sm space-y-6 no-print">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="bg-emerald-100 p-3 rounded-2xl text-emerald-600">
              <Table size={24} />
            </div>
            <div>
              <h2 className="text-xl font-bold text-zinc-900">{t.postalCheckPrint}</h2>
              <p className="text-sm text-zinc-500">{language === 'ar' ? 'رفع صورة الصك لتوليد صفحة A4 تحتوي على 6 صكوك' : 'Uploadez l\'image du chèque pour générer une page A4 de 6 chèques'}</p>
            </div>
          </div>
          
          {checkImage && (
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsPreviewMode(!isPreviewMode)}
                className="flex items-center gap-2 px-4 py-2 bg-zinc-100 text-zinc-700 rounded-xl font-bold text-xs hover:bg-zinc-200 transition-all"
              >
                <Eye size={14} />
                {language === 'ar' ? 'معاينة' : 'Preview'}
              </button>
              <button
                onClick={handleDownloadPDF}
                className="flex items-center gap-2 px-4 py-2 bg-zinc-800 text-white rounded-xl font-bold text-xs hover:bg-zinc-900 transition-all"
              >
                <Download size={14} />
                PDF
              </button>
              <button
                onClick={() => handleDownloadImage('jpg')}
                className="flex items-center gap-2 px-4 py-2 bg-zinc-100 text-zinc-700 rounded-xl font-bold text-xs hover:bg-zinc-200 transition-all"
              >
                <ImageIcon size={14} />
                JPG
              </button>
              <button
                onClick={() => handleDownloadImage('png')}
                className="flex items-center gap-2 px-4 py-2 bg-zinc-100 text-zinc-700 rounded-xl font-bold text-xs hover:bg-zinc-200 transition-all"
              >
                <ImageIcon size={14} />
                PNG
              </button>
              <button
                onClick={handlePrint}
                className="flex items-center gap-2 px-6 py-2 bg-emerald-600 text-white rounded-xl font-bold text-xs hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-200"
              >
                <Printer size={14} />
                {language === 'ar' ? 'طباعة' : 'Print'}
              </button>
            </div>
          )}
        </div>

        <div className="max-w-xl mx-auto">
          <div 
            onClick={() => inputRef.current?.click()}
            className={`relative group cursor-pointer border-2 border-dashed rounded-3xl p-12 transition-all flex flex-col items-center justify-center gap-4 ${checkImage ? 'border-emerald-200 bg-emerald-50/30' : 'border-zinc-200 hover:border-emerald-300 hover:bg-emerald-50/30'}`}
          >
            <input 
              type="file" 
              ref={inputRef} 
              className="hidden" 
              accept="image/*,.pdf" 
              onChange={handleFileChange} 
            />
            {checkImage ? (
              <>
                <div className="relative w-full aspect-[2/1] rounded-xl overflow-hidden shadow-md border border-emerald-100">
                  <img src={checkImage} alt="Check" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Upload className="text-white" size={32} />
                  </div>
                </div>
                <div className="flex items-center gap-2 text-emerald-700 font-bold text-sm">
                  <FileImage size={18} />
                  {t.uploadCheck}
                </div>
              </>
            ) : (
              <>
                <div className="w-16 h-16 bg-zinc-100 rounded-2xl flex items-center justify-center text-zinc-400 group-hover:text-emerald-500 group-hover:bg-white transition-all">
                  <Upload size={32} />
                </div>
                <div className="text-center">
                  <p className="font-bold text-zinc-700">{t.uploadCheck}</p>
                  <p className="text-xs text-zinc-400 mt-1">JPG, PNG, PDF</p>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Layout Preview / Print View */}
      {checkImage && (
        <div className={`${isPreviewMode ? 'block' : 'hidden print:block'} bg-white border border-zinc-200 shadow-xl mx-auto w-fit relative overflow-hidden`}>
          <style dangerouslySetInnerHTML={{ __html: `
            @media print {
              body * { visibility: hidden; }
              .print-area-check, .print-area-check * { visibility: visible; }
              .print-area-check { 
                position: absolute; 
                left: 0; 
                top: 0; 
                width: 297mm; 
                height: 210mm; 
                padding: 0; 
                margin: 0;
                background: white; 
              }
              .no-print { display: none !important; }
              @page {
                size: A4 landscape;
                margin: 0;
              }
            }
            .check-layout-container {
              width: 297mm;
              height: 210mm;
              background: white;
              position: relative;
              overflow: hidden;
            }
            .cheque-grid {
              display: grid;
              grid-template-columns: repeat(2, 141mm);
              grid-template-rows: repeat(3, 66mm);
              gap: 3mm;
              justify-content: center;
              align-content: center;
              height: 100%;
              position: relative;
              z-index: 1;
            }
            .cheque-item {
              width: 141mm;
              height: 66mm;
              border: 0.1mm dashed #bbb;
              background: #fff;
              box-shadow: 0 0 2mm rgba(0,0,0,0.05);
              overflow: hidden;
            }
            .cheque-item img {
              width: 100%;
              height: 100%;
              object-fit: stretch;
            }
            .guide-line {
              position: absolute;
              z-index: 10;
              pointer-events: none;
            }
            .guide-h {
              height: 0;
              border-top: 0.15mm dashed #999;
              width: 100%;
            }
            .guide-v {
              width: 0;
              border-left: 0.15mm dashed #999;
              height: 100%;
            }
            .safe-margin-indicator {
              position: absolute;
              inset: 5mm;
              border: 0.1mm solid rgba(16, 185, 129, 0.1);
              pointer-events: none;
              z-index: 0;
            }
          `}} />
          
          <div className="print-area-check" ref={printRef}>
            <div className="check-layout-container">
              {/* Safe Margin Visualizer */}
              <div className="safe-margin-indicator" style={{ top: '3mm', bottom: '3mm', left: '6mm', right: '6mm' }} />

              <div className="cheque-grid">
                <div className="cheque-item"><img src={checkImage} alt="" /></div>
                <div className="cheque-item"><img src={checkImage} alt="" /></div>
                <div className="cheque-item"><img src={checkImage} alt="" /></div>
                <div className="cheque-item"><img src={checkImage} alt="" /></div>
                <div className="cheque-item"><img src={checkImage} alt="" /></div>
                <div className="cheque-item"><img src={checkImage} alt="" /></div>
              </div>

              {/* Cutting Guides */}
              <div className="guide-line guide-h" style={{ top: '69mm' }} />
              <div className="guide-line guide-h" style={{ top: '138mm' }} />
              <div className="guide-line guide-v" style={{ left: '148.5mm' }} />
            </div>
          </div>

          {/* Floating Instruction Overlay for Preview */}
          {isPreviewMode && (
            <div className="absolute top-4 right-4 bg-emerald-600 text-white px-4 py-2 rounded-full text-xs font-bold shadow-lg flex items-center gap-2 no-print">
              <Scissors size={14} />
              {language === 'ar' ? 'معاينة التخطيط والقص' : 'Aperçu de la mise en page et découpe'}
            </div>
          )}
        </div>
      )}

      {!checkImage && (
        <div className="bg-zinc-50 border border-zinc-200 rounded-3xl p-12 text-center space-y-4">
          <div className="bg-white w-16 h-16 rounded-2xl flex items-center justify-center mx-auto text-zinc-300 shadow-sm">
            <Table size={32} />
          </div>
          <div className="space-y-1">
            <h3 className="font-bold text-zinc-800">{language === 'ar' ? 'بانتظار صورة الصك' : 'En attente de l\'image du chèque'}</h3>
            <p className="text-sm text-zinc-500 max-w-xs mx-auto">
              {language === 'ar' ? 'يرجى رفع صورة الصك البريدي لتوليد صفحة الطباعة.' : 'Veuillez uploader l\'image du chèque postal pour générer la page d\'impression.'}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
