import React, { useState, useMemo } from 'react';
import { CustomerSummary, Language, CustomerConfig, ManualContract, ManualInstallment } from '../types';
import { useTranslation } from '../utils/translations';
import { 
  Plus, 
  Trash2, 
  Calendar, 
  DollarSign, 
  Hash, 
  Search, 
  ChevronRight, 
  ChevronDown, 
  UserPlus, 
  CreditCard,
  AlertCircle,
  Save,
  X,
  Layers
} from 'lucide-react';
import { formatCurrency } from '../utils/formatters';
import { calculateEndDate } from '../utils/analyzer';

interface CustomerInstallmentsManagerProps {
  summaries: CustomerSummary[];
  configs: Record<string, CustomerConfig>;
  onUpdateConfig: (account: string, reference: string | null, config: CustomerConfig) => void;
  language: Language;
}

export const CustomerInstallmentsManager: React.FC<CustomerInstallmentsManagerProps> = ({ 
  summaries, 
  configs, 
  onUpdateConfig, 
  language 
}) => {
  const t = useTranslation(language);
  const isRtl = language === 'ar';

  const [searchTerm, setSearchTerm] = useState('');
  const [expandedCustomer, setExpandedCustomer] = useState<string | null>(null);
  const [isAddingCustomer, setIsAddingCustomer] = useState(false);
  const [newCustomer, setNewCustomer] = useState({ name: '', account: '' });

  // Local state for editing contracts to avoid frequent DB writes
  const [editingContract, setEditingContract] = useState<{
    account: string;
    contractIndex: number | 'new';
    data: ManualContract;
  } | null>(null);

  const [showBulkAdd, setShowBulkAdd] = useState(false);
  const [bulkData, setBulkData] = useState({
    amount: 0,
    count: 0,
    pastedRefs: ''
  });
  const [bulkError, setBulkError] = useState<string | null>(null);

  const filteredSummaries = useMemo(() => {
    return summaries.filter(s => 
      s.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.customerAccount.includes(searchTerm)
    );
  }, [summaries, searchTerm]);

  const handleAddCustomer = () => {
    if (!newCustomer.name || !newCustomer.account) return;
    
    // Create an empty config for the new customer
    onUpdateConfig(newCustomer.account, null, {
      duration: 12,
      contracts: []
    });
    
    setNewCustomer({ name: '', account: '' });
    setIsAddingCustomer(false);
  };

  const handleSaveContract = () => {
    if (!editingContract) return;

    const { account, contractIndex, data } = editingContract;
    const currentConfig = configs[account] || { duration: 12, contracts: [] };
    const contracts = [...(currentConfig.contracts || [])];

    // Calculate monthly value from installments
    const monthlyValue = data.installments.reduce((sum, inst) => sum + inst.amount, 0);
    const updatedData = { 
      ...data, 
      monthlyValue,
      endDate: calculateEndDate(data.startDate, data.duration)
    };

    if (contractIndex === 'new') {
      const existingIdx = contracts.findIndex(c => c.startDate === updatedData.startDate);
      if (existingIdx >= 0) {
        // Merge installments if start date matches
        contracts[existingIdx] = {
          ...contracts[existingIdx],
          installments: [...contracts[existingIdx].installments, ...updatedData.installments],
          monthlyValue: contracts[existingIdx].monthlyValue + updatedData.monthlyValue
        };
      } else {
        contracts.push(updatedData);
      }
    } else {
      contracts[contractIndex] = updatedData;
    }

    onUpdateConfig(account, null, {
      ...currentConfig,
      contracts
    });

    setEditingContract(null);
  };

  const handleBulkAdd = () => {
    setBulkError(null);
    const { amount, count, pastedRefs } = bulkData;

    if (amount <= 0 || count <= 0 || !pastedRefs.trim()) return;

    // Split by lines, spaces, or commas and remove empty entries
    const references = pastedRefs
      .split(/[\n\s,]+/)
      .map(ref => ref.trim())
      .filter(ref => ref.length > 0);

    if (references.length !== count) {
      setBulkError(t.errorCountMismatch);
      return;
    }

    const newInstallments: ManualInstallment[] = [];
    const existingRefs = new Set(editingContract?.data.installments.map(i => i.reference) || []);

    for (const reference of references) {
      if (existingRefs.has(reference)) {
        setBulkError(t.errorDuplicateReference);
        return;
      }
      
      newInstallments.push({ reference, amount });
    }

    if (editingContract) {
      setEditingContract({
        ...editingContract,
        data: {
          ...editingContract.data,
          installments: [...editingContract.data.installments, ...newInstallments]
        }
      });
    }

    setShowBulkAdd(false);
    setBulkData({ amount: 0, count: 0, pastedRefs: '' });
  };

  const handleDeleteContract = (account: string, index: number) => {
    const currentConfig = configs[account];
    if (!currentConfig || !currentConfig.contracts) return;

    const contracts = currentConfig.contracts.filter((_, i) => i !== index);
    onUpdateConfig(account, null, {
      ...currentConfig,
      contracts
    });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {/* Header & Search */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm">
        <div className="relative flex-1 max-w-md">
          <Search className={`absolute ${isRtl ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2 text-zinc-400`} size={18} />
          <input
            type="text"
            placeholder={t.searchPlaceholder}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className={`w-full ${isRtl ? 'pr-10 pl-4' : 'pl-10 pr-4'} py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all text-sm font-medium`}
          />
        </div>
        <button
          onClick={() => setIsAddingCustomer(true)}
          className="flex items-center gap-2 px-6 py-3 bg-zinc-900 text-white rounded-xl font-bold text-sm hover:bg-zinc-800 transition-all shadow-lg shadow-zinc-200"
        >
          <UserPlus size={18} />
          {t.addCustomer}
        </button>
      </div>

      {/* Add Customer Modal */}
      {isAddingCustomer && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md p-8 shadow-2xl animate-in zoom-in duration-300">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-black text-zinc-900">{t.addCustomer}</h3>
              <button onClick={() => setIsAddingCustomer(false)} className="p-2 hover:bg-zinc-100 rounded-full transition-colors">
                <X size={20} />
              </button>
            </div>
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">{t.customerName}</label>
                <input
                  type="text"
                  value={newCustomer.name}
                  onChange={(e) => setNewCustomer({ ...newCustomer, name: e.target.value })}
                  className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">{t.accountNumber}</label>
                <input
                  type="text"
                  value={newCustomer.account}
                  onChange={(e) => setNewCustomer({ ...newCustomer, account: e.target.value })}
                  className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                />
              </div>
              <button
                onClick={handleAddCustomer}
                className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-black text-sm hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100 mt-4"
              >
                {t.save}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Legend */}
      <div className="flex flex-wrap items-center gap-6 px-6 py-4 bg-white rounded-2xl border border-zinc-200 shadow-sm">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-blue-500"></div>
          <span className="text-[10px] font-black text-zinc-500 uppercase tracking-wider">{t.paidOnTime}</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
          <span className="text-[10px] font-black text-zinc-500 uppercase tracking-wider">{t.paidLate}</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-red-500"></div>
          <span className="text-[10px] font-black text-zinc-500 uppercase tracking-wider">{t.unpaid}</span>
        </div>
      </div>

      {/* Customer List */}
      <div className="space-y-4">
        {filteredSummaries.map(customer => {
          const config = configs[customer.customerAccount] || { duration: 12, contracts: [] };
          const contracts = config.contracts || [];
          const isExpanded = expandedCustomer === customer.customerAccount;

          return (
            <div key={customer.customerAccount} className="bg-white border border-zinc-200 rounded-3xl overflow-hidden shadow-sm transition-all">
              <div 
                className="p-6 flex items-center justify-between cursor-pointer hover:bg-zinc-50/50 transition-colors"
                onClick={() => setExpandedCustomer(isExpanded ? null : customer.customerAccount)}
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-zinc-100 rounded-2xl flex items-center justify-center text-zinc-600 font-black">
                    {customer.customerName.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-black text-zinc-900">{customer.customerName}</h4>
                    <p className="text-xs text-zinc-500 font-mono">{customer.customerAccount}</p>
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-right hidden sm:block">
                    <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">{language === 'ar' ? 'العقود' : 'Contrats'}</p>
                    <p className="font-black text-zinc-900">{contracts.length}</p>
                  </div>
                  {isExpanded ? <ChevronDown size={20} className="text-zinc-400" /> : <ChevronRight size={20} className="text-zinc-400" />}
                </div>
              </div>

              {isExpanded && (
                <div className="p-6 border-t border-zinc-100 bg-zinc-50/30 space-y-6">
                  <div className="flex items-center justify-between">
                    <h5 className="text-xs font-black text-zinc-400 uppercase tracking-widest">{t.allInstallments}</h5>
                    <button
                      onClick={() => setEditingContract({
                        account: customer.customerAccount,
                        contractIndex: 'new',
                        data: {
                          startDate: '',
                          endDate: '',
                          duration: 12,
                          monthlyValue: 0,
                          installments: []
                        }
                      })}
                      className="flex items-center gap-2 px-4 py-2 bg-emerald-50 text-emerald-700 rounded-xl font-bold text-xs hover:bg-emerald-100 transition-all"
                    >
                      <Plus size={14} />
                      {t.addContract}
                    </button>
                  </div>

                  {contracts.length === 0 ? (
                    <div className="py-12 text-center text-zinc-400 bg-white rounded-2xl border border-dashed border-zinc-200">
                      <CreditCard size={32} className="mx-auto mb-2 opacity-20" />
                      <p className="text-sm font-medium">{t.noData}</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {contracts.map((contract, idx) => (
                        <div key={idx} className="bg-white rounded-2xl border border-zinc-200 shadow-sm overflow-hidden">
                          <div className="p-6 bg-zinc-50/50 border-b border-zinc-100 flex flex-wrap items-center justify-between gap-4">
                            <div className="flex items-center gap-4">
                              <div className="w-10 h-10 bg-emerald-100 rounded-xl flex items-center justify-center text-emerald-600">
                                <Calendar size={20} />
                              </div>
                              <div>
                                <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">{t.startDate}</p>
                                <p className="text-base font-black text-zinc-900">{contract.startDate}</p>
                              </div>
                              <div className="h-8 w-px bg-zinc-200 mx-2 hidden sm:block"></div>
                              <div>
                                <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">{t.endDate}</p>
                                <p className="text-base font-black text-zinc-900">{contract.endDate}</p>
                              </div>
                              <div className="h-8 w-px bg-zinc-200 mx-2 hidden sm:block"></div>
                              <div>
                                <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">{t.duration}</p>
                                <p className="text-base font-black text-zinc-900">{contract.duration} m</p>
                              </div>
                            </div>
                            
                            <div className="flex items-center gap-3">
                              <div className="text-right">
                                <p className="text-[10px] text-emerald-600 font-bold uppercase tracking-wider">{t.totalMonthly}</p>
                                <p className="text-lg font-black text-emerald-700">{formatCurrency(contract.monthlyValue)}</p>
                              </div>
                              <div className="flex items-center gap-1">
                                <button
                                  onClick={() => setEditingContract({
                                    account: customer.customerAccount,
                                    contractIndex: idx,
                                    data: { ...contract }
                                  })}
                                  className="p-2 hover:bg-white rounded-lg text-zinc-400 hover:text-emerald-600 transition-all shadow-sm border border-transparent hover:border-zinc-200"
                                >
                                  <ChevronRight size={18} />
                                </button>
                                <button
                                  onClick={() => handleDeleteContract(customer.customerAccount, idx)}
                                  className="p-2 hover:bg-red-50 rounded-lg text-zinc-400 hover:text-red-600 transition-all"
                                >
                                  <Trash2 size={18} />
                                </button>
                              </div>
                            </div>
                          </div>

                          <div className="overflow-x-auto">
                            <table className="w-full text-left border-collapse">
                              <thead>
                                <tr className="bg-zinc-50/30">
                                  <th className="px-6 py-3 text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-100">{t.referenceCode}</th>
                                  <th className="px-6 py-3 text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-100">{t.amount}</th>
                                  <th className="px-6 py-3 text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-100">{t.paymentMonth}</th>
                                  <th className="px-6 py-3 text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-100 text-right">{t.status}</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-zinc-50">
                                {contract.installments.map((inst, i) => {
                                  const loan = customer.loans.find(l => l.startDate === contract.startDate);
                                  const instRecords = loan?.records.filter(r => r.fullReference === inst.reference) || [];
                                  
                                  // Find the "best" status: On Time > Late > Unpaid
                                  let status = 'unpaid';
                                  let month = '---';
                                  
                                  if (instRecords.some(r => r.statusCode === "000")) {
                                    status = 'onTime';
                                    const r = instRecords.find(r => r.statusCode === "000");
                                    if (r) {
                                      const dateParts = r.installmentDate.split('/');
                                      if (dateParts.length === 3) month = `${dateParts[1]}/${dateParts[2]}`;
                                    }
                                  } else if (instRecords.some(r => r.statusCode >= "001" && r.statusCode <= "027")) {
                                    status = 'late';
                                    const r = instRecords.find(r => r.statusCode >= "001" && r.statusCode <= "027");
                                    if (r) {
                                      const dateParts = r.installmentDate.split('/');
                                      if (dateParts.length === 3) month = `${dateParts[1]}/${dateParts[2]}`;
                                    }
                                  } else if (instRecords.length > 0) {
                                    status = 'unpaid';
                                  }

                                  const statusColors = {
                                    onTime: 'bg-blue-100 text-blue-700',
                                    late: 'bg-emerald-100 text-emerald-700',
                                    unpaid: 'bg-red-100 text-red-700'
                                  };

                                  const statusLabels = {
                                    onTime: t.paidOnTime,
                                    late: t.paidLate,
                                    unpaid: t.unpaid
                                  };

                                  return (
                                    <tr key={i} className="hover:bg-zinc-50/20 transition-colors">
                                      <td className="px-6 py-4 text-sm font-mono font-bold text-zinc-600">{inst.reference}</td>
                                      <td className="px-6 py-4 text-sm font-black text-zinc-900">{formatCurrency(inst.amount)}</td>
                                      <td className="px-6 py-4 text-sm font-medium text-zinc-400">{month}</td>
                                      <td className="px-6 py-4 text-right">
                                        <span className={`px-2 py-1 rounded-md text-[10px] font-bold uppercase ${statusColors[status as keyof typeof statusColors]}`}>
                                          {statusLabels[status as keyof typeof statusLabels]}
                                        </span>
                                      </td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                              <tfoot>
                                <tr className="bg-zinc-50/50">
                                  <td className="px-6 py-4 text-xs font-black text-zinc-500 uppercase tracking-wider">{t.groupTotal}</td>
                                  <td className="px-6 py-4 text-base font-black text-emerald-600" colSpan={2}>
                                    {formatCurrency(contract.monthlyValue)}
                                  </td>
                                </tr>
                              </tfoot>
                            </table>
                          </div>
                          <div className="p-6 bg-white border-t border-zinc-100">
                            <div className="flex items-center gap-2 mb-4">
                              <Layers size={16} className="text-zinc-400" />
                              <h6 className="text-xs font-black text-zinc-900 uppercase tracking-widest">{t.monthlyAnalysis}</h6>
                            </div>
                            
                            <div className="overflow-x-auto">
                              <table className="w-full text-left border-collapse">
                                <thead>
                                  <tr>
                                    <th className="px-4 py-2 text-[10px] font-black text-zinc-400 uppercase border-b border-zinc-50">{t.paymentMonth}</th>
                                    <th className="px-4 py-2 text-[10px] font-black text-zinc-400 uppercase border-b border-zinc-50">{t.expected}</th>
                                    <th className="px-4 py-2 text-[10px] font-black text-blue-600 uppercase border-b border-zinc-50">{t.paidOnTime}</th>
                                    <th className="px-4 py-2 text-[10px] font-black text-emerald-600 uppercase border-b border-zinc-50">{t.paidLate}</th>
                                    <th className="px-4 py-2 text-[10px] font-black text-zinc-900 uppercase border-b border-zinc-50">{t.collected}</th>
                                    <th className="px-4 py-2 text-[10px] font-black text-red-600 uppercase border-b border-zinc-50">{t.unpaid}</th>
                                    <th className="px-4 py-2 text-[10px] font-black text-zinc-400 uppercase border-b border-zinc-50">{t.difference}</th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-zinc-50">
                                  {(() => {
                                    const loan = customer.loans.find(l => l.startDate === contract.startDate);
                                    if (!loan) return null;
                                    
                                    return loan.monthlyBreakdown.map((mb, i) => {
                                      const collected = mb.paidOnTimeCount * mb.installmentAmount + mb.paidLateCount * mb.installmentAmount;
                                      const unpaid = mb.unpaidCount * mb.installmentAmount;
                                      const diff = mb.installmentAmount - collected;
                                      
                                      return (
                                        <tr key={i} className="text-xs">
                                          <td className="px-4 py-2 font-bold text-zinc-600">{mb.monthYear}</td>
                                          <td className="px-4 py-2 font-black text-zinc-900">{formatCurrency(mb.installmentAmount)}</td>
                                          <td className="px-4 py-2 font-bold text-blue-600">{formatCurrency(mb.paidOnTimeCount * mb.installmentAmount)}</td>
                                          <td className="px-4 py-2 font-bold text-emerald-600">{formatCurrency(mb.paidLateCount * mb.installmentAmount)}</td>
                                          <td className="px-4 py-2 font-black text-zinc-900">{formatCurrency(collected)}</td>
                                          <td className="px-4 py-2 font-bold text-red-600">{formatCurrency(unpaid)}</td>
                                          <td className={`px-4 py-2 font-black ${diff > 0 ? 'text-red-500' : 'text-emerald-500'}`}>
                                            {formatCurrency(diff)}
                                          </td>
                                        </tr>
                                      );
                                    });
                                  })()}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Bulk Add Modal */}
      {showBulkAdd && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md p-8 shadow-2xl animate-in zoom-in duration-300">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-black text-zinc-900">{t.bulkAddInstallments}</h3>
              <button onClick={() => setShowBulkAdd(false)} className="p-2 hover:bg-zinc-100 rounded-full transition-colors">
                <X size={20} />
              </button>
            </div>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">{t.singleInstallmentAmount}</label>
                  <input
                    type="number"
                    value={bulkData.amount}
                    onChange={(e) => setBulkData({ ...bulkData, amount: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm font-bold focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">{t.numberOfRepetitions}</label>
                  <input
                    type="number"
                    value={bulkData.count}
                    onChange={(e) => setBulkData({ ...bulkData, count: parseInt(e.target.value) || 0 })}
                    className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm font-bold focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">{t.pasteReferences}</label>
                <textarea
                  placeholder="001/2025&#10;005/2025&#10;020/2025"
                  value={bulkData.pastedRefs}
                  onChange={(e) => setBulkData({ ...bulkData, pastedRefs: e.target.value })}
                  rows={5}
                  className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm font-bold focus:ring-2 focus:ring-indigo-500 outline-none transition-all resize-none"
                />
                <p className="text-[10px] text-zinc-400 italic">
                  {language === 'ar' ? 'افصل بين المراجع بأسطر أو مسافات أو فواصل' : 'Séparez les références par des lignes, des espaces ou des virgules'}
                </p>
              </div>

              {bulkError && (
                <div className="flex items-center gap-2 p-3 bg-red-50 text-red-600 rounded-xl text-xs font-bold">
                  <AlertCircle size={14} />
                  {bulkError}
                </div>
              )}

              <button
                onClick={handleBulkAdd}
                className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-black text-sm hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 mt-4"
              >
                {t.generate}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Contract Modal */}
      {editingContract && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-2xl p-8 shadow-2xl animate-in zoom-in duration-300 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h3 className="text-xl font-black text-zinc-900">{t.contractDetails}</h3>
                <p className="text-sm text-zinc-500">{editingContract.account}</p>
              </div>
              <button onClick={() => setEditingContract(null)} className="p-2 hover:bg-zinc-100 rounded-full transition-colors">
                <X size={20} />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="space-y-2">
                <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">{t.startDate}</label>
                <input
                  type="text"
                  placeholder="DD/MM/YYYY"
                  value={editingContract.data.startDate}
                  onChange={(e) => setEditingContract({
                    ...editingContract,
                    data: { ...editingContract.data, startDate: e.target.value }
                  })}
                  className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">{t.duration}</label>
                <input
                  type="number"
                  value={editingContract.data.duration}
                  onChange={(e) => setEditingContract({
                    ...editingContract,
                    data: { ...editingContract.data, duration: parseInt(e.target.value) || 12 }
                  })}
                  className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                />
              </div>
              <div className="flex items-end pb-1">
                <div className="flex items-center gap-3 bg-emerald-50 px-4 py-3 rounded-xl w-full">
                  <div className="text-emerald-600"><AlertCircle size={16} /></div>
                  <div>
                    <p className="text-[10px] text-emerald-600 font-bold uppercase tracking-wider">{t.endDate}</p>
                    <p className="text-sm font-black text-emerald-700">
                      {calculateEndDate(editingContract.data.startDate, editingContract.data.duration) || '---'}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4 mb-8">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-black text-zinc-900 uppercase tracking-widest">{language === 'ar' ? 'الأقساط' : 'Mensualités'}</h4>
                <div className="flex gap-2">
                  <button
                    onClick={() => setShowBulkAdd(true)}
                    className="flex items-center gap-2 px-3 py-1.5 bg-indigo-50 text-indigo-700 rounded-lg font-bold text-[10px] hover:bg-indigo-100 transition-all"
                  >
                    <Layers size={12} />
                    {t.bulkAddInstallments}
                  </button>
                  <button
                    onClick={() => setEditingContract({
                      ...editingContract,
                      data: {
                        ...editingContract.data,
                        installments: [...editingContract.data.installments, { reference: '', amount: 0 }]
                      }
                    })}
                    className="flex items-center gap-2 px-3 py-1.5 bg-zinc-100 text-zinc-700 rounded-lg font-bold text-[10px] hover:bg-zinc-200 transition-all"
                  >
                    <Plus size={12} />
                    {t.addInstallment}
                  </button>
                </div>
              </div>

              <div className="space-y-3">
                {editingContract.data.installments.map((inst, i) => (
                  <div key={i} className="flex items-center gap-4 bg-zinc-50 p-4 rounded-2xl border border-zinc-100">
                    <div className="flex-1 grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-zinc-400 uppercase">{t.referenceCode}</label>
                        <input
                          type="text"
                          value={inst.reference}
                          onChange={(e) => {
                            const newInsts = [...editingContract.data.installments];
                            newInsts[i].reference = e.target.value;
                            setEditingContract({ ...editingContract, data: { ...editingContract.data, installments: newInsts } });
                          }}
                          className="w-full bg-white border border-zinc-200 rounded-lg px-3 py-2 text-xs font-bold outline-none focus:ring-2 focus:ring-emerald-500"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-zinc-400 uppercase">{t.amount}</label>
                        <input
                          type="number"
                          value={inst.amount}
                          onChange={(e) => {
                            const newInsts = [...editingContract.data.installments];
                            newInsts[i].amount = parseFloat(e.target.value) || 0;
                            setEditingContract({ ...editingContract, data: { ...editingContract.data, installments: newInsts } });
                          }}
                          className="w-full bg-white border border-zinc-200 rounded-lg px-3 py-2 text-xs font-bold outline-none focus:ring-2 focus:ring-emerald-500"
                        />
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        const newInsts = editingContract.data.installments.filter((_, idx) => idx !== i);
                        setEditingContract({ ...editingContract, data: { ...editingContract.data, installments: newInsts } });
                      }}
                      className="p-2 text-zinc-300 hover:text-red-500 transition-colors"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))}
                {editingContract.data.installments.length === 0 && (
                  <div className="py-8 text-center text-zinc-400 text-xs italic">
                    {language === 'ar' ? 'لم يتم إضافة أقساط بعد' : 'Aucune mensualité ajoutée'}
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center justify-between pt-6 border-t border-zinc-100">
              <div className="flex items-center gap-6">
                <div>
                  <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">{t.totalMonthly}</p>
                  <p className="text-lg font-black text-emerald-600">
                    {formatCurrency(editingContract.data.installments.reduce((sum, i) => sum + i.amount, 0))}
                  </p>
                </div>
                <div>
                  <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">{t.contractValue}</p>
                  <p className="text-lg font-black text-zinc-900">
                    {formatCurrency(editingContract.data.installments.reduce((sum, i) => sum + i.amount, 0) * editingContract.data.duration)}
                  </p>
                </div>
              </div>
              <button
                onClick={handleSaveContract}
                className="flex items-center gap-2 px-8 py-4 bg-emerald-600 text-white rounded-2xl font-black text-sm hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100"
              >
                <Save size={18} />
                {t.save}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
