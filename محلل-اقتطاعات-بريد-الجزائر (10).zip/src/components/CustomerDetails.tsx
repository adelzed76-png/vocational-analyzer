import React from 'react';
import { CustomerSummary, PaymentStatus, Language, RawRecord, CustomerConfig } from '../types';
import { getStatusFromCode } from '../utils/parser';
import { getInstallmentMonth } from '../utils/analyzer';
import { X, Calendar, FileText, TrendingUp, Download, Table, AlertCircle, CheckCircle2, XCircle, Clock, Ban, DollarSign, Wallet, Hash, Eye, Lock, HelpCircle } from 'lucide-react';
import { StatusBadge } from './StatusBadge';
import { exportCustomerReportToExcel, exportCustomerReportToPDF } from '../utils/reports';
import { formatCurrency } from '../utils/formatters';
import { useTranslation } from '../utils/translations';

interface CustomerDetailsProps {
  customer: CustomerSummary;
  onClose: () => void;
  onUpdateConfig: (customerAccount: string, reference: string | null, config: CustomerConfig) => void;
  language: Language;
}

export const CustomerDetails: React.FC<CustomerDetailsProps> = ({ customer, onClose, onUpdateConfig, language }) => {
  const t = useTranslation(language);
  const isRtl = language === 'ar';

  const [isEditingConfig, setIsEditingConfig] = React.useState(false);
  const [editDuration, setEditDuration] = React.useState(customer.loans[0]?.installmentDuration || 12);
  const [editStartDate, setEditStartDate] = React.useState(customer.loans[0]?.startDate || '');
  const [editNonCollectable, setEditNonCollectable] = React.useState(customer.nonCollectableDebt || false);

  const handleSaveConfig = () => {
    onUpdateConfig(customer.customerAccount, null, {
      duration: Number(editDuration),
      startDate: editStartDate,
      nonCollectableDebt: editNonCollectable
    });
    setIsEditingConfig(false);
  };

  const getStatusIcon = (status: PaymentStatus) => {
    switch (status) {
      case PaymentStatus.PAID_ON_TIME:
        return <CheckCircle2 className="text-blue-500" size={20} />;
      case PaymentStatus.PAID_LATE:
        return <CheckCircle2 className="text-emerald-500" size={20} />;
      case PaymentStatus.NOT_PAID:
        return <XCircle className="text-red-500" size={20} />;
      case PaymentStatus.UNDER_MONITORING:
        return <Eye className="text-amber-500" size={20} />;
      case PaymentStatus.ACCOUNT_BLOCKED:
        return <Lock className="text-zinc-900" size={20} />;
      case PaymentStatus.MONITORING_FAILURE:
        return <XCircle className="text-red-500" size={20} />;
      case PaymentStatus.OVER_DEDUCTION:
        return <AlertCircle className="text-amber-500" size={20} />;
      case PaymentStatus.STOP_LIST:
        return <Ban className="text-zinc-400" size={20} />;
      default:
        return <HelpCircle className="text-zinc-300" size={20} />;
    }
  };

  const getStatusColor = (status: PaymentStatus) => {
    switch (status) {
      case PaymentStatus.PAID_ON_TIME:
        return "bg-blue-50 border-blue-100 text-blue-700";
      case PaymentStatus.PAID_LATE:
        return "bg-emerald-50 border-emerald-100 text-emerald-700";
      case PaymentStatus.NOT_PAID:
        return "bg-red-50 border-red-100 text-red-700";
      case PaymentStatus.UNDER_MONITORING:
        return "bg-amber-50 border-amber-100 text-amber-700";
      case PaymentStatus.ACCOUNT_BLOCKED:
        return "bg-zinc-100 border-zinc-900 text-zinc-900";
      case PaymentStatus.MONITORING_FAILURE:
        return "bg-red-50 border-red-100 text-red-700";
      case PaymentStatus.OVER_DEDUCTION:
        return "bg-amber-50 border-amber-100 text-amber-700";
      case PaymentStatus.STOP_LIST:
        return "bg-zinc-50 border-zinc-200 text-zinc-500";
      default:
        return "bg-zinc-50 border-zinc-100 text-zinc-600";
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className={`bg-white w-full max-w-4xl max-h-[90vh] rounded-3xl shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95 duration-200 ${isRtl ? 'text-right' : 'text-left'}`} dir={isRtl ? 'rtl' : 'ltr'}>
        <div className="p-6 border-b border-zinc-100 flex items-center justify-between bg-zinc-50">
          <div className="flex items-center gap-4">
            <div className="bg-emerald-100 p-3 rounded-2xl text-emerald-600">
              <FileText size={24} />
            </div>
            <div>
              <h2 className="text-xl font-bold text-zinc-900">{customer.customerName}</h2>
              <p className="text-sm text-zinc-500 font-mono">{t.accountNumber}: {customer.customerAccount}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-zinc-200 rounded-full transition-colors">
            <X size={24} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-8">
          {/* Configuration Section */}
          <div className="bg-zinc-50 border border-zinc-200 rounded-3xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-white p-2 rounded-xl border border-zinc-200 text-zinc-600 shadow-sm">
                  <Calendar size={18} />
                </div>
                <h3 className="font-black text-zinc-800">{language === 'ar' ? 'إعدادات الأقساط' : 'Configuration des Échéances'}</h3>
              </div>
              {!isEditingConfig ? (
                <button 
                  onClick={() => setIsEditingConfig(true)}
                  className="text-xs font-bold text-emerald-600 hover:text-emerald-700 underline underline-offset-4"
                >
                  {language === 'ar' ? 'تعديل' : 'Modifier'}
                </button>
              ) : (
                <div className="flex gap-2">
                  <button 
                    onClick={() => setIsEditingConfig(false)}
                    className="text-xs font-bold text-zinc-400 hover:text-zinc-600"
                  >
                    {language === 'ar' ? 'إلغاء' : 'Annuler'}
                  </button>
                  <button 
                    onClick={handleSaveConfig}
                    className="text-xs font-bold text-emerald-600 hover:text-emerald-700"
                  >
                    {language === 'ar' ? 'حفظ' : 'Enregistrer'}
                  </button>
                </div>
              )}
            </div>

            {isEditingConfig ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 animate-in fade-in duration-300">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">{language === 'ar' ? 'تاريخ البدء' : 'Date de début'}</label>
                  <input 
                    type="month" 
                    value={editStartDate}
                    onChange={(e) => setEditStartDate(e.target.value)}
                    className="w-full bg-white border border-zinc-200 rounded-xl px-4 py-2 text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">{language === 'ar' ? 'المدة (أشهر)' : 'Durée (mois)'}</label>
                  <select 
                    value={editDuration}
                    onChange={(e) => setEditDuration(Number(e.target.value))}
                    className="w-full bg-white border border-zinc-200 rounded-xl px-4 py-2 text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none"
                  >
                    {[12, 15, 18, 45, 48, 60].map(d => (
                      <option key={d} value={d}>{d} {language === 'ar' ? 'شهر' : 'mois'}</option>
                    ))}
                  </select>
                </div>
                <div className="sm:col-span-2 flex items-center gap-3 bg-white p-3 rounded-xl border border-zinc-200">
                  <input 
                    type="checkbox" 
                    id="nonCollectable"
                    checked={editNonCollectable}
                    onChange={(e) => setEditNonCollectable(e.target.checked)}
                    className="w-5 h-5 text-emerald-600 border-zinc-300 rounded focus:ring-emerald-500"
                  />
                  <label htmlFor="nonCollectable" className="text-sm font-bold text-zinc-700 cursor-pointer">
                    {language === 'ar' ? 'دين غير قابل للتحصيل (يستثنى من الزكاة)' : 'Dette non recouvrable (Exclu de la Zakat)'}
                  </label>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-8">
                <div>
                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1">{language === 'ar' ? 'تاريخ البدء' : 'Date de début'}</p>
                  <p className="text-sm font-black text-zinc-700">{customer.loans[0]?.startDate || '---'}</p>
                </div>
                <div>
                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1">{language === 'ar' ? 'المدة' : 'Durée'}</p>
                  <p className="text-sm font-black text-zinc-700">{customer.loans[0]?.installmentDuration || '---'} {language === 'ar' ? 'شهر' : 'mois'}</p>
                </div>
                <div>
                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1">{language === 'ar' ? 'تاريخ الانتهاء' : 'Date de fin'}</p>
                  <p className="text-sm font-black text-zinc-700">{customer.loans[0]?.endDate || '---'}</p>
                </div>
                {customer.nonCollectableDebt && (
                  <div className="bg-red-100 px-3 py-1 rounded-lg border border-red-200">
                    <p className="text-[10px] font-bold text-red-600 uppercase tracking-wider">{language === 'ar' ? 'دين غير قابل للتحصيل' : 'Dette non recouvrable'}</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {customer.isStopList && (
            <div className="bg-red-50 border border-red-200 p-4 rounded-2xl flex items-center gap-3 text-red-700 animate-pulse">
              <AlertCircle size={24} />
              <p className="font-black text-sm">{language === 'ar' ? 'تم دفع جميع الأقساط لجميع القروض. يرجى إيقاف الاقتطاعات.' : 'Toutes les mensualités de tous les prêts ont été payées. Veuillez arrêter les prélèvements.'}</p>
            </div>
          )}
          
          {/* Global Summary Cards */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <div className="bg-zinc-50 p-4 rounded-2xl border border-zinc-100">
              <p className="text-[10px] text-zinc-500 mb-1 uppercase font-bold">{language === 'ar' ? 'إجمالي القروض' : 'Total Prêts'}</p>
              <p className="text-lg font-black text-zinc-900">{customer.loans.length}</p>
            </div>
            <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100">
              <p className="text-[10px] text-blue-600 mb-1 uppercase font-bold">{language === 'ar' ? 'إجمالي العقد' : 'Total Contrat'}</p>
              <p className="text-lg font-black text-blue-700">{formatCurrency(customer.totalExpected)}</p>
            </div>
            <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-100">
              <p className="text-[10px] text-emerald-600 mb-1 uppercase font-bold">{language === 'ar' ? 'إجمالي المدفوع' : 'Total Collecté'}</p>
              <p className="text-lg font-black text-emerald-700">{formatCurrency(customer.totalCollected)}</p>
            </div>
            <div className="bg-red-50 p-4 rounded-2xl border border-red-100">
              <p className="text-[10px] text-red-600 mb-1 uppercase font-bold">{language === 'ar' ? 'إجمالي غير المدفوع' : 'Total Non Payé'}</p>
              <p className="text-lg font-black text-red-700">{formatCurrency(customer.totalNotCollected)}</p>
            </div>
            <div className="bg-zinc-900 p-4 rounded-2xl text-white">
              <p className="text-[10px] text-zinc-400 mb-1 uppercase font-bold">{language === 'ar' ? 'إجمالي المتبقي' : 'Total Restant'}</p>
              <p className="text-lg font-black">{formatCurrency(customer.totalRemaining)}</p>
            </div>
          </div>

          {/* Loans Details */}
          <div className="space-y-6">
            <h3 className="text-lg font-bold flex items-center gap-2">
              <TrendingUp size={20} className="text-emerald-600" />
              {language === 'ar' ? 'تفاصيل القروض' : 'Détails des Prêts'}
            </h3>

            {customer.loans?.map((loan, lIdx) => (
              <div key={loan.fullReference} className="bg-white border border-zinc-200 rounded-3xl overflow-hidden shadow-sm">
                <div className="p-4 bg-zinc-50 border-b border-zinc-100 flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center border border-zinc-200 font-mono text-xs font-bold text-zinc-500">
                      {lIdx + 1}
                    </div>
                    <div>
                      <h4 className="font-bold text-zinc-800">{loan.fullReference}</h4>
                      <p className="text-[10px] text-zinc-400 font-mono">
                        {loan.installmentAmount.toLocaleString()} DZD x {loan.installmentDuration} {language === 'ar' ? 'شهر' : 'mois'}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <StatusBadge status={loan.latestStatus} showLabel={true} language={language} />
                  </div>
                </div>

                <div className="p-4 grid grid-cols-2 sm:grid-cols-4 gap-4 bg-white">
                  <div>
                    <p className="text-[9px] text-zinc-400 font-bold uppercase">{language === 'ar' ? 'المدفوع' : 'Payé'}</p>
                    <p className="text-sm font-bold text-emerald-600">{formatCurrency(loan.totalCollected)}</p>
                    <p className="text-[9px] text-zinc-400">{loan.monthsPaid} {language === 'ar' ? 'شهر' : 'mois'}</p>
                  </div>
                  <div>
                    <p className="text-[9px] text-zinc-400 font-bold uppercase">{language === 'ar' ? 'غير المدفوع' : 'Non Payé'}</p>
                    <p className="text-sm font-bold text-red-600">{formatCurrency(loan.totalNotCollected)}</p>
                    <p className="text-[9px] text-zinc-400">{loan.monthsMissed} {language === 'ar' ? 'شهر' : 'mois'}</p>
                  </div>
                  <div>
                    <p className="text-[9px] text-zinc-400 font-bold uppercase">{language === 'ar' ? 'المتبقي' : 'Restant'}</p>
                    <p className="text-sm font-bold text-zinc-900">{formatCurrency(loan.totalRemaining)}</p>
                  </div>
                  <div>
                    <p className="text-[9px] text-zinc-400 font-bold uppercase">{language === 'ar' ? 'الفترة' : 'Période'}</p>
                    <p className="text-[10px] font-bold text-zinc-700">{loan.startDate || '---'} - {loan.endDate || '---'}</p>
                  </div>
                </div>

                <div className="p-4 border-t border-zinc-50 bg-zinc-50/20">
                  <div className="flex flex-wrap gap-1">
                    {loan.monthlyBreakdown?.map((m, i) => (
                      <div 
                        key={i} 
                        className={`w-6 h-6 rounded-md flex items-center justify-center text-[8px] font-bold shadow-sm ${
                          m.status === PaymentStatus.PAID_ON_TIME ? 'bg-blue-500 text-white' :
                          m.status === PaymentStatus.PAID_LATE ? 'bg-emerald-500 text-white' :
                          m.status === PaymentStatus.NOT_PAID ? 'bg-red-500 text-white' :
                          m.status === PaymentStatus.ACCOUNT_BLOCKED ? 'bg-zinc-900 text-white' :
                          m.status === PaymentStatus.UNDER_MONITORING ? 'bg-amber-400 text-white' :
                          'bg-zinc-100 text-zinc-400'
                        }`}
                        title={`${m.monthYear}: ${m.status}`}
                      >
                        {i + 1}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="p-6 bg-zinc-50 border-t border-zinc-100 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => exportCustomerReportToExcel(customer)}
              className="flex items-center gap-2 px-4 py-2 bg-white border border-zinc-200 text-zinc-700 rounded-xl text-sm font-bold hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-200 transition-all"
            >
              <Table size={18} />
              {t.exportExcel}
            </button>
            <button
              onClick={() => exportCustomerReportToPDF(customer)}
              className="flex items-center gap-2 px-4 py-2 bg-white border border-zinc-200 text-zinc-700 rounded-xl text-sm font-bold hover:bg-red-50 hover:text-red-700 hover:border-red-200 transition-all"
            >
              <FileText size={18} />
              {t.stopReport} (PDF)
            </button>
          </div>
          <button
            onClick={onClose}
            className="w-full sm:w-auto px-8 py-2 bg-zinc-900 text-white rounded-xl font-bold hover:bg-zinc-800 transition-colors"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};

