import React from 'react';
import { getStatusConfig } from './StatusBadge';
import { PaymentStatus, Language } from '../types';
import { useTranslation } from '../utils/translations';

interface FilterBarProps {
  activeFilter: string | null;
  onFilterChange: (filter: string | null) => void;
  language: Language;
}

export const FilterBar: React.FC<FilterBarProps> = ({ activeFilter, onFilterChange, language }) => {
  const t = useTranslation(language);
  const isRtl = language === 'ar';
  
  const filters = [
    PaymentStatus.PAID_ON_TIME,
    PaymentStatus.PAID_LATE,
    PaymentStatus.UNDER_MONITORING,
    PaymentStatus.NOT_PAID,
    PaymentStatus.ACCOUNT_BLOCKED,
    PaymentStatus.MONITORING_FAILURE,
    "STOP_LIST"
  ];

  return (
    <div className="flex flex-wrap gap-2 mb-6" dir={isRtl ? "rtl" : "ltr"}>
      <button
        onClick={() => onFilterChange(null)}
        className={`px-4 py-1.5 rounded-full text-xs font-bold border transition-all ${
          activeFilter === null 
            ? 'bg-emerald-600 text-white border-emerald-600 shadow-md' 
            : 'bg-white text-zinc-500 border-zinc-200 hover:border-zinc-300'
        }`}
      >
        {isRtl ? 'الكل' : 'Tout'}
      </button>
      
      {filters.map((filter) => {
        const config = getStatusConfig(filter, t);
        const isActive = activeFilter === filter;
        
        return (
          <button
            key={filter}
            onClick={() => onFilterChange(isActive ? null : filter)}
            className={`flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold border transition-all ${
              isActive 
                ? `${config.bgColor} ${config.color} ${config.borderColor} shadow-md ring-2 ring-offset-1 ring-emerald-500/20` 
                : 'bg-white text-zinc-500 border-zinc-200 hover:border-zinc-300'
            }`}
          >
            {config.icon}
            <span>{config.label}</span>
          </button>
        );
      })}
    </div>
  );
};
