import React, { useState, useMemo } from 'react';
import { CustomerSummary, Language, PaymentStatus, RawRecord, LoanSummary, CustomerConfig } from '../types';
import { formatCurrency } from '../utils/formatters';
import { Calendar, Users, TrendingUp, CheckCircle2, AlertCircle, FileText, Search, ArrowLeft, Hash, DollarSign, Clock, Ban } from 'lucide-react';
import { getStatusFromCode } from '../utils/parser';

interface MonthlyInstallmentTrackerProps {
  summaries: CustomerSummary[];
  onUpdateConfig: (account: string, reference: string | null, config: CustomerConfig) => void;
  language: Language;
}

export const MonthlyInstallmentTracker: React.FC<MonthlyInstallmentTrackerProps> = ({ summaries, onUpdateConfig, language }) => {
  const [view, setView] = useState<'landing' | 'search' | 'details'>('landing');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCustomerAccount, setSelectedCustomerAccount] = useState<string | null>(null);
  const [isEditingConfig, setIsEditingConfig] = useState(false);
  const [editDuration, setEditDuration] = useState(12);
  const [editStartDate, setEditStartDate] = useState('');

  const isRtl = language === 'ar';

  const filteredCustomers = useMemo(() => {
    if (!searchQuery.trim()) return [];
    const query = searchQuery.toLowerCase();
    return summaries.filter(c => 
      c.customerName.toLowerCase().includes(query) || 
      c.customerAccount.includes(query)
    ).slice(0, 10);
  }, [summaries, searchQuery]);

  const selectedCustomer = useMemo(() => {
    return summaries.find(c => c.customerAccount === selectedCustomerAccount);
  }, [summaries, selectedCustomerAccount]);

  // Handle customer selection
  const handleSelectCustomer = (account: string) => {
    setSelectedCustomerAccount(account);
    setView('details');
  };

  // Initialize edit state when customer is selected
  useMemo(() => {
    if (selectedCustomer) {
      const firstLoan = selectedCustomer.loans[0];
      setEditDuration(firstLoan?.installmentDuration || 12);
      setEditStartDate(firstLoan?.startDate || '');
    }
  }, [selectedCustomer]);

  const handleSaveConfig = () => {
    if (selectedCustomerAccount) {
      onUpdateConfig(selectedCustomerAccount, null, {
        duration: editDuration,
        startDate: editStartDate
      });
      setIsEditingConfig(false);
    }
  };

  const getStatusColor = (status: PaymentStatus) => {
    switch (status) {
      case PaymentStatus.PAID_ON_TIME: return "bg-blue-500";
      case PaymentStatus.PAID_LATE: return "bg-emerald-500";
      case PaymentStatus.NOT_PAID: return "bg-red-500";
      case PaymentStatus.ACCOUNT_BLOCKED: return "bg-zinc-900";
      case PaymentStatus.UNDER_MONITORING: return "bg-amber-500";
      default: return "bg-zinc-200";
    }
  };

  const getStatusText = (status: PaymentStatus) => {
    switch (status) {
      case PaymentStatus.PAID_ON_TIME: return language === 'ar' ? 'مسدد في الوقت' : 'Payé à temps';
      case PaymentStatus.PAID_LATE: return language === 'ar' ? 'مسدد متأخر' : 'Payé en retard';
      case PaymentStatus.NOT_PAID: return language === 'ar' ? 'غير مسدد' : 'Non payé';
      case PaymentStatus.ACCOUNT_BLOCKED: return language === 'ar' ? 'حساب محجور' : 'Compte bloqué';
      default: return language === 'ar' ? 'غير معروف' : 'Inconnu';
    }
  };

  const monthNamesFrench = [
    "Jan", "Fév", "Mar", "Avr", "Mai", "Jun",
    "Jul", "Aoû", "Sep", "Oct", "Nov", "Déc"
  ];
  
  const monthNamesArabic = [
    "جانفي", "فيفري", "مارس", "أفريل", "ماي", "جوان",
    "جويلية", "أوت", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
  ];

  const formatMonth = (monthYear: string) => {
    const [m, y] = monthYear.split(' / ').map(Number);
    return language === 'ar' ? `${monthNamesArabic[m - 1]} ${y}` : `${monthNamesFrench[m - 1]} ${y}`;
  };

  const renderTrackingTable = (loan: LoanSummary) => {
    return (
      <div className="mt-4 overflow-x-auto pb-4">
        <div className="flex gap-1 min-w-max">
          {loan.monthlyBreakdown.map((month, idx) => (
            <div key={idx} className="flex flex-col items-center gap-1">
              <div 
                className={`w-8 h-8 rounded-lg ${getStatusColor(month.status)} shadow-sm flex items-center justify-center text-[8px] font-black text-white cursor-help`}
                title={`${formatMonth(month.monthYear)}: ${getStatusText(month.status)}`}
              >
                {month.monthYear.split(' / ')[0]}
              </div>
              <span className="text-[8px] font-bold text-zinc-400">{month.monthYear.split(' / ')[1].slice(-2)}</span>
            </div>
          ))}
        </div>
      </div>
    );
  };

  if (view === 'details' && selectedCustomer) {
    const customerMonthlyGroups = () => {
      const groups: Record<string, {
        monthYear: string;
        loans: LoanSummary[];
        stats: {
          total: number;
          paidOnTime: number;
          paidLate: number;
          unpaid: number;
          deducted: number;
        }
      }> = {};

      selectedCustomer.loans.forEach(loan => {
        loan.monthlyBreakdown.forEach(month => {
          if (month.records.length > 0) {
            if (!groups[month.monthYear]) {
              groups[month.monthYear] = {
                monthYear: month.monthYear,
                loans: [],
                stats: { total: 0, paidOnTime: 0, paidLate: 0, unpaid: 0, deducted: 0 }
              };
            }
            const group = groups[month.monthYear];
            group.loans.push(loan);
            group.stats.total += (month.paidOnTimeCount + month.paidLateCount + month.unpaidCount);
            group.stats.paidOnTime += month.paidOnTimeCount;
            group.stats.paidLate += month.paidLateCount;
            group.stats.unpaid += month.unpaidCount;
            group.stats.deducted += month.collectedAmount;
          }
        });
      });

      return Object.values(groups).map(g => ({
        ...g,
        // Sort loans by reference number smallest to largest
        loans: g.loans.sort((a, b) => a.referenceNumber.localeCompare(b.referenceNumber, undefined, { numeric: true }))
      })).sort((a, b) => {
        const [ma, ya] = a.monthYear.split(' / ').map(Number);
        const [mb, yb] = b.monthYear.split(' / ').map(Number);
        return new Date(yb, mb - 1, 1).getTime() - new Date(ya, ma - 1, 1).getTime();
      });
    };

    const monthlyData = customerMonthlyGroups();

    return (
      <div className="space-y-8 animate-in fade-in duration-500">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setView('search')}
              className="p-3 bg-white border border-zinc-200 rounded-2xl text-zinc-500 hover:text-zinc-900 transition-all hover:shadow-md"
            >
              <ArrowLeft size={24} />
            </button>
            <div>
              <h2 className="text-3xl font-black text-zinc-900 leading-tight">{selectedCustomer.customerName}</h2>
              <p className="text-sm font-bold text-zinc-500 font-mono tracking-wider">{selectedCustomer.customerAccount}</p>
            </div>
          </div>

          <div className="bg-white border border-zinc-200 rounded-[2rem] p-6 shadow-sm flex flex-wrap items-center gap-6">
            {!isEditingConfig ? (
              <>
                <div className="space-y-1">
                  <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">{language === 'ar' ? 'تاريخ بدء الأقساط' : 'Date de début des traites'}</p>
                  <p className="text-sm font-black text-zinc-800">{selectedCustomer.loans[0]?.startDate || '-'}</p>
                </div>
                <div className="w-px h-8 bg-zinc-100 hidden sm:block" />
                <div className="space-y-1">
                  <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">{language === 'ar' ? 'مدة الأقساط' : 'Durée des traites'}</p>
                  <p className="text-sm font-black text-zinc-800">{selectedCustomer.loans[0]?.installmentDuration || 12} {language === 'ar' ? 'شهر' : 'mois'}</p>
                </div>
                <div className="w-px h-8 bg-zinc-100 hidden sm:block" />
                <div className="space-y-1">
                  <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">{language === 'ar' ? 'تاريخ الانتهاء' : 'Date de fin'}</p>
                  <p className="text-sm font-black text-zinc-800">{selectedCustomer.loans[0]?.endDate || '-'}</p>
                </div>
                <button 
                  onClick={() => setIsEditingConfig(true)}
                  className="px-6 py-2 bg-zinc-900 text-white rounded-xl text-xs font-black uppercase tracking-widest hover:bg-zinc-800 transition-all"
                >
                  {language === 'ar' ? 'تعديل' : 'Modifier'}
                </button>
              </>
            ) : (
              <div className="flex flex-wrap items-end gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-zinc-400 uppercase tracking-widest block">{language === 'ar' ? 'تاريخ بدء الأقساط' : 'Installment Start Date'}</label>
                  <input 
                    type="text" 
                    placeholder="DD/MM/YYYY"
                    value={editStartDate}
                    onChange={(e) => setEditStartDate(e.target.value)}
                    className="bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-2 text-sm font-bold text-zinc-800 outline-none focus:ring-2 focus:ring-emerald-500 w-40"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-zinc-400 uppercase tracking-widest block">{language === 'ar' ? 'مدة الأقساط' : 'Installment Duration'}</label>
                  <select 
                    value={editDuration}
                    onChange={(e) => setEditDuration(Number(e.target.value))}
                    className="bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-2 text-sm font-bold text-zinc-800 outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    {[12, 15, 18, 45, 48, 60].map(d => (
                      <option key={d} value={d}>{d} {language === 'ar' ? 'شهر' : 'mois'}</option>
                    ))}
                  </select>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={handleSaveConfig}
                    className="px-6 py-2 bg-emerald-600 text-white rounded-xl text-xs font-black uppercase tracking-widest hover:bg-emerald-700 transition-all"
                  >
                    {language === 'ar' ? 'حفظ' : 'Enregistrer'}
                  </button>
                  <button 
                    onClick={() => setIsEditingConfig(false)}
                    className="px-6 py-2 bg-zinc-100 text-zinc-600 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-zinc-200 transition-all"
                  >
                    {language === 'ar' ? 'إلغاء' : 'Annuler'}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-16">
          {monthlyData.map((group) => (
            <div key={group.monthYear} className="space-y-8">
              <div className="flex items-center gap-4 px-2">
                <div className="bg-emerald-600 p-3 rounded-2xl text-white shadow-lg shadow-emerald-100">
                  <Calendar size={24} />
                </div>
                <div>
                  <h3 className="text-2xl font-black text-zinc-900 uppercase tracking-tight">
                    {language === 'ar' ? 'جدول' : 'TABLE'} — {formatMonth(group.monthYear)}
                  </h3>
                  <p className="text-sm font-bold text-zinc-400">
                    {language === 'ar' ? `جميع أقساط الزبون لشهر ${formatMonth(group.monthYear)}` : `Toutes les traites du client pour ${formatMonth(group.monthYear)}`}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-8">
                {group.loans.map((loan, idx) => (
                  <div key={idx} className="bg-white border border-zinc-200 rounded-[2.5rem] p-8 shadow-sm hover:shadow-xl transition-all duration-300 group">
                    <div className="flex flex-wrap items-start justify-between gap-6 mb-8">
                      <div className="flex items-center gap-5">
                        <div className="bg-zinc-100 p-4 rounded-2xl text-zinc-400 group-hover:bg-emerald-50 group-hover:text-emerald-600 transition-colors">
                          <Hash size={28} />
                        </div>
                        <div>
                          <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">{language === 'ar' ? 'رقم المرجع' : 'N° Référence'}</p>
                          <p className="text-xl font-black text-zinc-900 font-mono">{loan.fullReference}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-5">
                        <div className="bg-blue-50 p-4 rounded-2xl text-blue-600">
                          <DollarSign size={28} />
                        </div>
                        <div>
                          <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">{language === 'ar' ? 'مبلغ القسط' : 'Montant Mensuel'}</p>
                          <p className="text-xl font-black text-zinc-900">{formatCurrency(loan.installmentAmount)}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-5">
                        <div className="bg-zinc-100 p-4 rounded-2xl text-zinc-600">
                          <Clock size={28} />
                        </div>
                        <div>
                          <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">{language === 'ar' ? 'المدة' : 'Durée'}</p>
                          <p className="text-xl font-black text-zinc-900">{loan.installmentDuration} {language === 'ar' ? 'شهر' : 'mois'}</p>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 pt-8 border-t border-zinc-100">
                      <div className="grid grid-cols-2 gap-6">
                        <div className="bg-zinc-50 p-4 rounded-2xl border border-zinc-100">
                          <p className="text-[9px] font-black text-zinc-400 uppercase tracking-widest mb-1">{language === 'ar' ? 'تاريخ البدء' : 'Date de début'}</p>
                          <p className="text-sm font-black text-zinc-800">{loan.startDate || '-'}</p>
                        </div>
                        <div className="bg-zinc-50 p-4 rounded-2xl border border-zinc-100">
                          <p className="text-[9px] font-black text-zinc-400 uppercase tracking-widest mb-1">{language === 'ar' ? 'تاريخ الانتهاء' : 'Date de fin'}</p>
                          <p className="text-sm font-black text-zinc-800">{loan.endDate || '-'}</p>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest flex items-center gap-2">
                          <TrendingUp size={14} className="text-emerald-500" />
                          {language === 'ar' ? 'جدول التتبع من البداية إلى النهاية' : 'Tableau de suivi Start Date → End Date'}
                        </p>
                        {renderTrackingTable(loan)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Monthly Totals at the bottom of the monthly section */}
              <div className="bg-zinc-900 rounded-[2rem] p-8 shadow-2xl shadow-zinc-200 flex flex-wrap items-center justify-between gap-8">
                <div className="flex items-center gap-4">
                  <div className="bg-zinc-800 p-4 rounded-2xl text-zinc-400">
                    <TrendingUp size={28} />
                  </div>
                  <div>
                    <p className="text-xs font-black text-zinc-500 uppercase tracking-widest">{language === 'ar' ? 'ملخص الشهر' : 'Résumé du mois'}</p>
                    <p className="text-xl font-black text-white">{formatMonth(group.monthYear)}</p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-8">
                  <div className="text-center">
                    <p className="text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-1">{language === 'ar' ? 'إجمالي الأقساط' : 'Total Traites'}</p>
                    <p className="text-2xl font-black text-white">{group.stats.total}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-1">{language === 'ar' ? 'في الوقت' : 'À temps'}</p>
                    <p className="text-2xl font-black text-blue-400">{group.stats.paidOnTime}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest mb-1">{language === 'ar' ? 'متأخرة' : 'En retard'}</p>
                    <p className="text-2xl font-black text-emerald-400">{group.stats.paidLate}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-[10px] font-black text-red-400 uppercase tracking-widest mb-1">{language === 'ar' ? 'غير مسددة' : 'Non Payées'}</p>
                    <p className="text-2xl font-black text-red-400">{group.stats.unpaid}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest mb-1">{language === 'ar' ? 'المبلغ المقتطع' : 'Total Déduit'}</p>
                    <p className="text-2xl font-black text-emerald-400">{formatCurrency(group.stats.deducted)}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (view === 'search') {
    return (
      <div className="max-w-4xl mx-auto space-y-8 animate-in slide-in-from-bottom-4 duration-500">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setView('landing')}
            className="p-3 bg-white border border-zinc-200 rounded-2xl text-zinc-500 hover:text-zinc-900 transition-all hover:shadow-md"
          >
            <ArrowLeft size={24} />
          </button>
          <h2 className="text-3xl font-black text-zinc-900">
            {language === 'ar' ? 'بحث عن زبون' : 'Rechercher un client'}
          </h2>
        </div>

        <div className="relative group">
          <div className="absolute inset-y-0 left-6 flex items-center pointer-events-none text-zinc-400 group-focus-within:text-emerald-500 transition-colors">
            <Search size={24} />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={language === 'ar' ? 'ابحث بالاسم أو رقم الحساب...' : 'Rechercher par nom ou N° compte...'}
            className="w-full pl-16 pr-8 py-6 bg-white border-2 border-zinc-100 rounded-[2.5rem] text-xl font-bold text-zinc-800 outline-none focus:border-emerald-500 shadow-xl shadow-zinc-200/50 transition-all"
            autoFocus
          />
        </div>

        <div className="grid grid-cols-1 gap-4">
          {filteredCustomers.map((customer) => (
            <button
              key={customer.customerAccount}
              onClick={() => handleSelectCustomer(customer.customerAccount)}
              className="bg-white border border-zinc-200 p-6 rounded-[2rem] flex items-center justify-between hover:border-emerald-500 hover:shadow-lg transition-all group"
            >
              <div className="flex items-center gap-6">
                <div className="bg-zinc-100 p-4 rounded-2xl text-zinc-400 group-hover:bg-emerald-50 group-hover:text-emerald-600 transition-colors">
                  <Users size={24} />
                </div>
                <div className="text-left">
                  <p className="text-lg font-black text-zinc-800 group-hover:text-emerald-700 transition-colors">{customer.customerName}</p>
                  <p className="text-sm font-bold text-zinc-400 font-mono">{customer.customerAccount}</p>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <div className="text-right hidden sm:block">
                  <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">{language === 'ar' ? 'إجمالي الأقساط' : 'Total Mensualités'}</p>
                  <p className="text-sm font-black text-zinc-800">{customer.loans.length}</p>
                </div>
                <div className="bg-zinc-50 px-4 py-2 rounded-xl text-xs font-black text-zinc-400 group-hover:bg-emerald-600 group-hover:text-white transition-all">
                  {language === 'ar' ? 'اختيار' : 'Sélectionner'}
                </div>
              </div>
            </button>
          ))}

          {searchQuery && filteredCustomers.length === 0 && (
            <div className="text-center py-12 bg-zinc-50 rounded-[2.5rem] border-2 border-dashed border-zinc-200">
              <p className="text-zinc-400 font-bold">{language === 'ar' ? 'لم يتم العثور على نتائج' : 'Aucun résultat trouvé'}</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-12">
      <div className="text-center space-y-8">
        <div className="relative inline-block">
          <div className="bg-emerald-600 w-32 h-32 rounded-[2.5rem] flex items-center justify-center mx-auto text-white shadow-2xl shadow-emerald-200 animate-bounce-slow">
            <Users size={64} />
          </div>
          <div className="absolute -bottom-4 -right-4 bg-white p-4 rounded-2xl shadow-lg border border-zinc-100">
            <Search size={24} className="text-emerald-600" />
          </div>
        </div>
        
        <div className="space-y-4">
          <h2 className="text-5xl font-black text-zinc-900 tracking-tight">
            {language === 'ar' ? 'تتبع الأقساط' : 'Suivi des Mensualités'}
          </h2>
          <p className="text-xl text-zinc-500 font-medium max-w-lg mx-auto leading-relaxed">
            {language === 'ar' 
              ? 'قم باختيار زبون لعرض تفاصيل تتبع أقساطه الشهرية وحالة الدفع لكل قرض' 
              : 'Sélectionnez un client pour visualiser le détail de son suivi mensuel et l\'état de paiement de chaque prêt'}
          </p>
        </div>

        <button
          onClick={() => setView('search')}
          className="group relative inline-flex items-center gap-4 px-12 py-6 bg-zinc-900 text-white rounded-[2rem] text-xl font-black uppercase tracking-widest hover:bg-emerald-600 transition-all hover:scale-105 shadow-2xl shadow-zinc-200"
        >
          <Users size={28} className="group-hover:rotate-12 transition-transform" />
          {language === 'ar' ? 'اختيار زبون' : 'Select Customer'}
          <div className="absolute -inset-1 bg-emerald-400 rounded-[2.1rem] blur opacity-0 group-hover:opacity-20 transition-opacity" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-16">
          <div className="bg-white p-8 rounded-[2rem] border border-zinc-100 shadow-sm space-y-4 text-left">
            <div className="bg-blue-50 w-12 h-12 rounded-2xl flex items-center justify-center text-blue-600">
              <CheckCircle2 size={24} />
            </div>
            <h4 className="font-black text-zinc-900 uppercase tracking-widest text-xs">{language === 'ar' ? 'تتبع دقيق' : 'Suivi Précis'}</h4>
            <p className="text-sm text-zinc-500 leading-relaxed">{language === 'ar' ? 'عرض حالة كل شهر من تاريخ البدء إلى تاريخ الانتهاء' : 'Visualisez l\'état de chaque mois de la date de début à la date de fin'}</p>
          </div>
          <div className="bg-white p-8 rounded-[2rem] border border-zinc-100 shadow-sm space-y-4 text-left">
            <div className="bg-emerald-50 w-12 h-12 rounded-2xl flex items-center justify-center text-emerald-600">
              <TrendingUp size={24} />
            </div>
            <h4 className="font-black text-zinc-900 uppercase tracking-widest text-xs">{language === 'ar' ? 'إحصائيات شهرية' : 'Stats Mensuelles'}</h4>
            <p className="text-sm text-zinc-500 leading-relaxed">{language === 'ar' ? 'حساب تلقائي للمبالغ المقتطعة والأقساط غير المسددة' : 'Calcul automatique des montants déduits et des impayés'}</p>
          </div>
          <div className="bg-white p-8 rounded-[2rem] border border-zinc-100 shadow-sm space-y-4 text-left">
            <div className="bg-zinc-50 w-12 h-12 rounded-2xl flex items-center justify-center text-zinc-600">
              <FileText size={24} />
            </div>
            <h4 className="font-black text-zinc-900 uppercase tracking-widest text-xs">{language === 'ar' ? 'فرز تلقائي' : 'Tri Automatique'}</h4>
            <p className="text-sm text-zinc-500 leading-relaxed">{language === 'ar' ? 'ترتيب الأقساط حسب رقم المرجع لتسهيل المراجعة' : 'Classement des traites par numéro de référence pour faciliter la révision'}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
