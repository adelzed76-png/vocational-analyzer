import React, { useMemo } from 'react';
import { CustomerSummary, Language, PaymentStatus } from '../types';
import { formatCurrency } from '../utils/formatters';
import { Calendar, ChevronRight, Users, CheckCircle2, AlertCircle, TrendingUp } from 'lucide-react';

interface MonthlyGlobalSummaryProps {
  summaries: CustomerSummary[];
  language: Language;
}

export const MonthlyGlobalSummary: React.FC<MonthlyGlobalSummaryProps> = ({ summaries, language }) => {
  const isRtl = language === 'ar';

  const monthlyStats = useMemo(() => {
    const stats: Record<string, {
      monthYear: string;
      totalInstallments: number;
      totalDeducted: number;
      totalExpected: number;
      customers: Set<string>;
      paidCount: number;
      unpaidCount: number;
    }> = {};

    summaries.forEach(customer => {
      customer.loans.forEach(loan => {
        loan.monthlyBreakdown.forEach(month => {
          if (!stats[month.monthYear]) {
            stats[month.monthYear] = {
              monthYear: month.monthYear,
              totalInstallments: 0,
              totalDeducted: 0,
              totalExpected: 0,
              customers: new Set(),
              paidCount: 0,
              unpaidCount: 0
            };
          }

          const s = stats[month.monthYear];
          s.totalInstallments += (month.paidOnTimeCount + month.paidLateCount + month.unpaidCount);
          s.totalDeducted += month.collectedAmount;
          s.totalExpected += month.installmentAmount;
          s.customers.add(customer.customerAccount);
          
          s.paidCount += (month.paidOnTimeCount + month.paidLateCount);
          s.unpaidCount += month.unpaidCount;
        });
      });
    });

    return Object.values(stats).sort((a, b) => {
      const [ma, ya] = a.monthYear.split(' / ').map(Number);
      const [mb, yb] = b.monthYear.split(' / ').map(Number);
      return new Date(yb, mb - 1, 1).getTime() - new Date(ya, ma - 1, 1).getTime();
    });
  }, [summaries]);

  const monthNamesFrench = [
    "Janvier", "Février", "Mars", "Avril", "Mai", "Juin",
    "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"
  ];
  
  const monthNamesArabic = [
    "جانفي", "فيفري", "مارس", "أفريل", "ماي", "جوان",
    "جويلية", "أوت", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
  ];

  const formatMonth = (monthYear: string) => {
    const [m, y] = monthYear.split(' / ').map(Number);
    return language === 'ar' ? `${monthNamesArabic[m - 1]} ${y}` : `${monthNamesFrench[m - 1]} ${y}`;
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black text-zinc-900">
            {language === 'ar' ? 'ملخص النتائج الشهرية' : 'Résumé des Résultats Mensuels'}
          </h2>
          <p className="text-zinc-500 font-medium">
            {language === 'ar' ? 'تجميع الاقتطاعات حسب الشهر والسنة' : 'Groupement des déductions par mois et année'}
          </p>
        </div>
      </div>

      <div className="grid gap-6">
        {monthlyStats.map((stat) => (
          <div key={stat.monthYear} className="bg-white rounded-3xl border border-zinc-200 shadow-sm overflow-hidden hover:shadow-md transition-all">
            <div className="bg-zinc-50/50 px-8 py-4 border-b border-zinc-100 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-white p-2 rounded-xl border border-zinc-200 text-zinc-600 shadow-sm">
                  <Calendar size={20} />
                </div>
                <h3 className="text-lg font-black text-zinc-800">
                  {formatMonth(stat.monthYear)}
                </h3>
              </div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2 text-zinc-400">
                  <Users size={16} />
                  <span className="text-sm font-bold">{stat.customers.size} {language === 'ar' ? 'زبائن' : 'Clients'}</span>
                </div>
                <div className="h-4 w-px bg-zinc-200" />
                <div className="flex items-center gap-2 text-zinc-400">
                  <TrendingUp size={16} />
                  <span className="text-sm font-bold">{stat.totalInstallments} {language === 'ar' ? 'أقساط' : 'Installments'}</span>
                </div>
              </div>
            </div>

            <div className="p-8 grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="space-y-1">
                <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">
                  {language === 'ar' ? 'إجمالي المبلغ المقتطع' : 'Total Déduit'}
                </p>
                <p className="text-3xl font-black text-emerald-600">
                  {formatCurrency(stat.totalDeducted)}
                </p>
                <div className="flex items-center gap-2 text-xs text-zinc-400">
                  <span className="font-bold">{(stat.totalDeducted / stat.totalExpected * 100 || 0).toFixed(1)}%</span>
                  <span>{language === 'ar' ? 'من المتوقع' : 'du montant attendu'}</span>
                </div>
              </div>

              <div className="space-y-1">
                <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">
                  {language === 'ar' ? 'الأقساط المسددة' : 'Installments Payés'}
                </p>
                <div className="flex items-center gap-3">
                  <p className="text-3xl font-black text-zinc-800">
                    {stat.paidCount}
                  </p>
                  <div className="bg-emerald-100 text-emerald-700 px-2 py-1 rounded-lg text-[10px] font-bold">
                    {language === 'ar' ? 'ناجح' : 'Succès'}
                  </div>
                </div>
                <div className="w-full bg-zinc-100 h-1.5 rounded-full overflow-hidden">
                  <div 
                    className="bg-emerald-500 h-full transition-all duration-1000" 
                    style={{ width: `${(stat.paidCount / stat.totalInstallments * 100) || 0}%` }}
                  />
                </div>
              </div>

              <div className="space-y-1">
                <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">
                  {language === 'ar' ? 'الأقساط غير المسددة' : 'Installments Non Payés'}
                </p>
                <div className="flex items-center gap-3">
                  <p className="text-3xl font-black text-rose-600">
                    {stat.unpaidCount}
                  </p>
                  <div className="bg-rose-100 text-rose-700 px-2 py-1 rounded-lg text-[10px] font-bold">
                    {language === 'ar' ? 'فشل' : 'Échec'}
                  </div>
                </div>
                <div className="w-full bg-zinc-100 h-1.5 rounded-full overflow-hidden">
                  <div 
                    className="bg-rose-500 h-full transition-all duration-1000" 
                    style={{ width: `${(stat.unpaidCount / stat.totalInstallments * 100) || 0}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        ))}

        {monthlyStats.length === 0 && (
          <div className="bg-white rounded-3xl border border-zinc-200 p-20 text-center space-y-4">
            <div className="w-20 h-20 bg-zinc-50 rounded-full flex items-center justify-center mx-auto text-zinc-200">
              <Calendar size={40} />
            </div>
            <div className="space-y-1">
              <h3 className="text-xl font-bold text-zinc-800">
                {language === 'ar' ? 'لا توجد بيانات شهرية' : 'Aucune donnée mensuelle'}
              </h3>
              <p className="text-zinc-500">
                {language === 'ar' ? 'قم باستيراد ملفات النتائج لعرض الملخص الشهري' : 'Importez des fichiers de résultats pour afficher le résumé mensuel'}
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
