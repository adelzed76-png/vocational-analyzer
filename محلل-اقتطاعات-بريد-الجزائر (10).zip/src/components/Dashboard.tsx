import React from 'react';
import { Users, FileCheck, DollarSign, Wallet, AlertTriangle, CheckCircle, ShieldAlert, Ban, Clock, Eye, XCircle, Lock, TrendingUp, Receipt } from 'lucide-react';
import { GlobalStats, CustomerSummary, PaymentStatus, Language } from '../types';
import { AnalyticsCharts } from './AnalyticsCharts';
import { exportMonthlyReportToExcel, exportMonthlyReportToPDF, exportFullDatabaseToExcel, exportStopListToPDF, exportStopListToExcel } from '../utils/reports';
import { Download, FileText, Table } from 'lucide-react';
import { formatCurrency } from '../utils/formatters';
import { useTranslation } from '../utils/translations';

interface DashboardProps {
  stats: GlobalStats;
  summaries: CustomerSummary[];
  language: Language;
}

export const Dashboard: React.FC<DashboardProps> = ({ stats, summaries, language }) => {
  const [selectedMonth, setSelectedMonth] = React.useState<string>('');
  const t = useTranslation(language);

  // Extract all unique months from summaries
  const availableMonths = React.useMemo(() => {
    const months = new Set<string>();
    summaries.forEach(s => {
      s.loans.forEach(loan => {
        loan.monthlyBreakdown.forEach(m => months.add(m.monthYear));
      });
    });
    const sorted = Array.from(months).sort((a, b) => {
      const [mA, yA] = a.split(' / ').map(Number);
      const [mB, yB] = b.split(' / ').map(Number);
      return yB !== yA ? yB - yA : mB - mA;
    });
    
    if (sorted.length > 0 && !selectedMonth) {
      setSelectedMonth(sorted[0]);
    }
    
    return sorted;
  }, [summaries]);

  const monthlyTotals = React.useMemo(() => {
    if (!selectedMonth) return { collected: 0, notCollected: 0 };
    
    let collected = 0;
    let notCollected = 0;
    
    summaries.forEach(s => {
      s.loans.forEach(loan => {
        const monthData = loan.monthlyBreakdown.find(m => m.monthYear === selectedMonth);
        if (monthData) {
          collected += monthData.collectedAmount;
          notCollected += monthData.notCollectedAmount;
        }
      });
    });
    
    return { 
      collected: Number(collected.toFixed(2)), 
      notCollected: Number(notCollected.toFixed(2)) 
    };
  }, [selectedMonth, summaries]);

  const cards = [
    {
      title: t.totalCustomers,
      value: stats.totalCustomers,
      icon: <Users className="text-blue-600" />,
      bg: "bg-blue-50",
      border: "border-blue-100"
    },
    {
      title: t.totalInstallments,
      value: stats.totalInstallments,
      icon: <FileCheck className="text-purple-600" />,
      bg: "bg-purple-50",
      border: "border-purple-100"
    },
    {
      title: (t as any).validInstallments,
      value: stats.validInstallments,
      icon: <CheckCircle className="text-emerald-600" />,
      bg: "bg-emerald-50",
      border: "border-emerald-100"
    },
    {
      title: (t as any).invalidInstallments,
      value: stats.invalidInstallments,
      icon: <AlertTriangle className="text-red-600" />,
      bg: "bg-red-50",
      border: "border-red-100"
    },
    {
      title: t.totalPaid,
      value: stats.totalPaid,
      icon: <CheckCircle className="text-emerald-600" />,
      bg: "bg-emerald-50",
      border: "border-emerald-100"
    },
    {
      title: t.totalUnpaid,
      value: stats.totalUnpaid,
      icon: <XCircle className="text-red-600" />,
      bg: "bg-red-50",
      border: "border-red-100"
    },
    {
      title: t.totalExpected,
      value: formatCurrency(stats.totalExpectedAmount),
      icon: <DollarSign className="text-emerald-600" />,
      bg: "bg-emerald-50",
      border: "border-emerald-100"
    },
    {
      title: t.totalCollected,
      value: formatCurrency(stats.totalCollectedAmount),
      icon: <CheckCircle className="text-green-600" />,
      bg: "bg-green-50",
      border: "border-green-100"
    },
    {
      title: t.remainingAmount,
      value: formatCurrency(stats.totalRemainingAmount),
      icon: <Wallet className="text-zinc-600" />,
      bg: "bg-zinc-50",
      border: "border-zinc-100"
    },
    {
      title: language === 'ar' ? 'إجمالي الضرائب' : 'Total Taxes',
      value: formatCurrency(Object.values(summaries.reduce((acc, s) => {
        s.records.forEach(record => {
          const code = record.statusCode;
          if (code >= "001" && code <= "027") {
            const monthKey = `${record.deductionMonth.padStart(2, '0')} / ${record.deductionYear}`;
            acc[monthKey] = (acc[monthKey] || 0) + record.installmentAmount;
          }
        });
        return acc;
      }, {} as Record<string, number>)).reduce((total, lateIncome) => {
        const commission = lateIncome * 0.05;
        const ht = commission + 3000;
        const tva = ht * 0.19;
        return total + (ht + tva);
      }, 0)),
      icon: <Receipt className="text-amber-600" />,
      bg: "bg-amber-50",
      border: "border-amber-100"
    }
  ];

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((card, index) => (
          <div
            key={index}
            className={`${card.bg} ${card.border} border p-6 rounded-2xl shadow-sm hover:shadow-md transition-shadow flex items-center justify-between`}
          >
            <div className="space-y-1">
              <p className="text-sm font-medium text-zinc-500">{card.title}</p>
              <p className="text-2xl font-bold text-zinc-900">{card.value}</p>
            </div>
            <div className="p-3 bg-white rounded-xl shadow-sm">
              {card.icon}
            </div>
          </div>
        ))}
        
        <div className="col-span-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="bg-red-600 border border-red-700 p-6 rounded-2xl flex items-center justify-between text-white shadow-lg shadow-red-100">
            <div className="space-y-1">
              <p className="text-sm font-medium text-red-100 flex items-center gap-2">
                <Ban size={14} />
                {t.stopListTitle}
              </p>
              <p className="text-2xl font-bold">{stats.stopListCount}</p>
            </div>
            <div className="p-3 bg-red-500 rounded-xl shadow-sm text-white">
              <Ban />
            </div>
          </div>
          <div className="bg-red-50 border border-red-100 p-6 rounded-2xl flex items-center justify-between">
            <div className="space-y-1">
              <p className="text-sm font-medium text-red-600 flex items-center gap-2">
                <XCircle size={14} />
                {t.unpaidInstallments} (2+)
              </p>
              <p className="text-2xl font-bold text-red-900">{stats.overdueCount2PlusMonths}</p>
            </div>
            <div className="p-3 bg-white rounded-xl shadow-sm text-red-600">
              <AlertTriangle />
            </div>
          </div>
          <div className="bg-amber-50 border border-amber-100 p-6 rounded-2xl flex items-center justify-between">
            <div className="space-y-1">
              <p className="text-sm font-medium text-amber-600 flex items-center gap-2">
                <Clock size={14} />
                {t.unpaidInstallments} (1)
              </p>
              <p className="text-2xl font-bold text-amber-900">{stats.overdueCount1Month}</p>
            </div>
            <div className="p-3 bg-white rounded-xl shadow-sm text-amber-600">
              <Clock />
            </div>
          </div>
        </div>
      </div>

      <AnalyticsCharts summaries={summaries} language={language} />

      {/* Reports Section */}
      <div className="bg-white border border-zinc-200 rounded-3xl p-8 space-y-8">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <h3 className="text-xl font-bold text-zinc-900">{language === 'ar' ? 'مركز التقارير' : 'Centre de Rapports'}</h3>
            <p className="text-sm text-zinc-500">{language === 'ar' ? 'إنشاء تقارير مالية مفصلة بتنسيقات Excel و PDF' : 'Générer des rapports financiers détaillés en formats Excel et PDF'}</p>
          </div>
          <div className="bg-emerald-50 text-emerald-600 p-3 rounded-2xl">
            <FileText size={24} />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Monthly Report */}
          <div className="space-y-4 p-6 bg-zinc-50 rounded-2xl border border-zinc-100">
            <div className="flex items-center gap-3 text-zinc-800 font-bold">
              <Clock size={20} className="text-emerald-600" />
              <h4>{language === 'ar' ? 'تقرير شهري كامل' : 'Rapport Mensuel Complet'}</h4>
            </div>
            <p className="text-xs text-zinc-500">{language === 'ar' ? 'تقرير مفصل لجميع الزبائن لشهر محدد، بما في ذلك المحاولات والمبالغ المحصلة.' : 'Rapport détaillé de tous les clients pour un mois spécifique, incluant les tentatives et les montants collectés.'}</p>
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <select 
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="bg-white border border-zinc-200 rounded-xl px-4 py-2 text-sm font-bold outline-none focus:ring-2 focus:ring-emerald-500"
              >
                {availableMonths.map(m => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </select>
              <button 
                onClick={() => exportMonthlyReportToExcel(selectedMonth, summaries)}
                className="flex items-center gap-2 px-4 py-2 bg-white border border-zinc-200 text-zinc-700 rounded-xl text-sm font-bold hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-200 transition-all"
              >
                <Table size={16} />
                Excel
              </button>
              <button 
                onClick={() => exportMonthlyReportToPDF(selectedMonth, summaries)}
                className="flex items-center gap-2 px-4 py-2 bg-white border border-zinc-200 text-zinc-700 rounded-xl text-sm font-bold hover:bg-red-50 hover:text-red-700 hover:border-red-200 transition-all"
              >
                <FileText size={16} />
                PDF
              </button>
            </div>
            {selectedMonth && (
              <div className="grid grid-cols-2 gap-3 pt-4 border-t border-zinc-200/50">
                <div className="bg-white p-3 rounded-xl border border-zinc-100">
                  <p className="text-[10px] text-zinc-400 font-bold uppercase">{t.totalCollected}</p>
                  <p className="text-sm font-black text-emerald-600">{formatCurrency(monthlyTotals.collected)}</p>
                </div>
                <div className="bg-white p-3 rounded-xl border border-zinc-100">
                  <p className="text-[10px] text-zinc-400 font-bold uppercase">{t.unpaidInstallments}</p>
                  <p className="text-sm font-black text-red-600">{formatCurrency(monthlyTotals.notCollected)}</p>
                </div>
              </div>
            )}
          </div>

          {/* Other Reports */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <button 
              onClick={() => exportFullDatabaseToExcel(summaries)}
              className="flex flex-col items-center justify-center gap-3 p-6 bg-emerald-50 border border-emerald-100 rounded-2xl text-emerald-700 hover:bg-emerald-100 transition-all group"
            >
              <Download size={24} className="group-hover:scale-110 transition-transform" />
              <span className="font-bold text-sm">{t.exportExcel}</span>
            </button>
            <button 
              onClick={() => exportStopListToPDF(summaries)}
              className="flex flex-col items-center justify-center gap-3 p-6 bg-red-50 border border-red-100 rounded-2xl text-red-700 hover:bg-red-100 transition-all group"
            >
              <FileText size={24} className="group-hover:scale-110 transition-transform" />
              <span className="font-bold text-sm">{t.stopReport} (PDF)</span>
            </button>
            <button 
              onClick={() => exportStopListToExcel(summaries)}
              className="flex flex-col items-center justify-center gap-3 p-6 bg-rose-50 border border-rose-100 rounded-2xl text-rose-700 hover:bg-rose-100 transition-all group"
            >
              <Table size={24} className="group-hover:scale-110 transition-transform" />
              <span className="font-bold text-sm">{t.stopReport} (Excel)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};


