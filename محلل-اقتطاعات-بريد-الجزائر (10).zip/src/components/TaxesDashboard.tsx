import React, { useMemo, useState } from 'react';
import { CustomerSummary, Language } from '../types';
import { Receipt, Calculator, Calendar, TrendingUp, Search, ArrowRight } from 'lucide-react';
import { formatCurrency } from '../utils/formatters';

interface TaxesDashboardProps {
  summaries: CustomerSummary[];
  language: Language;
}

interface MonthlyTaxData {
  monthYear: string;
  lateIncome: number;
  tax: number;
}

export const TaxesDashboard: React.FC<TaxesDashboardProps> = ({ summaries, language }) => {
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState('');
  const [customResult, setCustomResult] = useState<{ lateIncome: number; tax: number; start: string; end: string } | null>(null);

  const monthlyTaxes = useMemo(() => {
    const data: Record<string, number> = {};

    summaries.forEach(summary => {
      summary.records.forEach(record => {
        const code = record.statusCode;
        // Only include late payments (001-027)
        if (code >= "001" && code <= "027") {
          // Group by the month of the results file (deduction month/year)
          const monthKey = `${record.deductionMonth.padStart(2, '0')} / ${record.deductionYear}`;
          data[monthKey] = (data[monthKey] || 0) + record.installmentAmount;
        }
      });
    });

    return Object.entries(data)
      .map(([monthYear, lateIncome]) => {
        // Formula: 
        // 1. Commission = LateIncome * 0.05
        // 2. HT = Commission + 3000
        // 3. TVA = HT * 0.19
        // 4. TTC = HT + TVA
        const commission = lateIncome * 0.05;
        const ht = commission + 3000;
        const tva = ht * 0.19;
        const tax = ht + tva;
        
        return {
          monthYear,
          lateIncome,
          tax
        };
      })
      .sort((a, b) => {
        const [ma, ya] = a.monthYear.split(' / ').map(Number);
        const [mb, yb] = b.monthYear.split(' / ').map(Number);
        return new Date(yb, mb - 1, 1).getTime() - new Date(ya, ma - 1, 1).getTime();
      });
  }, [summaries]);

  const handleCalculateCustom = () => {
    if (!customStart || !customEnd) return;

    const start = new Date(customStart);
    const end = new Date(customEnd);
    // Set end to end of day
    end.setHours(23, 59, 59, 999);

    let lateIncome = 0;

    summaries.forEach(summary => {
      summary.records.forEach(record => {
        const code = record.statusCode;
        if (code >= "001" && code <= "027") {
          const [d, m, y] = record.installmentDate.split('/').map(Number);
          const paymentDate = new Date(y, m - 1, d);

          if (paymentDate >= start && paymentDate <= end) {
            lateIncome += record.installmentAmount;
          }
        }
      });
    });

    const commission = lateIncome * 0.05;
    const ht = commission + 3000;
    const tva = ht * 0.19;
    const tax = ht + tva;
    
    // Format dates for display
    const formatDate = (dateStr: string) => {
      const d = new Date(dateStr);
      return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
    };

    setCustomResult({
      lateIncome,
      tax,
      start: formatDate(customStart),
      end: formatDate(customEnd)
    });
  };

  const totalLateIncome = monthlyTaxes.reduce((sum, item) => sum + item.lateIncome, 0);
  const totalTax = monthlyTaxes.reduce((sum, item) => sum + item.tax, 0);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Custom Tax Period Section */}
      <div className="bg-white border border-zinc-200 rounded-3xl p-8 shadow-sm">
        <div className="flex items-center gap-3 mb-8">
          <div className="bg-emerald-600 text-white p-2.5 rounded-2xl shadow-lg shadow-emerald-100">
            <Calculator size={24} />
          </div>
          <div>
            <h3 className="text-xl font-black text-zinc-900">
              {language === 'ar' ? 'فترة ضريبية مخصصة' : 'Période Fiscale Personnalisée'}
            </h3>
            <p className="text-xs text-zinc-500 font-medium">
              {language === 'ar' 
                ? 'حساب الضرائب بناءً على تاريخ الدفع الفعلي لفترة محددة' 
                : 'Calculer les taxes basées sur la date de paiement réelle pour une période spécifique'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-zinc-400 uppercase tracking-widest px-1">
              {language === 'ar' ? 'من تاريخ' : 'De Date'}
            </label>
            <input 
              type="date" 
              value={customStart}
              onChange={(e) => setCustomStart(e.target.value)}
              className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm font-bold outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
            />
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-black text-zinc-400 uppercase tracking-widest px-1">
              {language === 'ar' ? 'إلى تاريخ' : 'À Date'}
            </label>
            <input 
              type="date" 
              value={customEnd}
              onChange={(e) => setCustomEnd(e.target.value)}
              className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm font-bold outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
            />
          </div>
          <button 
            onClick={handleCalculateCustom}
            disabled={!customStart || !customEnd}
            className="bg-emerald-600 text-white rounded-xl px-6 py-3.5 font-black text-sm hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100 disabled:opacity-50 disabled:shadow-none flex items-center justify-center gap-2"
          >
            <Search size={18} />
            {language === 'ar' ? 'حساب الضرائب' : 'Calculer Taxes'}
          </button>
        </div>

        {customResult && (
          <div className="mt-8 p-6 bg-emerald-50 border border-emerald-100 rounded-2xl animate-in slide-in-from-top-4 duration-300">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="space-y-4">
                <div className="flex items-center gap-3 text-emerald-900">
                  <Calendar size={20} />
                  <span className="font-black text-sm">
                    {language === 'ar' ? 'الفترة المختارة:' : 'Période Sélectionnée :'}
                  </span>
                  <div className="flex items-center gap-2 bg-white px-3 py-1 rounded-lg border border-emerald-200 text-xs font-bold">
                    {customResult.start} <ArrowRight size={12} /> {customResult.end}
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div>
                    <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest mb-1">
                      {language === 'ar' ? 'التسديدات المتأخرة المحصلة' : 'Paiements Retard Collectés'}
                    </p>
                    <p className="text-xl font-black text-emerald-900">
                      {formatCurrency(customResult.lateIncome)}
                    </p>
                  </div>
                  <div className="w-px h-10 bg-emerald-200"></div>
                  <div>
                    <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest mb-1">
                      {language === 'ar' ? 'الضريبة المحسوبة' : 'Taxe Calculée'}
                    </p>
                    <p className="text-xl font-black text-emerald-900">
                      {formatCurrency(customResult.tax)}
                    </p>
                  </div>
                </div>
              </div>
              <div className="bg-white p-4 rounded-2xl border border-emerald-200 shadow-sm self-center md:self-auto">
                <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-2 text-center">
                  {language === 'ar' ? 'صيغة الحساب المطبقة' : 'Formule Appliquée'}
                </p>
                <code className="text-xs font-mono font-bold text-emerald-700">
                  ({formatCurrency(customResult.lateIncome)} × 0.05 + 3000) × 1.19
                </code>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white border border-zinc-200 rounded-3xl p-8 shadow-sm hover:shadow-md transition-all">
          <div className="flex items-center gap-4 mb-6">
            <div className="bg-amber-100 text-amber-600 p-3 rounded-2xl">
              <TrendingUp size={24} />
            </div>
            <div>
              <p className="text-xs font-black text-zinc-400 uppercase tracking-widest">
                {language === 'ar' ? 'إجمالي دخل التأخير' : 'Total Revenu Retard'}
              </p>
              <h3 className="text-2xl font-black text-zinc-900">
                {formatCurrency(totalLateIncome)}
              </h3>
            </div>
          </div>
          <div className="h-2 bg-zinc-100 rounded-full overflow-hidden">
            <div className="h-full bg-amber-500 w-full"></div>
          </div>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-8 shadow-xl shadow-zinc-200 text-white">
          <div className="flex items-center gap-4 mb-6">
            <div className="bg-emerald-500 text-white p-3 rounded-2xl">
              <Calculator size={24} />
            </div>
            <div>
              <p className="text-xs font-black text-zinc-500 uppercase tracking-widest">
                {language === 'ar' ? 'إجمالي الضرائب المستحقة' : 'Total Taxes Dues'}
              </p>
              <h3 className="text-2xl font-black text-white">
                {formatCurrency(totalTax)}
              </h3>
            </div>
          </div>
          <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
            <div className="h-full bg-emerald-500 w-full"></div>
          </div>
        </div>
      </div>

      {/* Monthly Breakdown Table */}
      <div className="bg-white border border-zinc-200 rounded-3xl overflow-hidden shadow-sm">
        <div className="p-6 border-b border-zinc-100 bg-zinc-50/50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Receipt className="text-emerald-600" size={24} />
            <div>
              <h3 className="text-lg font-black text-zinc-900">
                {language === 'ar' ? 'تفاصيل الضرائب الشهرية' : 'Détails des Taxes Mensuelles'}
              </h3>
              <p className="text-xs text-zinc-500 font-medium">
                {language === 'ar' 
                  ? 'حساب تلقائي بناءً على دخل الأقساط المتأخرة (001-027)' 
                  : 'Calcul automatique basé sur le revenu des mensualités en retard (001-027)'}
              </p>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-zinc-50 text-zinc-500 text-[10px] uppercase tracking-widest font-black">
                <th className="px-8 py-5">{language === 'ar' ? 'الشهر' : 'Mois'}</th>
                <th className="px-8 py-5">{language === 'ar' ? 'دخل التأخير' : 'Revenu Retard'}</th>
                <th className="px-8 py-5">{language === 'ar' ? 'الضريبة المحسوبة' : 'Taxe Calculée'}</th>
                <th className="px-8 py-5">{language === 'ar' ? 'الصيغة المطبقة' : 'Formule Appliquée'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {monthlyTaxes.map((item) => (
                <tr key={item.monthYear} className="hover:bg-zinc-50 transition-colors group">
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-3">
                      <div className="bg-zinc-100 text-zinc-600 p-2 rounded-xl group-hover:bg-emerald-100 group-hover:text-emerald-600 transition-colors">
                        <Calendar size={18} />
                      </div>
                      <span className="font-black text-zinc-900">{item.monthYear}</span>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <span className="font-black text-amber-600">{formatCurrency(item.lateIncome)}</span>
                  </td>
                  <td className="px-8 py-6">
                    <div className="bg-emerald-50 text-emerald-700 px-4 py-2 rounded-xl inline-block font-black">
                      {formatCurrency(item.tax)}
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <code className="text-[10px] bg-zinc-100 text-zinc-500 px-3 py-1.5 rounded-lg font-mono">
                      ({formatCurrency(item.lateIncome)} × 0.05 + 3000) × 1.19
                    </code>
                  </td>
                </tr>
              ))}
              {monthlyTaxes.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-8 py-20 text-center">
                    <div className="flex flex-col items-center gap-3 text-zinc-400">
                      <Receipt size={48} className="opacity-20" />
                      <p className="font-bold">{language === 'ar' ? 'لا توجد بيانات ضرائب متاحة' : 'Aucune donnée de taxe disponible'}</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Formula Explanation Card */}
      <div className="bg-emerald-50 border border-emerald-100 rounded-3xl p-8">
        <h4 className="text-emerald-900 font-black mb-4 flex items-center gap-2">
          <Calculator size={20} />
          {language === 'ar' ? 'شرح طريقة الحساب' : 'Explication du Calcul'}
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-emerald-800 text-sm leading-relaxed">
          <div className="space-y-4">
            <p className="font-bold">
              {language === 'ar' 
                ? 'يتم حساب الضريبة الشهرية بناءً على إجمالي دخل الأقساط المتأخرة (الأكواد 001-027):' 
                : 'La taxe mensuelle est calculée sur la base du revenu total des mensualités en retard (codes 001-027) :'}
            </p>
            <ul className="list-decimal list-inside space-y-2 font-medium opacity-80">
              <li>{language === 'ar' ? 'حساب العمولة: ضرب المبلغ في 0.05 (5%).' : 'Calcul de la commission : Multiplier le montant par 0.05 (5%).'}</li>
              <li>{language === 'ar' ? 'إضافة رسوم التسيير: 3000 دج ثابتة.' : 'Ajout des frais de gestion : 3000 DZD fixe.'}</li>
              <li>{language === 'ar' ? 'حساب الرسم على القيمة المضافة (TVA): ضرب الناتج في 0.19 (19%).' : 'Calcul de la TVA : Multiplier le montant HT par 0.19 (19%).'}</li>
              <li>{language === 'ar' ? 'المبلغ الإجمالي (TTC): مجموع المبلغ الخام والرسوم.' : 'Montant Total (TTC) : Somme du montant HT et de la TVA.'}</li>
            </ul>
          </div>
          <div className="bg-white/50 rounded-2xl p-6 border border-emerald-200/50 self-center">
            <p className="text-xs font-black text-emerald-900 uppercase tracking-widest mb-3">
              {language === 'ar' ? 'الصيغة الرياضية الرسمية' : 'Formule Mathématique Officielle'}
            </p>
            <p className="text-xl font-mono font-black text-emerald-700">
              TTC = (Income × 0.05 + 3000) × 1.19
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
