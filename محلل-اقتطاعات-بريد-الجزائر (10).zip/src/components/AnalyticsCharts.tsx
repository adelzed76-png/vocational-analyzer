import React, { useMemo } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
} from 'chart.js';
import { Bar, Pie } from 'react-chartjs-2';
import { CustomerSummary, PaymentStatus, Language } from '../types';
import { getStatusFromCode } from '../utils/parser';
import { useTranslation } from '../utils/translations';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

interface AnalyticsChartsProps {
  summaries: CustomerSummary[];
  language: Language;
}

export const AnalyticsCharts: React.FC<AnalyticsChartsProps> = ({ summaries, language }) => {
  const t = useTranslation(language);

  // Monthly Performance
  const monthlyData = useMemo(() => {
    const months: Record<string, { collected: number; expected: number }> = {};
    
    summaries.forEach(s => {
      s.records.forEach(r => {
        const [d, m, y] = r.installmentDate.split('/');
        const key = `${y}-${m.padStart(2, '0')}`;
        if (!months[key]) months[key] = { collected: 0, expected: 0 };
        
        const { status } = getStatusFromCode(r.statusCode);
        months[key].expected += r.installmentAmount;
        if (status === PaymentStatus.PAID_ON_TIME || status === PaymentStatus.PAID_LATE) {
          months[key].collected += r.installmentAmount;
        }
      });
    });

    const sortedKeys = Object.keys(months).sort();
    return {
      labels: sortedKeys,
      datasets: [
        {
          label: language === 'ar' ? 'المحصل (دج)' : 'Collecté (DZD)',
          data: sortedKeys.map(k => months[k].collected),
          backgroundColor: 'rgba(16, 185, 129, 0.6)',
        },
        {
          label: language === 'ar' ? 'المتوقع (دج)' : 'Attendu (DZD)',
          data: sortedKeys.map(k => months[k].expected),
          backgroundColor: 'rgba(209, 213, 219, 0.6)',
        }
      ]
    };
  }, [summaries, language]);

  // Status Distribution
  const statusData = useMemo(() => {
    const counts: Record<string, number> = {
      [language === 'ar' ? 'منتظم' : 'Régulier']: 0,
      [language === 'ar' ? 'متأخر' : 'En retard']: 0,
      [language === 'ar' ? 'متأخر جدا' : 'Très en retard']: 0,
      [language === 'ar' ? 'منتهي' : 'Terminé']: 0
    };

    summaries.forEach(s => {
      if (s.isStopList) counts[language === 'ar' ? 'منتهي' : 'Terminé']++;
      else if (s.overdueMonths >= 2) counts[language === 'ar' ? 'متأخر جدا' : 'Très en retard']++;
      else if (s.overdueMonths === 1) counts[language === 'ar' ? 'متأخر' : 'En retard']++;
      else counts[language === 'ar' ? 'منتظم' : 'Régulier']++;
    });

    return {
      labels: Object.keys(counts),
      datasets: [
        {
          data: Object.values(counts),
          backgroundColor: [
            'rgba(16, 185, 129, 0.6)',
            'rgba(245, 158, 11, 0.6)',
            'rgba(239, 68, 68, 0.6)',
            'rgba(31, 41, 55, 0.6)',
          ],
        }
      ]
    };
  }, [summaries, language]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-10">
      <div className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm">
        <h3 className="text-lg font-bold mb-6 text-zinc-800">
          {language === 'ar' ? 'أداء التحصيل الشهري' : 'Performance Mensuelle de Collecte'}
        </h3>
        <Bar 
          data={monthlyData} 
          options={{ 
            responsive: true,
            plugins: { legend: { position: 'bottom' as const } },
            scales: { y: { beginAtZero: true } }
          }} 
        />
      </div>
      <div className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm">
        <h3 className="text-lg font-bold mb-6 text-zinc-800">
          {language === 'ar' ? 'توزيع حالات الزبائن' : 'Distribution des Statuts Clients'}
        </h3>
        <div className="max-w-[300px] mx-auto">
          <Pie 
            data={statusData} 
            options={{ 
              responsive: true,
              plugins: { legend: { position: 'bottom' as const } }
            }} 
          />
        </div>
      </div>
    </div>
  );
};
