import React from 'react';
import { 
  CheckCircle2, 
  Clock, 
  Eye, 
  XCircle, 
  Lock, 
  AlertTriangle, 
  Ban,
  HelpCircle
} from 'lucide-react';
import { PaymentStatus, Language } from '../types';
import { useTranslation } from '../utils/translations';

export const getStatusConfig = (status: string, t: any) => {
  const configs: Record<string, { 
    icon: React.ReactNode; 
    label: string; 
    color: string;
    bgColor: string;
    borderColor: string;
  }> = {
    [PaymentStatus.PAID_ON_TIME]: {
      icon: <CheckCircle2 size={16} />,
      label: t.paidOnTime,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      borderColor: "border-blue-200"
    },
    [PaymentStatus.PAID_LATE]: {
      icon: <Clock size={16} />,
      label: t.paidLate,
      color: "text-emerald-600",
      bgColor: "bg-emerald-50",
      borderColor: "border-emerald-200"
    },
    [PaymentStatus.UNDER_MONITORING]: {
      icon: <Eye size={16} />,
      label: t.underMonitoring,
      color: "text-amber-600",
      bgColor: "bg-amber-50",
      borderColor: "border-amber-200"
    },
    [PaymentStatus.NOT_PAID]: {
      icon: <XCircle size={16} />,
      label: t.notPaid,
      color: "text-red-600",
      bgColor: "bg-red-50",
      borderColor: "border-red-200"
    },
    [PaymentStatus.ACCOUNT_BLOCKED]: {
      icon: <Lock size={16} />,
      label: t.blocked,
      color: "text-zinc-900",
      bgColor: "bg-zinc-100",
      borderColor: "border-zinc-900"
    },
    [PaymentStatus.MONITORING_FAILURE]: {
      icon: <AlertTriangle size={16} />,
      label: t.monitoringFailure,
      color: "text-red-600",
      bgColor: "bg-red-50",
      borderColor: "border-red-200"
    },
    "STOP_LIST": {
      icon: <Ban size={16} />,
      label: t.toStop,
      color: "text-red-600",
      bgColor: "bg-red-50",
      borderColor: "border-red-200"
    },
    [PaymentStatus.UNKNOWN]: {
      icon: <HelpCircle size={16} />,
      label: t.unknown,
      color: "text-zinc-400",
      bgColor: "bg-zinc-50",
      borderColor: "border-zinc-200"
    }
  };
  return configs[status] || configs[PaymentStatus.UNKNOWN];
};

interface StatusBadgeProps {
  status: string;
  showLabel?: boolean;
  className?: string;
  language?: Language;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, showLabel = true, className = "", language = 'fr' }) => {
  const t = useTranslation(language as Language);
  const config = getStatusConfig(status, t);
  
  return (
    <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-xs font-bold transition-all ${config.bgColor} ${config.color} ${config.borderColor} ${className}`}>
      {config.icon}
      {showLabel && <span>{config.label}</span>}
    </div>
  );
};
