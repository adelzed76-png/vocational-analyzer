import React, { useState, useMemo, useEffect } from 'react';
import { Language } from '../types';
import { useTranslation } from '../utils/translations';
import { formatCurrency } from '../utils/formatters';
import { 
  Search, 
  FileText, 
  User, 
  CreditCard, 
  CheckCircle2, 
  AlertTriangle, 
  TrendingUp, 
  Trash2,
  Download,
  ClipboardCheck
} from 'lucide-react';

interface CodeAnalysisToolProps {
  language: Language;
}

interface Record {
  ccp: string;
  name: string;
  amount: number;
  date: string;
  sellerCcp: string;
  code: string;
  reference: string;
}

interface AnalyzedReference {
  reference: string;
  name: string;
  ccp: string;
  amount: number;
  status: 'PAID_ON_TIME' | 'UNDER_SURVEILLANCE';
}

export const CodeAnalysisTool: React.FC<CodeAnalysisToolProps> = ({ language }) => {
  const [resultsRaw, setResultsRaw] = useState(() => localStorage.getItem('code_analysis_raw') || '');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeView, setActiveView] = useState<'references' | 'amounts' | 'customer'>('references');
  const [selectedCustomerCcp, setSelectedCustomerCcp] = useState<string | null>(null);
  const t = useTranslation(language);
  const isRtl = language === 'ar';

  useEffect(() => {
    localStorage.setItem('code_analysis_raw', resultsRaw);
  }, [resultsRaw]);

  const parseResults = (raw: string): Record[] => {
    if (!raw.trim()) return [];
    const lines = raw.split('\n');
    const records: Record[] = [];

    lines.forEach((line) => {
      const trimmed = line.trim();
      if (!trimmed) return;

      try {
        // Data Extraction Rules:
        // 1. Customer account
        // 2. Name
        // 3. Amount
        // 4. Date
        // 5. Seller account (ends with 93)
        // 6. Code (3 digits)
        // 7. Reference (rest of line)

        // a. Customer account
        const ccpMatch = trimmed.match(/^[.\s]*(\d+)/);
        if (!ccpMatch) return;
        const ccp = ccpMatch[1];
        let remaining = trimmed.substring(ccpMatch[0].length);

        // b. Amount
        const amountMatch = remaining.match(/[.\s]*(\d+\.\d{2})/);
        if (!amountMatch) return;
        
        // Name is between ccp and amount
        const name = remaining.substring(0, amountMatch.index!).replace(/[.\s]+/g, ' ').trim();
        if (!name) return;
        
        const amount = parseFloat(amountMatch[1]);
        remaining = remaining.substring(amountMatch.index! + amountMatch[0].length);

        // d. Date (DD/MM/YYYY)
        const dateMatch = remaining.match(/[.\s]*(\d{1,2}\/\d{1,2}\/\d{4})/);
        if (!dateMatch) return;
        const date = dateMatch[1];
        remaining = remaining.substring(remaining.indexOf(date) + date.length);

        // e. Seller account (ending with 93)
        const sellerCcpMatch = remaining.match(/[.\s]*(\d*93)/);
        if (!sellerCcpMatch) return;
        const sellerCcp = sellerCcpMatch[1];
        remaining = remaining.substring(remaining.indexOf(sellerCcp) + sellerCcp.length);

        // f. Code (3 digits)
        const codeMatch = remaining.match(/[.\s]*(\d{3})/);
        if (!codeMatch) return;
        const code = codeMatch[1];
        remaining = remaining.substring(remaining.indexOf(code) + 3);

        // g. Reference
        const reference = remaining.replace(/^[.\s]+|[.\s]+$/g, '').trim();
        if (!reference) return;

        records.push({ ccp, name, amount, date, sellerCcp, code, reference });
      } catch (e) {
        // Skip malformed lines
      }
    });

    return records;
  };

  const analyzedData = useMemo(() => {
    const records = parseResults(resultsRaw);
    if (records.length === 0) return null;

    // Group by reference
    const refGroups = new Map<string, Record[]>();
    records.forEach(r => {
      if (!refGroups.has(r.reference)) {
        refGroups.set(r.reference, []);
      }
      refGroups.get(r.reference)!.push(r);
    });

    const results: AnalyzedReference[] = [];
    let count000 = 0;
    let count100 = 0;
    let amount000 = 0;
    let amount100 = 0;

    refGroups.forEach((group, ref) => {
      const has000 = group.some(r => r.code === '000');
      const has100 = group.some(r => r.code === '100');

      if (has000 || has100) {
        // Priority Rule: 000 takes priority
        const status = has000 ? 'PAID_ON_TIME' : 'UNDER_SURVEILLANCE';
        const representative = group[0]; // Take first occurrence for name/ccp/amount

        results.push({
          reference: ref,
          name: representative.name,
          ccp: representative.ccp,
          amount: representative.amount,
          status
        });

        if (status === 'PAID_ON_TIME') {
          count000++;
          amount000 += representative.amount;
        } else {
          count100++;
          amount100 += representative.amount;
        }
      }
    });

    // Sub-feature: Group by Amount
    const amountMap = new Map<number, number>();
    results.forEach(r => {
      amountMap.set(r.amount, (amountMap.get(r.amount) || 0) + 1);
    });

    const amountGroups = Array.from(amountMap.entries()).map(([amount, count]) => ({
      amount,
      count,
      total: amount * count
    })).sort((a, b) => b.amount - a.amount);

    const totalRepeated = amountGroups
      .filter(g => g.count > 1)
      .reduce((sum, g) => sum + g.total, 0);

    const totalUnique = amountGroups
      .filter(g => g.count === 1)
      .reduce((sum, g) => sum + g.amount, 0);

    return {
      references: results,
      amountGroups,
      summary: {
        count000,
        count100,
        amount000,
        amount100,
        totalRepeated,
        totalUnique,
        grandTotal: totalRepeated + totalUnique
      }
    };
  }, [resultsRaw]);

  const customerAnalysis = useMemo(() => {
    if (!selectedCustomerCcp || !analyzedData) return null;
    
    const customerRefs = analyzedData.references.filter(r => r.ccp === selectedCustomerCcp);
    if (customerRefs.length === 0) return null;

    const amountMap = new Map<number, number>();
    customerRefs.forEach(r => {
      amountMap.set(r.amount, (amountMap.get(r.amount) || 0) + 1);
    });

    const amountGroups = Array.from(amountMap.entries()).map(([amount, count]) => ({
      amount,
      count,
      total: amount * count
    })).sort((a, b) => b.amount - a.amount);

    const totalRepeated = amountGroups
      .filter(g => g.count > 1)
      .reduce((sum, g) => sum + g.total, 0);

    const totalUnique = amountGroups
      .filter(g => g.count === 1)
      .reduce((sum, g) => sum + g.amount, 0);

    return {
      name: customerRefs[0].name,
      ccp: selectedCustomerCcp,
      amountGroups,
      summary: {
        totalRepeated,
        totalUnique,
        grandTotal: totalRepeated + totalUnique
      }
    };
  }, [selectedCustomerCcp, analyzedData]);

  const filteredReferences = useMemo(() => {
    if (!analyzedData) return [];
    if (!searchQuery.trim()) return analyzedData.references;
    const query = searchQuery.toLowerCase();
    return analyzedData.references.filter(r => 
      r.name.toLowerCase().includes(query) || 
      r.ccp.includes(query) || 
      r.reference.toLowerCase().includes(query)
    );
  }, [analyzedData, searchQuery]);

  const copyResultsToClipboard = () => {
    if (!analyzedData) return;

    let text = `-------------------------------------\n`;
    text += `CODE 000 & CODE 100 ANALYSIS\n`;
    text += `-------------------------------------\n\n`;

    if (activeView === 'references') {
      text += `FINANCIAL SUMMARY\n`;
      text += `- Paid ON TIME (000): ${analyzedData.summary.count000} refs | ${analyzedData.summary.amount000.toFixed(2)} DZD\n`;
      text += `- Under Surveillance (100): ${analyzedData.summary.count100} refs | ${analyzedData.summary.amount100.toFixed(2)} DZD\n\n`;

      text += `DETAILS PER REFERENCE\n`;
      filteredReferences.forEach(r => {
        const statusLabel = r.status === 'PAID_ON_TIME' ? 'PAID ON TIME 🔵' : 'UNDER SURVEILLANCE ⚠️';
        text += `- Ref: ${r.reference} | ${r.name} | ${r.ccp} | ${r.amount.toFixed(2)} DZD | ${statusLabel}\n`;
      });
    } else if (activeView === 'amounts') {
      text += `AMOUNT ANALYSIS SUMMARY\n`;
      text += `- Total Repeated Amounts: ${analyzedData.summary.totalRepeated.toFixed(2)} DZD\n`;
      text += `- Total Unique Amounts: ${analyzedData.summary.totalUnique.toFixed(2)} DZD\n`;
      text += `- Grand Total: ${analyzedData.summary.grandTotal.toFixed(2)} DZD\n\n`;

      text += `GROUPED AMOUNTS\n`;
      analyzedData.amountGroups.forEach(g => {
        text += `- Amount: ${g.amount.toFixed(2)} | Count: ${g.count} | Total: ${g.total.toFixed(2)} DZD\n`;
      });
    } else if (activeView === 'customer' && customerAnalysis) {
      text += `CUSTOMER ANALYSIS: ${customerAnalysis.name} (${customerAnalysis.ccp})\n`;
      text += `-------------------------------------\n`;
      text += `- Total Repeated Amounts: ${customerAnalysis.summary.totalRepeated.toFixed(2)} DZD\n`;
      text += `- Total Unique Amounts: ${customerAnalysis.summary.totalUnique.toFixed(2)} DZD\n`;
      text += `- Grand Total: ${customerAnalysis.summary.grandTotal.toFixed(2)} DZD\n\n`;

      text += `GROUPED AMOUNTS PER REFERENCE\n`;
      customerAnalysis.amountGroups.forEach(g => {
        text += `- Amount: ${g.amount.toFixed(2)} | Count: ${g.count} | Total: ${g.total.toFixed(2)} DZD\n`;
      });
    }

    navigator.clipboard.writeText(text);
    alert(language === 'ar' ? 'تم نسخ النتائج!' : 'Résultats copiés !');
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="bg-white border border-zinc-200 rounded-3xl p-8 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
          <div className="flex items-center gap-4">
            <div className="bg-blue-100 text-blue-600 p-3 rounded-2xl">
              <ClipboardCheck size={32} />
            </div>
            <div>
              <h3 className="text-2xl font-black text-zinc-900">
                {language === 'ar' ? 'تحليل الكود 000 و 100' : 'Analyse Code 000 & Code 100'}
              </h3>
              <p className="text-zinc-500">
                {language === 'ar' ? 'استخراج المراجع المدفوعة في الوقت وتحت المراقبة' : 'Extraction des références payées à temps et sous surveillance'}
              </p>
            </div>
          </div>

          {analyzedData && (
            <div className="flex bg-zinc-100 p-1 rounded-2xl self-start md:self-center">
              <button
                onClick={() => setActiveView('references')}
                className={`px-6 py-2 rounded-xl text-xs font-black transition-all ${activeView === 'references' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-500 hover:text-zinc-700'}`}
              >
                {t.referenceDetails}
              </button>
              <button
                onClick={() => setActiveView('amounts')}
                className={`px-6 py-2 rounded-xl text-xs font-black transition-all ${activeView === 'amounts' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-500 hover:text-zinc-700'}`}
              >
                {t.amountAnalysis}
              </button>
              {selectedCustomerCcp && (
                <button
                  onClick={() => setActiveView('customer')}
                  className={`px-6 py-2 rounded-xl text-xs font-black transition-all ${activeView === 'customer' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-500 hover:text-zinc-700'}`}
                >
                  {language === 'ar' ? 'تحليل الزبون' : 'Analyse Client'}
                </button>
              )}
            </div>
          )}
        </div>

        <div className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-bold text-zinc-700 ml-1">
              {language === 'ar' ? 'تحميل ملف النتائج' : 'Charger le fichier des résultats'}
            </label>
            <div className="relative">
              <textarea
                value={resultsRaw}
                onChange={(e) => setResultsRaw(e.target.value)}
                placeholder={language === 'ar' ? 'الصق محتوى ملف النتائج هنا...' : 'Collez le contenu du fichier des résultats ici...'}
                className="w-full h-32 p-4 bg-zinc-50 border border-zinc-200 rounded-2xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all font-mono text-sm resize-none"
              />
              {resultsRaw && (
                <button 
                  onClick={() => setResultsRaw('')}
                  className="absolute top-4 right-4 text-red-500 hover:text-red-600 p-2 hover:bg-red-50 rounded-xl transition-all"
                >
                  <Trash2 size={16} />
                </button>
              )}
            </div>
          </div>

          {activeView === 'references' && (
            <div className="relative">
              <Search className={`absolute ${isRtl ? 'right-4' : 'left-4'} top-1/2 -translate-y-1/2 text-zinc-400`} size={20} />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={language === 'ar' ? 'ابحث بالاسم، الحساب، أو المرجع...' : 'Rechercher par nom, compte, ou référence...'}
                className={`w-full ${isRtl ? 'pr-12 pl-4' : 'pl-12 pr-4'} py-4 bg-zinc-50 border border-zinc-200 rounded-2xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all font-bold`}
              />
            </div>
          )}
        </div>
      </div>

      {analyzedData && (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-300">
          {activeView === 'references' ? (
            <>
              {/* Summary */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white border border-zinc-200 rounded-3xl p-6 shadow-sm flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="bg-blue-100 text-blue-600 p-3 rounded-2xl">
                      <CheckCircle2 size={24} />
                    </div>
                    <div>
                      <p className="text-xs text-zinc-400 uppercase font-bold tracking-widest">
                        {language === 'ar' ? 'مدفوع في الوقت (000)' : 'PAID ON TIME (000)'}
                      </p>
                      <p className="text-2xl font-black text-zinc-900">{analyzedData.summary.count000} <span className="text-sm font-medium text-zinc-400">refs</span></p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-black text-blue-600">{formatCurrency(analyzedData.summary.amount000)}</p>
                  </div>
                </div>

                <div className="bg-white border border-zinc-200 rounded-3xl p-6 shadow-sm flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="bg-amber-100 text-amber-600 p-3 rounded-2xl">
                      <AlertTriangle size={24} />
                    </div>
                    <div>
                      <p className="text-xs text-zinc-400 uppercase font-bold tracking-widest">
                        {language === 'ar' ? 'تحت المراقبة (100)' : 'UNDER SURVEILLANCE (100)'}
                      </p>
                      <p className="text-2xl font-black text-zinc-900">{analyzedData.summary.count100} <span className="text-sm font-medium text-zinc-400">refs</span></p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-black text-amber-600">{formatCurrency(analyzedData.summary.amount100)}</p>
                  </div>
                </div>
              </div>

              {/* Results Table */}
              <div className="bg-white border border-zinc-200 rounded-3xl overflow-hidden shadow-sm">
                <div className="p-6 border-b border-zinc-100 bg-zinc-50/50 flex items-center justify-between">
                  <h4 className="font-black text-zinc-900 flex items-center gap-2">
                    <FileText size={20} className="text-zinc-400" />
                    {language === 'ar' ? 'تفاصيل المراجع' : 'DÉTAILS DES RÉFÉRENCES'}
                  </h4>
                  <button 
                    onClick={copyResultsToClipboard}
                    className="flex items-center gap-2 px-4 py-2 bg-zinc-900 text-white rounded-xl font-bold text-xs hover:bg-zinc-800 transition-all"
                  >
                    <Download size={14} />
                    {language === 'ar' ? 'نسخ النتائج' : 'Copier les résultats'}
                  </button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="bg-zinc-50 text-zinc-500 text-[10px] uppercase tracking-wider font-black">
                        <th className="px-6 py-4">{language === 'ar' ? 'المرجع' : 'RÉFÉRENCE'}</th>
                        <th className="px-6 py-4">{language === 'ar' ? 'الزبون' : 'CLIENT'}</th>
                        <th className="px-6 py-4">{language === 'ar' ? 'الحساب' : 'COMPTE'}</th>
                        <th className="px-6 py-4">{language === 'ar' ? 'المبلغ' : 'MONTANT'}</th>
                        <th className="px-6 py-4">{language === 'ar' ? 'الحالة' : 'STATUT'}</th>
                        <th className="px-6 py-4"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-100">
                      {filteredReferences.map((r) => (
                        <tr key={r.reference} className="hover:bg-zinc-50/50 transition-colors">
                          <td className="px-6 py-4 font-mono text-xs font-bold text-zinc-600">{r.reference}</td>
                          <td className="px-6 py-4 font-black text-zinc-900 text-sm">{r.name}</td>
                          <td className="px-6 py-4 font-mono text-xs text-zinc-500">{r.ccp}</td>
                          <td className="px-6 py-4 font-black text-zinc-900">{formatCurrency(r.amount)}</td>
                          <td className="px-6 py-4">
                            {r.status === 'PAID_ON_TIME' ? (
                              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-[10px] font-black uppercase tracking-wider">
                                <CheckCircle2 size={12} />
                                {language === 'ar' ? 'مدفوع في الوقت' : 'PAID ON TIME'} 🔵
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-100 text-amber-700 rounded-full text-[10px] font-black uppercase tracking-wider">
                                <AlertTriangle size={12} />
                                {language === 'ar' ? 'تحت المراقبة' : 'SURVEILLANCE'} ⚠️
                              </span>
                            )}
                          </td>
                          <td className="px-6 py-4 text-right">
                            <button
                              onClick={() => {
                                setSelectedCustomerCcp(r.ccp);
                                setActiveView('customer');
                              }}
                              className="p-2 text-zinc-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all"
                              title={language === 'ar' ? 'تحليل مبالغ الزبون' : 'Analyser les montants du client'}
                            >
                              <TrendingUp size={18} />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          ) : activeView === 'amounts' ? (
            <>
              {/* Amount Summary */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white border border-zinc-200 rounded-3xl p-6 shadow-sm">
                  <p className="text-xs text-zinc-400 uppercase font-bold tracking-widest mb-1">
                    {t.repeatedAmounts}
                  </p>
                  <p className="text-2xl font-black text-zinc-900">{formatCurrency(analyzedData.summary.totalRepeated)}</p>
                </div>
                <div className="bg-white border border-zinc-200 rounded-3xl p-6 shadow-sm">
                  <p className="text-xs text-zinc-400 uppercase font-bold tracking-widest mb-1">
                    {t.uniqueAmounts}
                  </p>
                  <p className="text-2xl font-black text-zinc-900">{formatCurrency(analyzedData.summary.totalUnique)}</p>
                </div>
                <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 shadow-lg shadow-zinc-200">
                  <p className="text-xs text-zinc-400 uppercase font-bold tracking-widest mb-1">
                    {t.grandTotal}
                  </p>
                  <p className="text-2xl font-black text-white">{formatCurrency(analyzedData.summary.grandTotal)}</p>
                </div>
              </div>

              {/* Amount Grouping Table */}
              <div className="bg-white border border-zinc-200 rounded-3xl overflow-hidden shadow-sm">
                <div className="p-6 border-b border-zinc-100 bg-zinc-50/50 flex items-center justify-between">
                  <h4 className="font-black text-zinc-900 flex items-center gap-2">
                    <TrendingUp size={20} className="text-zinc-400" />
                    {language === 'ar' ? 'تجميع المبالغ' : 'GROUPEMENT DES MONTANTS'}
                  </h4>
                  <button 
                    onClick={copyResultsToClipboard}
                    className="flex items-center gap-2 px-4 py-2 bg-zinc-900 text-white rounded-xl font-bold text-xs hover:bg-zinc-800 transition-all"
                  >
                    <Download size={14} />
                    {language === 'ar' ? 'نسخ النتائج' : 'Copier les résultats'}
                  </button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="bg-zinc-50 text-zinc-500 text-[10px] uppercase tracking-wider font-black">
                        <th className="px-6 py-4">{t.amount}</th>
                        <th className="px-6 py-4">{t.count}</th>
                        <th className="px-6 py-4">TOTAL</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-100">
                      {analyzedData.amountGroups.map((g) => (
                        <tr key={g.amount} className={`hover:bg-zinc-50/50 transition-colors ${g.count > 1 ? 'bg-blue-50/30' : ''}`}>
                          <td className="px-6 py-4 font-black text-zinc-900">{formatCurrency(g.amount)}</td>
                          <td className="px-6 py-4 font-mono font-bold text-zinc-600">
                            <span className={`inline-flex items-center justify-center w-8 h-8 rounded-full ${g.count > 1 ? 'bg-blue-100 text-blue-700' : 'bg-zinc-100 text-zinc-500'}`}>
                              {g.count}
                            </span>
                          </td>
                          <td className="px-6 py-4 font-black text-zinc-900">{formatCurrency(g.total)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          ) : (
            <>
              {/* Customer Specific Analysis */}
              {customerAnalysis && (
                <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-300">
                  <div className="bg-blue-50 border border-blue-100 rounded-3xl p-6 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="bg-blue-600 text-white p-3 rounded-2xl">
                        <User size={24} />
                      </div>
                      <div>
                        <h4 className="text-xl font-black text-zinc-900">{customerAnalysis.name}</h4>
                        <p className="text-sm font-mono text-blue-600 font-bold">{customerAnalysis.ccp}</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => setActiveView('references')}
                      className="px-4 py-2 bg-white text-zinc-600 rounded-xl font-bold text-xs border border-zinc-200 hover:bg-zinc-50 transition-all"
                    >
                      {t.close}
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-white border border-zinc-200 rounded-3xl p-6 shadow-sm">
                      <p className="text-xs text-zinc-400 uppercase font-bold tracking-widest mb-1">
                        {t.repeatedAmounts}
                      </p>
                      <p className="text-2xl font-black text-zinc-900">{formatCurrency(customerAnalysis.summary.totalRepeated)}</p>
                    </div>
                    <div className="bg-white border border-zinc-200 rounded-3xl p-6 shadow-sm">
                      <p className="text-xs text-zinc-400 uppercase font-bold tracking-widest mb-1">
                        {t.uniqueAmounts}
                      </p>
                      <p className="text-2xl font-black text-zinc-900">{formatCurrency(customerAnalysis.summary.totalUnique)}</p>
                    </div>
                    <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 shadow-lg shadow-zinc-200">
                      <p className="text-xs text-zinc-400 uppercase font-bold tracking-widest mb-1">
                        {t.grandTotal}
                      </p>
                      <p className="text-2xl font-black text-white">{formatCurrency(customerAnalysis.summary.grandTotal)}</p>
                    </div>
                  </div>

                  <div className="bg-white border border-zinc-200 rounded-3xl overflow-hidden shadow-sm">
                    <div className="p-6 border-b border-zinc-100 bg-zinc-50/50 flex items-center justify-between">
                      <h4 className="font-black text-zinc-900 flex items-center gap-2">
                        <TrendingUp size={20} className="text-zinc-400" />
                        {language === 'ar' ? 'تجميع مبالغ الزبون' : 'GROUPEMENT DES MONTANTS DU CLIENT'}
                      </h4>
                      <button 
                        onClick={copyResultsToClipboard}
                        className="flex items-center gap-2 px-4 py-2 bg-zinc-900 text-white rounded-xl font-bold text-xs hover:bg-zinc-800 transition-all"
                      >
                        <Download size={14} />
                        {language === 'ar' ? 'نسخ النتائج' : 'Copier les résultats'}
                      </button>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left">
                        <thead>
                          <tr className="bg-zinc-50 text-zinc-500 text-[10px] uppercase tracking-wider font-black">
                            <th className="px-6 py-4">{t.amount}</th>
                            <th className="px-6 py-4">{t.count}</th>
                            <th className="px-6 py-4">TOTAL</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-zinc-100">
                          {customerAnalysis.amountGroups.map((g) => (
                            <tr key={g.amount} className={`hover:bg-zinc-50/50 transition-colors ${g.count > 1 ? 'bg-blue-50/30' : ''}`}>
                              <td className="px-6 py-4 font-black text-zinc-900">{formatCurrency(g.amount)}</td>
                              <td className="px-6 py-4 font-mono font-bold text-zinc-600">
                                <span className={`inline-flex items-center justify-center w-8 h-8 rounded-full ${g.count > 1 ? 'bg-blue-100 text-blue-700' : 'bg-zinc-100 text-zinc-500'}`}>
                                  {g.count}
                                </span>
                              </td>
                              <td className="px-6 py-4 font-black text-zinc-900">{formatCurrency(g.total)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
};
