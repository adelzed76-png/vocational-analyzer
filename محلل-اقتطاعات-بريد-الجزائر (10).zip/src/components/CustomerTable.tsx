import React from 'react';
import { CustomerSummary, PaymentStatus, Language } from '../types';
import { getStatusFromCode } from '../utils/parser';
import { AlertCircle, CheckCircle2, Clock, Ban, Eye, XCircle, Lock, HelpCircle } from 'lucide-react';
import { StatusBadge } from './StatusBadge';
import { formatCurrency } from '../utils/formatters';
import { useTranslation } from '../utils/translations';

interface CustomerTableProps {
  summaries: CustomerSummary[];
  onSelectCustomer: (summary: CustomerSummary) => void;
  language: Language;
}

export const CustomerTable: React.FC<CustomerTableProps> = ({ summaries, onSelectCustomer, language }) => {
  const t = useTranslation(language);
  const isRtl = language === 'ar';

  return (
    <div className="w-full overflow-hidden bg-white border border-zinc-200 rounded-2xl shadow-sm">
      <div className="overflow-x-auto">
        <table className={`w-full ${isRtl ? 'text-right' : 'text-left'} border-collapse`}>
          <thead>
            <tr className="bg-zinc-50 border-b border-zinc-200">
              <th className={`px-6 py-4 text-sm font-bold text-zinc-700 ${isRtl ? 'text-right' : 'text-left'}`}>{t.accountNumber}</th>
              <th className={`px-6 py-4 text-sm font-bold text-zinc-700 ${isRtl ? 'text-right' : 'text-left'}`}>{t.customerName}</th>
              <th className="px-6 py-4 text-sm font-bold text-zinc-700 text-center">{t.installmentAmount}</th>
              <th className="px-6 py-4 text-sm font-bold text-zinc-700 text-center">{t.totalPaid}</th>
              <th className="px-6 py-4 text-sm font-bold text-zinc-700 text-center">{t.remainingAmount}</th>
              <th className="px-6 py-4 text-sm font-bold text-zinc-700 text-center">{t.totalAttempts}</th>
              <th className="px-6 py-4 text-sm font-bold text-zinc-700 text-center">{t.lastStatus}</th>
              <th className="px-6 py-4 text-sm font-bold text-zinc-700 text-center">{t.generalStatus}</th>
              <th className="px-6 py-4 text-sm font-bold text-zinc-700 text-center">{t.actions}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-100">
            {summaries.map((customer) => {
              const lastRecord = customer.records[customer.records.length - 1];
              const lastStatus = lastRecord ? getStatusFromCode(lastRecord.statusCode).status : PaymentStatus.UNKNOWN;
              
              return (
                <tr 
                  key={customer.customerAccount} 
                  className={`hover:bg-zinc-50 transition-colors ${customer.overdueMonths >= 2 ? 'bg-red-50/30' : ''}`}
                >
                  <td className={`px-6 py-4 text-sm font-medium text-zinc-900 font-mono ${isRtl ? 'text-right' : 'text-left'}`}>{customer.customerAccount}</td>
                  <td className={`px-6 py-4 text-sm text-zinc-700 ${isRtl ? 'text-right' : 'text-left'}`}>{customer.customerName}</td>
                  <td className="px-6 py-4 text-sm text-center font-bold">{formatCurrency(customer.loans.reduce((sum, l) => sum + l.installmentAmount, 0))}</td>
                  <td className="px-6 py-4 text-sm text-center text-emerald-600 font-bold">{formatCurrency(customer.totalCollected)}</td>
                  <td className="px-6 py-4 text-sm text-center text-zinc-500">{formatCurrency(customer.totalRemaining)}</td>
                  <td className="px-6 py-4 text-sm text-center">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${customer.totalAttempts > customer.records.length ? 'bg-amber-100 text-amber-700' : 'bg-zinc-100 text-zinc-600'}`}>
                      {customer.totalAttempts}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-center">
                    <div className="flex justify-center">
                      {customer.isStopList ? (
                        <StatusBadge status="STOP_LIST" language={language} />
                      ) : (
                        <StatusBadge status={customer.latestStatus} language={language} />
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-center">
                    <div className="flex justify-center">
                      {customer.overdueMonths >= 2 ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-red-100 text-red-700 border border-red-200">
                          <AlertCircle size={10} /> {t.veryOverdue}
                        </span>
                      ) : customer.overdueMonths === 1 ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-700 border border-amber-200">
                          <Clock size={10} /> {t.overdue}
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700 border border-emerald-200">
                          <CheckCircle2 size={10} /> {t.regular}
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-center">
                    <button
                      onClick={() => onSelectCustomer(customer)}
                      className="text-emerald-600 hover:text-emerald-700 font-bold text-xs underline underline-offset-4"
                    >
                      {t.details}
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

