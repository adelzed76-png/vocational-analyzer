import { openDB, IDBPDatabase } from 'idb';
import { RawRecord, CustomerSummary, CustomerConfig } from '../types';

const DB_NAME = 'AlgeriaPostAnalyzer';
const STORE_RECORDS = 'records';
const STORE_SUMMARIES = 'summaries';
const STORE_CONFIGS = 'durations'; // Keeping the name for backward compatibility but storing objects
const STORE_ZAKAT = 'zakat';

export async function initDB() {
  return openDB(DB_NAME, 3, {
    upgrade(db, oldVersion) {
      if (oldVersion < 1) {
        db.createObjectStore(STORE_RECORDS, { keyPath: 'id' });
        db.createObjectStore(STORE_SUMMARIES, { keyPath: 'customerAccount' });
      }
      if (oldVersion < 2) {
        if (!db.objectStoreNames.contains(STORE_CONFIGS)) {
          db.createObjectStore(STORE_CONFIGS);
        }
      }
      if (oldVersion < 3) {
        if (!db.objectStoreNames.contains(STORE_ZAKAT)) {
          db.createObjectStore(STORE_ZAKAT);
        }
      }
    },
  });
}

import { ZakatState } from '../types';

export async function saveZakatState(state: ZakatState) {
  const db = await initDB();
  await db.put(STORE_ZAKAT, state, 'current');
}

export async function getZakatState(): Promise<ZakatState | null> {
  const db = await initDB();
  return db.get(STORE_ZAKAT, 'current');
}

export async function saveCustomerConfig(account: string, config: CustomerConfig) {
  const db = await initDB();
  await db.put(STORE_CONFIGS, config, account);
}

export async function getCustomerConfigs(): Promise<Record<string, CustomerConfig>> {
  const db = await initDB();
  const tx = db.transaction(STORE_CONFIGS, 'readonly');
  const keys = await tx.store.getAllKeys();
  const values = await tx.store.getAll();
  const result: Record<string, CustomerConfig> = {};
  keys.forEach((key, i) => {
    // Handle legacy data where only duration was stored
    const val = values[i];
    if (typeof val === 'number') {
      result[key as string] = { duration: val as 12 | 15 | 18 };
    } else {
      result[key as string] = val;
    }
  });
  return result;
}

export async function saveRecords(records: RawRecord[]) {
  const db = await initDB();
  const tx = db.transaction(STORE_RECORDS, 'readwrite');
  for (const record of records) {
    await tx.store.put(record);
  }
  await tx.done;
}

export async function getAllRecords(): Promise<RawRecord[]> {
  const db = await initDB();
  return db.getAll(STORE_RECORDS);
}

export async function clearAllData() {
  const db = await initDB();
  const tx = db.transaction([STORE_RECORDS, STORE_SUMMARIES], 'readwrite');
  await Promise.all([
    tx.objectStore(STORE_RECORDS).clear(),
    tx.objectStore(STORE_SUMMARIES).clear(),
    tx.done
  ]);
}

export async function saveSummaries(summaries: CustomerSummary[]) {
  const db = await initDB();
  const tx = db.transaction(STORE_SUMMARIES, 'readwrite');
  for (const summary of summaries) {
    await tx.store.put(summary);
  }
  await tx.done;
}

export async function getSummaries(): Promise<CustomerSummary[]> {
  const db = await initDB();
  return db.getAll(STORE_SUMMARIES);
}
