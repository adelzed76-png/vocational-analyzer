/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum PaymentStatus {
  PAID_ON_TIME = "PAID_ON_TIME",
  PAID_LATE = "PAID_LATE",
  UNDER_MONITORING = "UNDER_MONITORING",
  NOT_PAID = "NOT_PAID",
  ACCOUNT_BLOCKED = "ACCOUNT_BLOCKED",
  MONITORING_FAILURE = "MONITORING_FAILURE",
  OVERPAID = "OVERPAID",
  OVER_DEDUCTION = "OVER_DEDUCTION",
  UNKNOWN = "UNKNOWN",
  NOT_COLLECTED = "NOT_COLLECTED",
  OVERDUE = "OVERDUE",
  STOP_LIST = "STOP_LIST"
}

export type Language = 'ar' | 'fr';

export interface RawRecord {
  id: string;
  customerAccount: string;
  customerName: string;
  installmentAmount: number;
  installmentDate: string; // DD/MM/YYYY (from file)
  deductionDay: number;    // Extracted from code
  deductionMonth: string;  // Extracted from file
  deductionYear: string;   // Extracted from file
  sellerAccount: string;
  statusCode: string;
  referenceNumber: string;
  referenceYear: string;
  fullReference: string;
  fileName: string;
  lineIndex: number;
  uploadDate: number;
  isValid: boolean;
}

export interface MonthlyBreakdown {
  monthYear: string; // MM / YYYY
  installmentAmount: number;
  attemptCount: number;
  collectedAmount: number;
  notCollectedAmount: number;
  paidOnTimeCount: number;
  paidLateCount: number;
  unpaidCount: number;
  totalPaidAmount: number;
  totalUnpaidAmount: number;
  status: PaymentStatus;
  records: RawRecord[];
}

export interface LoanSummary {
  fullReference: string;
  referenceNumber: string;
  referenceYear: string;
  installmentAmount: number;
  installmentDuration: number;
  startDate?: string;
  endDate?: string;
  totalExpected: number;
  totalCollected: number;
  totalNotCollected: number;
  totalRemaining: number;
  totalPaidAmount: number;
  totalUnpaidAmount: number;
  totalAttempts: number;
  monthsPaid: number;
  monthsMissed: number;
  paidOnTimeCount: number;
  paidLateCount: number;
  unpaidCount: number;
  records: RawRecord[];
  monthlyBreakdown: MonthlyBreakdown[];
  isStopList: boolean;
  isOverpaid: boolean;
  overdueMonths: number;
  latestStatus: PaymentStatus;
  nonCollectableDebt?: boolean;
}

export interface CustomerSummary {
  customerAccount: string;
  customerName: string;
  loans: LoanSummary[];
  totalExpected: number;
  totalCollected: number;
  totalNotCollected: number;
  totalRemaining: number;
  totalAttempts: number;
  isStopList: boolean;
  isOverpaid: boolean;
  overdueMonths: number;
  completionDate?: string;
  latestStatus: PaymentStatus;
  records: RawRecord[]; // All records for this customer
  nonCollectableDebt?: boolean;
}

export interface ManualInstallment {
  reference: string;
  amount: number;
}

export interface ManualContract {
  startDate: string;
  endDate: string;
  duration: number;
  monthlyValue: number;
  installments: ManualInstallment[];
  nonCollectableDebt?: boolean;
}

export interface CustomerConfig {
  duration: number;
  startDate?: string;
  endDate?: string;
  nonCollectableDebt?: boolean;
  contracts?: ManualContract[];
}

export interface MonthlyStats {
  month: string; // YYYY-MM
  expected: number;
  collected: number;
  remaining: number;
}

export interface ZakatBenefit {
  id: string;
  customerName: string;
  startDate: string; // YYYY-MM-DD
  endDate: string;   // YYYY-MM-DD
  duration: number;
  monthlyAmount: number;
  isUncollectible: boolean;
}

export interface ZakatState {
  hawlStart: string; // YYYY-MM-DD
  hawlEnd: string;   // YYYY-MM-DD
  benefits: ZakatBenefit[];
}

export interface GlobalStats {
  totalCustomers: number;
  totalInstallments: number;
  validInstallments: number;
  invalidInstallments: number;
  totalPaid: number;
  totalUnpaid: number;
  totalExpectedAmount: number;
  totalCollectedAmount: number;
  totalNotCollectedAmount: number;
  totalRemainingAmount: number;
  rawCollectedAmount: number;
  stopListCount: number;
  overdueCount1Month: number;
  overdueCount2PlusMonths: number;
}
